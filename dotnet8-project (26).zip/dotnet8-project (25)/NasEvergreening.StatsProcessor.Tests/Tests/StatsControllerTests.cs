using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreening.StatsProcessor.Controllers;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using Xunit;

namespace NasEvergreening.StatsProcessor.Tests.Controllers
{
    public class StatsControllerTests
    {
        private readonly Mock<IStatsProcessingService> _mockService;
        private readonly Mock<ILogger<StatsController>> _mockLogger;
        private readonly StatsController _controller;

        public StatsControllerTests()
        {
            _mockService = new Mock<IStatsProcessingService>();
            _mockLogger = new Mock<ILogger<StatsController>>();
            _controller = new StatsController(_mockService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessStats_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("Key", "ErrorMessage");
            var request = new StatsProcessingRequestDto();

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.NotNull(badRequestResult.Value);
        }

        [Fact]
        public async Task ProcessStats_ReturnsOkResult_WithProcessingResult()
        {
            // Arrange
            var request = new StatsProcessingRequestDto { LoggingLevel = 1, CallMode = 'U' };
            var expectedResult = new StatsProcessingResultDto { Success = true, Message = "Success" };
            _mockService.Setup(s => s.ProcessStatsAsync(request)).ReturnsAsync(expectedResult);

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedResult, okResult.Value);
        }

        [Fact]
        public async Task ProcessStats_ReturnsBadRequest_WhenArgumentExceptionThrown()
        {
            // Arrange
            var request = new StatsProcessingRequestDto { LoggingLevel = 1, CallMode = 'U' };
            var exceptionMessage = "Invalid argument";
            _mockService.Setup(s => s.ProcessStatsAsync(request)).ThrowsAsync(new ArgumentException(exceptionMessage));

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var errorObj = Assert.IsType<dynamic>(badRequestResult.Value);
            Assert.Contains(exceptionMessage, errorObj.error.ToString());
            _mockLogger.Verify(l => l.LogWarning(It.IsAny<ArgumentException>(), It.Is<string>(s => s.Contains("Validation error"))), Times.Once);
        }

        [Fact]
        public async Task ProcessStats_ReturnsStatusCode500_WhenUnexpectedExceptionThrown()
        {
            // Arrange
            var request = new StatsProcessingRequestDto { LoggingLevel = 1, CallMode = 'U' };
            _mockService.Setup(s => s.ProcessStatsAsync(request)).ThrowsAsync(new Exception("Unexpected error"));

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            var errorObj = Assert.IsType<dynamic>(objectResult.Value);
            Assert.Equal("An unexpected error occurred.", errorObj.error.ToString());
            _mockLogger.Verify(l => l.LogError(It.IsAny<Exception>(), It.Is<string>(s => s.Contains("Unexpected error"))), Times.Once);
        }

        [Fact]
        public void Constructor_ThrowsArgumentNullException_WhenStatsProcessingServiceIsNull()
        {
            // Arrange
            IStatsProcessingService nullService = null;

            // Act & Assert
            var ex = Assert.Throws<ArgumentNullException>(() => new StatsController(nullService, _mockLogger.Object));
            Assert.Equal("statsProcessingService", ex.ParamName);
        }

        [Fact]
        public void Constructor_ThrowsArgumentNullException_WhenLoggerIsNull()
        {
            // Arrange
            ILogger<StatsController> nullLogger = null;

            // Act & Assert
            var ex = Assert.Throws<ArgumentNullException>(() => new StatsController(_mockService.Object, nullLogger));
            Assert.Equal("logger", ex.ParamName);
        }
    }
}
