using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatsController : ControllerBase
    {
        private readonly IStatsProcessingService _statsProcessingService;
        private readonly ILogger<StatsController> _logger;

        public StatsController(IStatsProcessingService statsProcessingService, ILogger<StatsController> logger)
        {
            _statsProcessingService = statsProcessingService ?? throw new ArgumentNullException(nameof(statsProcessingService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessStats([FromBody] StatsProcessingRequestDto request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var result = await _statsProcessingService.ProcessStatsAsync(request);
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                _logger.LogWarning(ex, "Validation error in ProcessStats");
                return BadRequest(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error in ProcessStats");
                return StatusCode(500, new { error = "An unexpected error occurred." });
            }
        }
    }
}