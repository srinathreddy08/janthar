using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("StatsRecords")]
    public class StatsRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int ReapplyDinCount { get; set; }

        public int PinCount { get; set; }

        public int LinDeleted { get; set; }

        public int TotalExistErrorRec { get; set; }

        public long CpuTime { get; set; }

        public long ElapsedTime { get; set; }

        public long TotalTimeCpu { get; set; }

        public long TotalTimeElapsed { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        [StringLength(50)]
        public string ModifiedBy { get; set; } = string.Empty;
    }
}