using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("StatsDetailRecords")]
    public class StatsDetailRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [StringLength(40)]
        public string Header { get; set; } = string.Empty;

        [StringLength(20)]
        public string Details { get; set; } = string.Empty;
    }
}