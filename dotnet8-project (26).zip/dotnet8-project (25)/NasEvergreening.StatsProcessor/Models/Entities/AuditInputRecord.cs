using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("AuditInputRecords")]
    public class AuditInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [StringLength(8)]
        public string ProcStartDate { get; set; } = string.Empty; // N-PROC-START-DT PIC X(08)

        [StringLength(4)]
        public string ProcStartTime { get; set; } = string.Empty; // N-PROC-START-TM PIC X(4)

        public long NasevgDin { get; set; } // PIC S9(18) COMP

        public long SrcDin { get; set; } // PIC S9(18) COMP

        public short SrcSubjIdNb { get; set; } // PIC S9(4) COMP

        public short SrcSubjSeqNb { get; set; } // PIC S9(4) COMP

        public long SrcRef { get; set; } // PIC S9(18) COMP

        [StringLength(440)]
        public string SrcName { get; set; } = string.Empty; // PIC X(440)

        public int SrcAin { get; set; } // PIC S9(9) COMP

        [StringLength(1)]
        public string AddrQty { get; set; } = string.Empty; // PIC X(1) with 88-levels

        [StringLength(2)]
        public string SrcAddrFrmtCd { get; set; } = string.Empty; // PIC X(2)

        [StringLength(440)]
        public string SrcAddr { get; set; } = string.Empty; // PIC X(440)

        // Formatted Address Group
        [StringLength(150)]
        public string SrcNm { get; set; } = string.Empty; // PIC X(150)

        [StringLength(60)]
        public string AddrLine1 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(60)]
        public string AddrLine2 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(60)]
        public string AddrLine3 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(60)]
        public string AddrLine4 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(60)]
        public string AddrLine5 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(112)]
        public string AddrLine6 { get; set; } = string.Empty; // PIC X(112)

        [StringLength(8)]
        public string AddrLine7 { get; set; } = string.Empty; // PIC X(8)

        public int AinFromNas { get; set; } // PIC S9(9) COMP

        [StringLength(1)]
        public string QtyFromNas { get; set; } = string.Empty; // PIC X(1) with 88-levels

        [StringLength(1)]
        public string AinChangeFlag { get; set; } = string.Empty; // PIC X(1) with 88-levels

        [StringLength(1)]
        public string DinFoundFlag { get; set; } = string.Empty; // PIC X(1) with 88-levels

        [StringLength(4)]
        public string ErrorCode { get; set; } = string.Empty; // PIC X(4) with 88-levels

        [StringLength(1)]
        public string ProcessStg { get; set; } = string.Empty; // PIC X(1) with 88-levels

        [StringLength(1)]
        public string FieldIndicator { get; set; } = string.Empty; // PIC X(1) with 88-levels

        [StringLength(5)]
        public string DataProvider { get; set; } = string.Empty; // PIC X(5)

        public int SequenceNb { get; set; } // PIC 9(6)

        public short PinCount { get; set; } // PIC S9(4) COMP

        public short NonStdLinCount { get; set; } // PIC S9(4) COMP

        public short DinCount { get; set; } // PIC S9(4) COMP

        // Collections for OCCURS
        public List<long> PinArray { get; set; } = new(); // N-PIN-ARRAY OCCURS 0 TO 500 TIMES

        public List<int> LinArray { get; set; } = new(); // N-LIN-ARRAY OCCURS 0 TO 200 TIMES

        public List<AuditDinReapply> DinReapply { get; set; } = new(); // N-DIN-REAPPLY OCCURS 0 TO 2200 TIMES
    }

    public class AuditDinReapply
    {
        public long Din { get; set; } // PIC S9(18) COMP

        public short SubjIdNb { get; set; } // PIC S9(4) COMP

        public short SubjIdSeqNb { get; set; } // PIC S9(4) COMP
    }
}