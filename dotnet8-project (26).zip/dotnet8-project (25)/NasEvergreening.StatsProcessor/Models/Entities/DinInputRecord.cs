using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("DinInputRecords")]
    public class DinInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public long Din { get; set; } // PIC S9(18) COMP

        public short SubjNb { get; set; } // PIC S9(4) COMP

        public short SubjSeqNb { get; set; } // PIC S9(4) COMP
    }
}