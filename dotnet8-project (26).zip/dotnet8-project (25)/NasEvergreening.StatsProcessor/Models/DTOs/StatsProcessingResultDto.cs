namespace NasEvergreening.StatsProcessor.Models.DTOs
{
    public class StatsProcessingResultDto
    {
        public bool Success { get; set; }

        public string Message { get; set; } = string.Empty;

        public int DinCount { get; set; }

        public int PinCount { get; set; }

        public int LinCount { get; set; }

        public int ErroredRecords { get; set; }
    }
}