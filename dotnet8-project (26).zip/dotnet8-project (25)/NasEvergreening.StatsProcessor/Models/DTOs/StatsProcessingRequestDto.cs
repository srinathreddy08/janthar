using System.ComponentModel.DataAnnotations;

namespace NasEvergreening.StatsProcessor.Models.DTOs
{
    public class StatsProcessingRequestDto
    {
        [Range(0, 9, ErrorMessage = "LoggingLevel must be between 0 and 9.")]
        public int LoggingLevel { get; set; }

        [Required]
        [RegularExpression("[UR]", ErrorMessage = "CallMode must be 'U' or 'R'.")]
        public char CallMode { get; set; }
    }
}