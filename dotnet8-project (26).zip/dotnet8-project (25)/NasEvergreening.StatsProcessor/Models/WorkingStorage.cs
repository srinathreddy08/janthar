namespace NasEvergreening.StatsProcessor.Models
{
    public class WorkingStorage
    {
        public int DinCount { get; set; }
        public int PinCount { get; set; }
        public int LinCount { get; set; }
        public int ErroredRec { get; set; }

        public bool EofAuditFile { get; set; } = false;
        public bool EofDinFile { get; set; } = false;

        public char CallMode { get; set; } = 'R'; // 'U' for update, 'R' for read

        public int LoggingLevel { get; set; } = 0;

        public long PrevDin { get; set; } = 0;

        public long DinNumeric { get; set; } = 0;

        public string DinAlphanumeric { get; set; } = string.Empty;
    }
}