using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using System.Text.Json;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class DinRepository : IDinRepository
    {
        private readonly ILogger<DinRepository> _logger;
        private readonly string _filePath;
        private StreamReader? _reader;
        private DinInputRecord? _currentRecord;

        public DinInputRecord? CurrentRecord => _currentRecord;

        public DinRepository(ILogger<DinRepository> logger, string filePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _filePath = filePath ?? throw new ArgumentNullException(nameof(filePath));
        }

        public async Task<bool> ReadNextAsync()
        {
            try
            {
                if (_reader == null)
                {
                    _reader = new StreamReader(_filePath);
                }

                var line = await _reader.ReadLineAsync();

                if (line == null)
                {
                    _currentRecord = null;
                    return false;
                }

                // Deserialize or parse line into DinInputRecord
                _currentRecord = JsonSerializer.Deserialize<DinInputRecord>(line);

                if (_currentRecord == null)
                {
                    _logger.LogWarning("Failed to parse DIN record line: {Line}", line);
                    return await ReadNextAsync(); // Skip invalid line
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error reading DIN file.");
                throw;
            }
        }

        public async Task CloseAsync()
        {
            if (_reader != null)
            {
                _reader.Dispose();
                _reader = null;
            }
        }
    }
}