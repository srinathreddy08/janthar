using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using System.Text.Json;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class AuditRepository : IAuditRepository
    {
        private readonly ILogger<AuditRepository> _logger;
        private readonly string _filePath;
        private StreamReader? _reader;
        private AuditInputRecord? _currentRecord;

        public AuditInputRecord? CurrentRecord => _currentRecord;

        public AuditRepository(ILogger<AuditRepository> logger, string filePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _filePath = filePath ?? throw new ArgumentNullException(nameof(filePath));
        }

        public async Task<bool> ReadNextAsync()
        {
            try
            {
                if (_reader == null)
                {
                    _reader = new StreamReader(_filePath);
                }

                var line = await _reader.ReadLineAsync();

                if (line == null)
                {
                    _currentRecord = null;
                    return false;
                }

                // Deserialize or parse line into AuditInputRecord
                // Assuming JSON lines for example; adjust parsing as per actual file format
                _currentRecord = JsonSerializer.Deserialize<AuditInputRecord>(line);

                if (_currentRecord == null)
                {
                    _logger.LogWarning("Failed to parse audit record line: {Line}", line);
                    return await ReadNextAsync(); // Skip invalid line
                }

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error reading audit file.");
                throw;
            }
        }

        public async Task CloseAsync()
        {
            if (_reader != null)
            {
                _reader.Dispose();
                _reader = null;
            }
        }
    }
}