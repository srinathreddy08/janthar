using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class ReapplyRepository : IReapplyRepository
    {
        private readonly ILogger<ReapplyRepository> _logger;
        private readonly string _filePath;
        private StreamWriter? _writer;

        public ReapplyRepository(ILogger<ReapplyRepository> logger, string filePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _filePath = filePath ?? throw new ArgumentNullException(nameof(filePath));
        }

        public async Task WriteAsync(ReapplyRecord record)
        {
            if (record == null) throw new ArgumentNullException(nameof(record));

            try
            {
                if (_writer == null)
                {
                    _writer = new StreamWriter(_filePath, append: true);
                }

                await _writer.WriteLineAsync(record.RecordData);
                await _writer.FlushAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing reapply record to file.");
                throw;
            }
        }

        public async Task CloseAsync()
        {
            if (_writer != null)
            {
                await _writer.DisposeAsync();
                _writer = null;
            }
        }
    }
}