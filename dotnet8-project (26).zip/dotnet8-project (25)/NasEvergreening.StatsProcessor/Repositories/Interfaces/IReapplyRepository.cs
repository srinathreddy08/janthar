using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IReapplyRepository
    {
        Task WriteAsync(ReapplyRecord record);

        Task CloseAsync();
    }
}