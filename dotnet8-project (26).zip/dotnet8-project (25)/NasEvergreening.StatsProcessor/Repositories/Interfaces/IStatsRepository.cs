using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IStatsRepository
    {
        Task ReadStatsAsync();

        Task WriteOrUpdateStatsAsync(StatsRecord statsRecord);

        Task WriteStatsDetailAsync(StatsDetailRecord detailRecord);

        Task CloseAsync();
    }
}