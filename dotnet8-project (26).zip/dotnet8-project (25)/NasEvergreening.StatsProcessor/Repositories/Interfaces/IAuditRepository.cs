using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IAuditRepository
    {
        AuditInputRecord? CurrentRecord { get; }

        Task<bool> ReadNextAsync();

        Task CloseAsync();
    }
}