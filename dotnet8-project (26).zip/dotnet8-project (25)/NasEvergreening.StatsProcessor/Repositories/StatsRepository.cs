using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using System.Text.Json;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class StatsRepository : IStatsRepository
    {
        private readonly ILogger<StatsRepository> _logger;
        private readonly string _statsFilePath;
        private readonly string _statsDetailFilePath;

        public StatsRepository(ILogger<StatsRepository> logger, string statsFilePath, string statsDetailFilePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _statsFilePath = statsFilePath ?? throw new ArgumentNullException(nameof(statsFilePath));
            _statsDetailFilePath = statsDetailFilePath ?? throw new ArgumentNullException(nameof(statsDetailFilePath));
        }

        public async Task ReadStatsAsync()
        {
            // For file-based implementation, reading stats file can be implemented if needed
            // For now, assume stats file is empty or initialized
            _logger.LogInformation("Reading stats file is not implemented; assuming empty stats.");
            await Task.CompletedTask;
        }

        public async Task WriteOrUpdateStatsAsync(StatsRecord statsRecord)
        {
            if (statsRecord == null) throw new ArgumentNullException(nameof(statsRecord));

            try
            {
                var json = JsonSerializer.Serialize(statsRecord);
                await File.WriteAllTextAsync(_statsFilePath, json);
                _logger.LogInformation("Stats record written to file.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing stats record to file.");
                throw;
            }
        }

        public async Task WriteStatsDetailAsync(StatsDetailRecord detailRecord)
        {
            if (detailRecord == null) throw new ArgumentNullException(nameof(detailRecord));

            try
            {
                var json = JsonSerializer.Serialize(detailRecord);
                await File.AppendAllTextAsync(_statsDetailFilePath, json + Environment.NewLine);
                _logger.LogDebug("Stats detail record appended to file.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error writing stats detail record to file.");
                throw;
            }
        }

        public async Task CloseAsync()
        {
            // No resources to dispose for file-based implementation
            await Task.CompletedTask;
        }
    }
}