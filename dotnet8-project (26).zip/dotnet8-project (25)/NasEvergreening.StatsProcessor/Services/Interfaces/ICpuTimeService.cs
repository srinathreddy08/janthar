using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Services.Interfaces
{
    public interface ICpuTimeService
    {
        Task InitializeAsync();

        Task<long> GetCpuTimeAsync();

        Task<long> GetElapsedTimeAsync();
    }
}