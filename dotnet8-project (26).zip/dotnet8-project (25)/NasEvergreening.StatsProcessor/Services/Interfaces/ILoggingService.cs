using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Services.Interfaces
{
    public interface ILoggingService
    {
        Task LogInfoAsync(string message);

        Task LogErrorAsync(string message);

        Task LogAbendAsync(string section, string errorMessage, int errorCode);
    }
}