using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using NasEvergreening.StatsProcessor.Models;
using System.Collections.Generic;
using System.Linq;

namespace NasEvergreening.StatsProcessor.Services
{
    public class StatsProcessingService : IStatsProcessingService
    {
        private readonly IAuditRepository _auditRepository;
        private readonly IDinRepository _dinRepository;
        private readonly IStatsRepository _statsRepository;
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ILoggingService _loggingService;
        private readonly ICpuTimeService _cpuTimeService;
        private readonly ILogger<StatsProcessingService> _logger;

        public StatsProcessingService(
            IAuditRepository auditRepository,
            IDinRepository dinRepository,
            IStatsRepository statsRepository,
            IReapplyRepository reapplyRepository,
            ILoggingService loggingService,
            ICpuTimeService cpuTimeService,
            ILogger<StatsProcessingService> logger)
        {
            _auditRepository = auditRepository ?? throw new ArgumentNullException(nameof(auditRepository));
            _dinRepository = dinRepository ?? throw new ArgumentNullException(nameof(dinRepository));
            _statsRepository = statsRepository ?? throw new ArgumentNullException(nameof(statsRepository));
            _reapplyRepository = reapplyRepository ?? throw new ArgumentNullException(nameof(reapplyRepository));
            _loggingService = loggingService ?? throw new ArgumentNullException(nameof(loggingService));
            _cpuTimeService = cpuTimeService ?? throw new ArgumentNullException(nameof(cpuTimeService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<StatsProcessingResultDto> ProcessStatsAsync(StatsProcessingRequestDto request)
        {
            _logger.LogInformation("Starting stats processing with LoggingLevel={LoggingLevel} and CallMode={CallMode}", request.LoggingLevel, request.CallMode);

            if (request == null)
                throw new ArgumentNullException(nameof(request), "Request cannot be null.");

            if (request.LoggingLevel < 0 || request.LoggingLevel > 9)
                throw new ArgumentOutOfRangeException(nameof(request.LoggingLevel), "LoggingLevel must be between 0 and 9.");

            if (request.CallMode != 'U' && request.CallMode != 'R')
                throw new ArgumentException("CallMode must be 'U' (Update) or 'R' (Read).", nameof(request.CallMode));

            var workingStorage = new WorkingStorage
            {
                LoggingLevel = request.LoggingLevel,
                CallMode = request.CallMode
            };

            try
            {
                // Log entering program
                if (workingStorage.LoggingLevel > 1)
                {
                    await _loggingService.LogInfoAsync("ENTERING PROGRAM EDBNAECE");
                }

                // Initialization
                await InitializeAsync(workingStorage);

                // Main processing
                await ProcessAuditFileAsync(workingStorage);
                await ProcessDinFileAsync(workingStorage);

                // Termination
                await TerminationAsync(workingStorage);

                if (workingStorage.LoggingLevel > 1)
                {
                    await _loggingService.LogInfoAsync("EXITING PROGRAM EDBNAECE");
                }

                return new StatsProcessingResultDto
                {
                    Success = true,
                    Message = "Stats processing completed successfully.",
                    DinCount = workingStorage.DinCount,
                    PinCount = workingStorage.PinCount,
                    LinCount = workingStorage.LinCount,
                    ErroredRecords = workingStorage.ErroredRec
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during stats processing.");
                await _loggingService.LogErrorAsync($"Error in EDBNAECE: {ex.Message}");
                throw;
            }
        }

        private async Task InitializeAsync(WorkingStorage ws)
        {
            _logger.LogDebug("Initializing working storage and reading initial data.");

            ws.DinCount = 0;
            ws.PinCount = 0;
            ws.LinCount = 0;
            ws.ErroredRec = 0;
            ws.EofAuditFile = false;
            ws.EofDinFile = false;
            ws.PrevDin = 0;
            ws.DinNumeric = 0;
            ws.DinAlphanumeric = string.Empty;

            // Initialize CPU and elapsed time
            await _cpuTimeService.InitializeAsync();

            // Read first audit record
            ws.EofAuditFile = !await _auditRepository.ReadNextAsync();

            // Read first stats record (if needed)
            await _statsRepository.ReadStatsAsync();

            // Read first DIN record
            ws.EofDinFile = !await _dinRepository.ReadNextAsync();

            _logger.LogDebug("Initialization complete. EOF Audit: {EofAudit}, EOF DIN: {EofDin}", ws.EofAuditFile, ws.EofDinFile);
        }

        private async Task ProcessAuditFileAsync(WorkingStorage ws)
        {
            _logger.LogInformation("Processing audit file records.");

            while (!ws.EofAuditFile)
            {
                var auditRecord = _auditRepository.CurrentRecord;

                if (auditRecord == null)
                {
                    ws.EofAuditFile = true;
                    break;
                }

                // Business logic: accumulate counts based on audit record flags
                if (IsAuditError(auditRecord))
                {
                    ws.ErroredRec += 1;
                }
                else if (IsAuditProcessed(auditRecord))
                {
                    ws.PinCount += auditRecord.PinCount;
                    ws.LinCount += auditRecord.NonStdLinCount;
                }

                // Read next audit record
                ws.EofAuditFile = !await _auditRepository.ReadNextAsync();
            }

            _logger.LogInformation("Completed processing audit file. Errored records: {ErroredRec}, PinCount: {PinCount}, LinCount: {LinCount}", ws.ErroredRec, ws.PinCount, ws.LinCount);
        }

        private bool IsAuditError(Models.Entities.AuditInputRecord record)
        {
            // COBOL logic: WHEN AUD-ERROR
            // AUD-ERROR is when N-PROCESS-STG = 'E'
            return record.ProcessStg == "E";
        }

        private bool IsAuditProcessed(Models.Entities.AuditInputRecord record)
        {
            // COBOL logic: WHEN AUD-PROCESSED
            // AUD-PROCESSED is when N-PROCESS-STG = 'P'
            return record.ProcessStg == "P";
        }

        private async Task ProcessDinFileAsync(WorkingStorage ws)
        {
            _logger.LogInformation("Processing DIN file records.");

            while (!ws.EofDinFile)
            {
                var dinRecord = _dinRepository.CurrentRecord;

                if (dinRecord == null)
                {
                    ws.EofDinFile = true;
                    break;
                }

                // Prepare reapply record
                var reapplyRecord = new Models.Entities.ReapplyRecord
                {
                    RecordData = FormatReapplyRecord(dinRecord)
                };

                // Write reapply record if in update mode
                if (ws.CallMode == 'U')
                {
                    await _reapplyRepository.WriteAsync(reapplyRecord);
                }

                ws.DinCount += 1;

                // Read next DIN record
                ws.EofDinFile = !await _dinRepository.ReadNextAsync();
            }

            _logger.LogInformation("Completed processing DIN file. DIN count: {DinCount}", ws.DinCount);
        }

        private string FormatReapplyRecord(Models.Entities.DinInputRecord dinRecord)
        {
            // Format the reapply record string as per COBOL logic
            // For simplicity, concatenate DIN, SubjNb, SubjSeqNb with padding
            return string.Format("{0,-18}{1,-4}{2,-4}", dinRecord.Din, dinRecord.SubjNb, dinRecord.SubjSeqNb);
        }

        private async Task TerminationAsync(WorkingStorage ws)
        {
            _logger.LogInformation("Starting termination processing.");

            // Close files handled by repositories if needed
            await _auditRepository.CloseAsync();
            await _dinRepository.CloseAsync();
            await _reapplyRepository.CloseAsync();

            // Populate stats record
            var statsRecord = new Models.Entities.StatsRecord
            {
                ReapplyDinCount = ws.DinCount,
                PinCount = ws.PinCount,
                LinDeleted = ws.LinCount,
                TotalExistErrorRec = ws.ErroredRec,
                CpuTime = await _cpuTimeService.GetCpuTimeAsync(),
                ElapsedTime = await _cpuTimeService.GetElapsedTimeAsync(),
                TotalTimeCpu = 0, // Could accumulate if multiple runs
                TotalTimeElapsed = 0,
                CreatedDate = DateTime.UtcNow
            };

            await _statsRepository.WriteOrUpdateStatsAsync(statsRecord);

            // Write detailed stats
            var detailRecords = GenerateStatsDetailRecords(statsRecord);
            foreach (var detail in detailRecords)
            {
                await _statsRepository.WriteStatsDetailAsync(detail);
            }

            _logger.LogInformation("Termination processing completed.");
        }

        private IEnumerable<Models.Entities.StatsDetailRecord> GenerateStatsDetailRecords(Models.Entities.StatsRecord stats)
        {
            // Map COBOL WC-HEADERs and stats fields to detail records
            var details = new List<Models.Entities.StatsDetailRecord>
            {
                new Models.Entities.StatsDetailRecord { Header = "NUMBER OF LOW QUALITY INPUT RECORDS  :", Details = stats.LinDeleted.ToString() },
                new Models.Entities.StatsDetailRecord { Header = "NUMBER OF TEXT QUALITY INPUT RECORDS :", Details = stats.PinCount.ToString() },
                new Models.Entities.StatsDetailRecord { Header = "NUMBER OF ERRORED RECORDS            :", Details = stats.TotalExistErrorRec.ToString() },
                new Models.Entities.StatsDetailRecord { Header = "TOTAL NUMBER OF INPUT RECORDS        :", Details = (stats.ReapplyDinCount + stats.PinCount + stats.LinDeleted).ToString() },
                new Models.Entities.StatsDetailRecord { Header = "NUMBER OF PINS IMPACTED              :", Details = stats.PinCount.ToString() },
                new Models.Entities.StatsDetailRecord { Header = "NUMBER OF DINS SENT TO REAPPLY       :", Details = stats.ReapplyDinCount.ToString() },
                new Models.Entities.StatsDetailRecord { Header = "NUMBER OF LINS DELETED               :", Details = stats.LinDeleted.ToString() },
                new Models.Entities.StatsDetailRecord { Header = "TOTAL CPU TIME                       :", Details = stats.CpuTime.ToString() },
                new Models.Entities.StatsDetailRecord { Header = "TOTAL ELAPSED TIME                   :", Details = stats.ElapsedTime.ToString() }
            };

            return details;
        }
    }
}