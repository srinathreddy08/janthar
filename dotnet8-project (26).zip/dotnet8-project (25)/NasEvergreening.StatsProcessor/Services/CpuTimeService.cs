using System;
using System.Diagnostics;
using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Services
{
    public class CpuTimeService : ICpuTimeService
    {
        private Stopwatch? _cpuStopwatch;
        private Stopwatch? _elapsedStopwatch;

        public Task InitializeAsync()
        {
            _cpuStopwatch = Stopwatch.StartNew();
            _elapsedStopwatch = Stopwatch.StartNew();
            return Task.CompletedTask;
        }

        public Task<long> GetCpuTimeAsync()
        {
            if (_cpuStopwatch == null)
                throw new InvalidOperationException("CPU timer not initialized.");

            // Return CPU time in milliseconds
            return Task.FromResult(_cpuStopwatch.ElapsedMilliseconds);
        }

        public Task<long> GetElapsedTimeAsync()
        {
            if (_elapsedStopwatch == null)
                throw new InvalidOperationException("Elapsed timer not initialized.");

            // Return elapsed time in milliseconds
            return Task.FromResult(_elapsedStopwatch.ElapsedMilliseconds);
        }
    }
}