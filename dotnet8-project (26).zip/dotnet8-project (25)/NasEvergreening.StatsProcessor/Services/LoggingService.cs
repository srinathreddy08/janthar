using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Services
{
    public class LoggingService : ILoggingService
    {
        private readonly ILogger<LoggingService> _logger;

        public LoggingService(ILogger<LoggingService> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public Task LogInfoAsync(string message)
        {
            _logger.LogInformation(message);
            return Task.CompletedTask;
        }

        public Task LogErrorAsync(string message)
        {
            _logger.LogError(message);
            return Task.CompletedTask;
        }

        public Task LogAbendAsync(string section, string errorMessage, int errorCode)
        {
            _logger.LogCritical("ABEND in section {Section} with error code {ErrorCode}: {ErrorMessage}", section, errorCode, errorMessage);
            // Additional abend handling logic can be added here
            return Task.CompletedTask;
        }
    }
}