using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using NasEvergreening.StatsProcessor.Data;
using NasEvergreening.StatsProcessor.Repositories;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using NasEvergreening.StatsProcessor.Services;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Configuration
var configuration = builder.Configuration;

// Validate required file paths
string auditFilePath = configuration["FilePaths:AuditInputFile"] 
    ?? throw new InvalidOperationException("Missing AuditInputFile path in configuration.");
string dinFilePath = configuration["FilePaths:DinInputFile"] 
    ?? throw new InvalidOperationException("Missing DinInputFile path in configuration.");
string statsFilePath = configuration["FilePaths:StatsFile"] 
    ?? throw new InvalidOperationException("Missing StatsFile path in configuration.");
string statsDetailFilePath = configuration["FilePaths:StatsDetailFile"] 
    ?? throw new InvalidOperationException("Missing StatsDetailFile path in configuration.");
string reapplyFilePath = configuration["FilePaths:ReapplyFile"] 
    ?? throw new InvalidOperationException("Missing ReapplyFile path in configuration.");

// Add services to the container
builder.Services.AddControllers();

// Configure DbContext
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(configuration.GetConnectionString("DefaultConnection"),
        new MySqlServerVersion(new Version(8, 0, 33))));

// Register repositories
builder.Services.AddScoped<IAuditRepository, AuditRepository>(sp =>
    new AuditRepository(sp.GetRequiredService<ILogger<AuditRepository>>(), auditFilePath));

builder.Services.AddScoped<IDinRepository, DinRepository>(sp =>
    new DinRepository(sp.GetRequiredService<ILogger<DinRepository>>(), dinFilePath));

builder.Services.AddScoped<IStatsRepository, StatsRepository>(sp =>
    new StatsRepository(sp.GetRequiredService<ILogger<StatsRepository>>(), statsFilePath, statsDetailFilePath));

builder.Services.AddScoped<IReapplyRepository, ReapplyRepository>(sp =>
    new ReapplyRepository(sp.GetRequiredService<ILogger<ReapplyRepository>>(), reapplyFilePath));

// Register services
builder.Services.AddScoped<IStatsProcessingService, StatsProcessingService>();
builder.Services.AddScoped<ILoggingService, LoggingService>();
builder.Services.AddScoped<ICpuTimeService, CpuTimeService>();

// Configure Authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = configuration["Jwt:Authority"];
        options.Audience = configuration["Jwt:Audience"];
    });

// Add Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "NasEvergreening StatsProcessor API", Version = "v1" });
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
