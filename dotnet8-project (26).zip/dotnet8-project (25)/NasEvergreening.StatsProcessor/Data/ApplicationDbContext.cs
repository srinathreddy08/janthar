using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AuditInputRecord> AuditInputRecords { get; set; } = null!;
        public DbSet<DinInputRecord> DinInputRecords { get; set; } = null!;
        public DbSet<StatsRecord> StatsRecords { get; set; } = null!;
        public DbSet<StatsDetailRecord> StatsDetailRecords { get; set; } = null!;
        public DbSet<ReapplyRecord> ReapplyRecords { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure AuditInputRecord
            modelBuilder.Entity<AuditInputRecord>(entity =>
            {
                entity.ToTable("AuditInputRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ProcStartDate).HasMaxLength(8).IsRequired();
                entity.Property(e => e.ProcStartTime).HasMaxLength(4).IsRequired();
                entity.Property(e => e.SrcName).HasMaxLength(440);
                entity.Property(e => e.SrcAddr).HasMaxLength(440);
                entity.Property(e => e.SrcNm).HasMaxLength(150);
                entity.Property(e => e.AddrLine1).HasMaxLength(60);
                entity.Property(e => e.AddrLine2).HasMaxLength(60);
                entity.Property(e => e.AddrLine3).HasMaxLength(60);
                entity.Property(e => e.AddrLine4).HasMaxLength(60);
                entity.Property(e => e.AddrLine5).HasMaxLength(60);
                entity.Property(e => e.AddrLine6).HasMaxLength(112);
                entity.Property(e => e.AddrLine7).HasMaxLength(8);
                entity.Property(e => e.AddrQty).HasMaxLength(1);
                entity.Property(e => e.SrcAddrFrmtCd).HasMaxLength(2);
                entity.Property(e => e.AinChangeFlag).HasMaxLength(1);
                entity.Property(e => e.DinFoundFlag).HasMaxLength(1);
                entity.Property(e => e.ErrorCode).HasMaxLength(4);
                entity.Property(e => e.ProcessStg).HasMaxLength(1);
                entity.Property(e => e.FieldIndicator).HasMaxLength(1);
                entity.Property(e => e.DataProvider).HasMaxLength(5);

                // Configure collections as owned entities or separate tables if needed
            });

            // Configure other entities similarly

            modelBuilder.Entity<DinInputRecord>(entity =>
            {
                entity.ToTable("DinInputRecords");
                entity.HasKey(e => e.Id);
            });

            modelBuilder.Entity<StatsRecord>(entity =>
            {
                entity.ToTable("StatsRecords");
                entity.HasKey(e => e.Id);
            });

            modelBuilder.Entity<StatsDetailRecord>(entity =>
            {
                entity.ToTable("StatsDetailRecords");
                entity.HasKey(e => e.Id);
            });

            modelBuilder.Entity<ReapplyRecord>(entity =>
            {
                entity.ToTable("ReapplyRecords");
                entity.HasKey(e => e.Id);
            });
        }
    }
}