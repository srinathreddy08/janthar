using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreening.StatsProcessor.Controllers;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using Xunit;

namespace NasEvergreening.StatsProcessor.Tests.Controllers
{
    public class StatsControllerTests
    {
        private readonly Mock<IStatsProcessingService> _mockStatsProcessingService;
        private readonly Mock<ILogger<StatsController>> _mockLogger;
        private readonly StatsController _controller;

        public StatsControllerTests()
        {
            _mockStatsProcessingService = new Mock<IStatsProcessingService>();
            _mockLogger = new Mock<ILogger<StatsController>>();
            _controller = new StatsController(_mockStatsProcessingService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessStats_ValidRequest_ReturnsOkResultWithSuccess()
        {
            // Arrange
            var request = new StatsProcessingRequestDto { CallMode = 'U', LoggingLevel = 1 };
            var expectedResult = new StatsProcessingResultDto { Success = true, Message = "Success", StatsRecordId = 123 };

            _mockStatsProcessingService
                .Setup(s => s.ProcessStatsAsync(request))
                .ReturnsAsync(expectedResult);

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<StatsProcessingResultDto>(okResult.Value);
            Assert.True(returnValue.Success);
            Assert.Equal(expectedResult.Message, returnValue.Message);
            Assert.Equal(expectedResult.StatsRecordId, returnValue.StatsRecordId);

            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Received request to process stats")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task ProcessStats_InvalidModelState_ReturnsBadRequest()
        {
            // Arrange
            _controller.ModelState.AddModelError("CallMode", "Required");
            var request = new StatsProcessingRequestDto();

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<SerializableError>(badRequestResult.Value);

            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Warning,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Invalid model state")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task ProcessStats_ServiceReturnsFailure_ReturnsStatusCode500WithMessage()
        {
            // Arrange
            var request = new StatsProcessingRequestDto { CallMode = 'R', LoggingLevel = 0 };
            var failureResult = new StatsProcessingResultDto { Success = false, Message = "Failure occurred" };

            _mockStatsProcessingService
                .Setup(s => s.ProcessStatsAsync(request))
                .ReturnsAsync(failureResult);

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal(failureResult.Message, objectResult.Value);

            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Warning,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Stats processing failed")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task ProcessStats_ServiceThrowsArgumentException_ReturnsBadRequestWithMessage()
        {
            // Arrange
            var request = new StatsProcessingRequestDto { CallMode = 'U', LoggingLevel = 1 };
            var exceptionMessage = "Invalid argument";

            _mockStatsProcessingService
                .Setup(s => s.ProcessStatsAsync(request))
                .ThrowsAsync(new ArgumentException(exceptionMessage));

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(exceptionMessage, badRequestResult.Value);

            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Argument exception")),
                    It.IsAny<ArgumentException>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }

        [Fact]
        public async Task ProcessStats_ServiceThrowsGeneralException_ReturnsStatusCode500WithGenericMessage()
        {
            // Arrange
            var request = new StatsProcessingRequestDto { CallMode = 'R', LoggingLevel = 0 };

            _mockStatsProcessingService
                .Setup(s => s.ProcessStatsAsync(request))
                .ThrowsAsync(new Exception("Unexpected error"));

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal("An unexpected error occurred while processing statistics.", objectResult.Value);

            _mockLogger.Verify(
                x => x.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Unexpected error")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once);
        }

        [Fact]
        public void Constructor_NullStatsProcessingService_ThrowsArgumentNullException()
        {
            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new StatsController(null, _mockLogger.Object));
        }

        [Fact]
        public void Constructor_NullLogger_ThrowsArgumentNullException()
        {
            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new StatsController(_mockStatsProcessingService.Object, null));
        }
    }
}
