using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatsController : ControllerBase
    {
        private readonly IStatsProcessingService _statsProcessingService;
        private readonly ILogger<StatsController> _logger;

        public StatsController(IStatsProcessingService statsProcessingService, ILogger<StatsController> logger)
        {
            _statsProcessingService = statsProcessingService ?? throw new ArgumentNullException(nameof(statsProcessingService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessStats([FromBody] StatsProcessingRequestDto request)
        {
            _logger.LogInformation("Received request to process stats with call mode: {CallMode} and logging level: {LoggingLevel}", request.CallMode, request.LoggingLevel);

            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid model state for ProcessStats request.");
                return BadRequest(ModelState);
            }

            try
            {
                var result = await _statsProcessingService.ProcessStatsAsync(request);

                if (result.Success)
                {
                    return Ok(result);
                }
                else
                {
                    _logger.LogWarning("Stats processing failed: {Message}", result.Message);
                    return StatusCode(500, result.Message);
                }
            }
            catch (ArgumentException argEx)
            {
                _logger.LogError(argEx, "Argument exception during stats processing.");
                return BadRequest(argEx.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during stats processing.");
                return StatusCode(500, "An unexpected error occurred while processing statistics.");
            }
        }
    }
}