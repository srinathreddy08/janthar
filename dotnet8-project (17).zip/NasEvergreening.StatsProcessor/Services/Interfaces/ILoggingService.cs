using System;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Services.Interfaces
{
    public interface ILoggingService
    {
        Task LogInformationAsync(string message, params object[] args);
        Task LogErrorAsync(Exception exception, string message, params object[] args);
    }
}