using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.DTOs;

namespace NasEvergreening.StatsProcessor.Services.Interfaces
{
    public interface ITimeMeasurementService
    {
        void StartMeasurement();
        TimingResultDto StopMeasurement();
    }
}