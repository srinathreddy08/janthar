using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.DTOs;

namespace NasEvergreening.StatsProcessor.Services.Interfaces
{
    public interface IStatsProcessingService
    {
        Task<StatsProcessingResultDto> ProcessStatsAsync(StatsProcessingRequestDto request);
    }
}