using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Services
{
    public class LoggingService : ILoggingService
    {
        private readonly ILogger<LoggingService> _logger;

        public LoggingService(ILogger<LoggingService> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public Task LogInformationAsync(string message, params object[] args)
        {
            _logger.LogInformation(message, args);
            return Task.CompletedTask;
        }

        public Task LogErrorAsync(Exception exception, string message, params object[] args)
        {
            _logger.LogError(exception, message, args);
            return Task.CompletedTask;
        }
    }
}