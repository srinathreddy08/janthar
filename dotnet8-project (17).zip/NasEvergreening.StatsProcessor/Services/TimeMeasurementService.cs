using System;
using System.Diagnostics;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Services
{
    public class TimeMeasurementService : ITimeMeasurementService
    {
        private Stopwatch _stopwatch = new Stopwatch();

        public void StartMeasurement()
        {
            _stopwatch.Restart();
        }

        public TimingResultDto StopMeasurement()
        {
            _stopwatch.Stop();

            // For CPU time, we simulate with elapsed milliseconds as placeholder
            // In production, use PerformanceCounter or Process.TotalProcessorTime
            return new TimingResultDto
            {
                CpuTime = _stopwatch.ElapsedMilliseconds,
                ElapsedTime = _stopwatch.ElapsedMilliseconds
            };
        }
    }
}