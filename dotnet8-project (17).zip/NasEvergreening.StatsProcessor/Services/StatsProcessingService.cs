using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using NasEvergreening.StatsProcessor.Models;
using System.Collections.Generic;
using System.Linq;

namespace NasEvergreening.StatsProcessor.Services
{
    public class StatsProcessingService : IStatsProcessingService
    {
        private readonly IStatsRepository _statsRepository;
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ILoggingService _loggingService;
        private readonly ITimeMeasurementService _timeMeasurementService;
        private readonly ILogger<StatsProcessingService> _logger;

        public StatsProcessingService(
            IStatsRepository statsRepository,
            IReapplyRepository reapplyRepository,
            ILoggingService loggingService,
            ITimeMeasurementService timeMeasurementService,
            ILogger<StatsProcessingService> logger)
        {
            _statsRepository = statsRepository ?? throw new ArgumentNullException(nameof(statsRepository));
            _reapplyRepository = reapplyRepository ?? throw new ArgumentNullException(nameof(reapplyRepository));
            _loggingService = loggingService ?? throw new ArgumentNullException(nameof(loggingService));
            _timeMeasurementService = timeMeasurementService ?? throw new ArgumentNullException(nameof(timeMeasurementService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<StatsProcessingResultDto> ProcessStatsAsync(StatsProcessingRequestDto request)
        {
            _logger.LogInformation("Starting stats processing with call mode: {CallMode} and logging level: {LoggingLevel}", request.CallMode, request.LoggingLevel);

            if (request == null)
                throw new ArgumentNullException(nameof(request), "Request cannot be null.");

            if (request.CallMode != 'U' && request.CallMode != 'R')
                throw new ArgumentException("Invalid call mode. Allowed values are 'U' (Update) or 'R' (Read).", nameof(request.CallMode));

            if (request.LoggingLevel < 0)
                throw new ArgumentException("Logging level must be non-negative.", nameof(request.LoggingLevel));

            var workingStorage = new WorkingStorage
            {
                CallMode = request.CallMode,
                LoggingLevel = request.LoggingLevel
            };

            try
            {
                // Initialize CPU and elapsed time measurement
                _timeMeasurementService.StartMeasurement();

                // Initialize accumulators
                workingStorage.DinCount = 0;
                workingStorage.PinCount = 0;
                workingStorage.LinCount = 0;
                workingStorage.ErroredRecords = 0;

                // Read audit records and process
                await foreach (var auditRecord in _statsRepository.GetAuditRecordsAsync())
                {
                    if (auditRecord == null)
                        continue;

                    if (auditRecord.IsError)
                    {
                        workingStorage.ErroredRecords += 1;
                    }
                    else if (auditRecord.IsProcessed)
                    {
                        workingStorage.PinCount += auditRecord.PinCount;
                        workingStorage.LinCount += auditRecord.NonStdLinCount;
                    }
                }

                // Read DIN input records and process
                await foreach (var dinRecord in _reapplyRepository.GetDinInputRecordsAsync())
                {
                    if (dinRecord == null)
                        continue;

                    workingStorage.PrevDin = dinRecord.Din;

                    // Compose Reapply record
                    var reapplyRecord = new Models.Entities.ReapplyRecord
                    {
                        Din = dinRecord.Din,
                        SrcProcess = ExtractSrcProcessFromDin(dinRecord.Din),
                        RunDate = DateTime.UtcNow.Date,
                        NoOfSubj = 1,
                        SubjNb = new List<int> { dinRecord.SubjNb },
                        SubjSeq = new List<int> { dinRecord.SubjSeqNb },
                        CreatedDate = DateTime.UtcNow,
                        CreatedBy = "System"
                    };

                    // Business rule: If SrcProcess is 80, 60, 70, or 50, add second subject
                    if (new[] { 80, 60, 70, 50 }.Contains(Convert.ToInt32(reapplyRecord.SrcProcess)))
                    {
                        reapplyRecord.NoOfSubj = 2;
                        reapplyRecord.SubjNb.Add(2); // Assuming 2 as second subject number
                        reapplyRecord.SubjSeq.Add(reapplyRecord.SubjSeq[0]);
                    }

                    if (workingStorage.CallMode == 'U')
                    {
                        await _reapplyRepository.AddReapplyRecordAsync(reapplyRecord);
                    }

                    workingStorage.DinCount += 1;
                }

                // Stop CPU and elapsed time measurement
                var timing = _timeMeasurementService.StopMeasurement();

                // Populate stats record
                var statsRecord = new Models.Entities.StatsRecord
                {
                    ReapplyDinCount = workingStorage.DinCount,
                    PinCount = workingStorage.PinCount,
                    LinDeleted = workingStorage.LinCount,
                    TotalExistErrorRec = workingStorage.ErroredRecords,
                    CpuTime = timing.CpuTime,
                    ElapsedTime = timing.ElapsedTime,
                    TotalCpuTime = timing.CpuTime, // Assuming cumulative
                    TotalElapsedTime = timing.ElapsedTime, // Assuming cumulative
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "System"
                };

                await _statsRepository.SaveStatsRecordAsync(statsRecord);

                // Generate detailed stats display records
                var detailRecords = GenerateStatsDetailRecords(statsRecord);
                await _statsRepository.SaveStatsDetailRecordsAsync(detailRecords);

                _logger.LogInformation("Stats processing completed successfully.");

                return new StatsProcessingResultDto
                {
                    Success = true,
                    Message = "Statistics processed successfully.",
                    StatsRecordId = statsRecord.Id
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during stats processing.");
                throw;
            }
        }

        private string ExtractSrcProcessFromDin(long din)
        {
            // Extract substring from DIN as per COBOL WS-DIN-APLHANUM(7:4)
            // Assuming DIN is numeric, convert to string with padding
            var dinStr = din.ToString().PadLeft(19, '0');
            if (dinStr.Length < 10) return "00";
            return dinStr.Substring(6, 4); // 7th to 10th character (0-based index 6)
        }

        private List<Models.Entities.StatsDetailRecord> GenerateStatsDetailRecords(Models.Entities.StatsRecord statsRecord)
        {
            var details = new List<Models.Entities.StatsDetailRecord>();

            var headers = new[]
            {
                "NUMBER OF LOW QUALITY INPUT RECORDS  :",
                "NUMBER OF TEXT QUALITY INPUT RECORDS :",
                "NUMBER OF ERRORED RECORDS            :",
                "TOTAL NUMBER OF INPUT RECORDS        :",
                "NO OF RECORDS WITH AIN AND QLTY UNCHG:",
                "NO OF TEXT TO LQ RECORD WITH SAME AIN:",
                "NO OF LQ TO HQ RECORDS WITH UNCHG AIN:",
                "NO OF RECORDS WITH CHNG AIN SAME QLTY:",
                "NO OF TEXT TO LQ RECORD WITH CHNG AIN:",
                "NO OF LQ TO HQ RECORDS WITH CHNGD AIN:",
                "NUMBER OF PINS IMPACTED              :",
                "NUMBER OF DINS SENT TO REAPPLY       :",
                "NUMBER OF LINS DELETED               :",
                "TOTAL CPU TIME                       :",
                "TOTAL ELAPSED TIME                   :",
                "NO OF TEXT TO HQ RECORD WITH CHNG AIN:"
            };

            var values = new[]
            {
                "0", // Placeholder for LQ REC
                "0", // Placeholder for TXT REC
                statsRecord.TotalExistErrorRec.ToString(),
                (statsRecord.ReapplyDinCount + statsRecord.PinCount + statsRecord.LinDeleted).ToString(),
                "0", // Placeholder for UNCHNGD ADDR
                "0", // Placeholder for TXT LQ AIN UNCHG
                "0", // Placeholder for LQ HQ AIN UNCHG
                "0", // Placeholder for UNCHG LQ AIN CHGD
                "0", // Placeholder for TXT LQ AIN CHG
                "0", // Placeholder for LQ HQ AIN CHG
                statsRecord.PinCount.ToString(),
                statsRecord.ReapplyDinCount.ToString(),
                statsRecord.LinDeleted.ToString(),
                statsRecord.CpuTime.ToString(),
                statsRecord.ElapsedTime.ToString(),
                "0" // Placeholder for TXT HQ AIN CHG
            };

            for (int i = 0; i < headers.Length; i++)
            {
                details.Add(new Models.Entities.StatsDetailRecord
                {
                    Header = headers[i],
                    Details = values[i],
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "System"
                });
            }

            return details;
        }
    }
}