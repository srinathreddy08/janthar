using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.BatchJobs
{
    public class StatsProcessingBackgroundService : BackgroundService
    {
        private readonly IStatsProcessingService _statsProcessingService;
        private readonly ILogger<StatsProcessingBackgroundService> _logger;

        public StatsProcessingBackgroundService(IStatsProcessingService statsProcessingService, ILogger<StatsProcessingBackgroundService> logger)
        {
            _statsProcessingService = statsProcessingService ?? throw new ArgumentNullException(nameof(statsProcessingService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("StatsProcessingBackgroundService is starting.");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    var request = new StatsProcessingRequestDto
                    {
                        CallMode = 'U', // Or configurable
                        LoggingLevel = 2
                    };

                    _logger.LogInformation("Background service starting stats processing.");

                    var result = await _statsProcessingService.ProcessStatsAsync(request);

                    if (result.Success)
                    {
                        _logger.LogInformation("Background stats processing completed successfully.");
                    }
                    else
                    {
                        _logger.LogWarning("Background stats processing failed: {Message}", result.Message);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error occurred in background stats processing.");
                }

                // Wait for configured interval before next run
                await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
            }

            _logger.LogInformation("StatsProcessingBackgroundService is stopping.");
        }
    }
}