using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Data;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class ReapplyRepository : IReapplyRepository
    {
        private readonly ApplicationDbContext _context;

        public ReapplyRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async IAsyncEnumerable<DinInputRecord> GetDinInputRecordsAsync()
        {
            await foreach (var record in _context.DinInputRecords.AsNoTracking().AsAsyncEnumerable())
            {
                yield return record;
            }
        }

        public async Task AddReapplyRecordAsync(ReapplyRecord reapplyRecord)
        {
            if (reapplyRecord == null) throw new System.ArgumentNullException(nameof(reapplyRecord));

            await _context.ReapplyRecords.AddAsync(reapplyRecord);
            await _context.SaveChangesAsync();
        }
    }
}