using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IStatsRepository
    {
        IAsyncEnumerable<AuditRecord> GetAuditRecordsAsync();
        Task SaveStatsRecordAsync(StatsRecord statsRecord);
        Task SaveStatsDetailRecordsAsync(IEnumerable<StatsDetailRecord> detailRecords);
    }
}