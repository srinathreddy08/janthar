using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IReapplyRepository
    {
        IAsyncEnumerable<DinInputRecord> GetDinInputRecordsAsync();
        Task AddReapplyRecordAsync(ReapplyRecord reapplyRecord);
    }
}