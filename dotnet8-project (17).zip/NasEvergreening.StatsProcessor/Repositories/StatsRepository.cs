using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Data;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class StatsRepository : IStatsRepository
    {
        private readonly ApplicationDbContext _context;

        public StatsRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async IAsyncEnumerable<AuditRecord> GetAuditRecordsAsync()
        {
            await foreach (var record in _context.AuditRecords.AsNoTracking().AsAsyncEnumerable())
            {
                yield return record;
            }
        }

        public async Task SaveStatsRecordAsync(StatsRecord statsRecord)
        {
            if (statsRecord == null) throw new System.ArgumentNullException(nameof(statsRecord));

            await _context.StatsRecords.AddAsync(statsRecord);
            await _context.SaveChangesAsync();
        }

        public async Task SaveStatsDetailRecordsAsync(IEnumerable<StatsDetailRecord> detailRecords)
        {
            if (detailRecords == null) throw new System.ArgumentNullException(nameof(detailRecords));

            await _context.StatsDetailRecords.AddRangeAsync(detailRecords);
            await _context.SaveChangesAsync();
        }
    }
}