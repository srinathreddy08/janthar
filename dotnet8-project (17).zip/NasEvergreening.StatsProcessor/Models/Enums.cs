namespace NasEvergreening.StatsProcessor.Models
{
    public enum CallMode
    {
        Update = 'U',
        Read = 'R'
    }

    public enum LoggingLevel
    {
        None = 0,
        Error = 1,
        Info = 2,
        Debug = 3
    }
}