using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("ReapplyRecords")]
    public class ReapplyRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [Range(long.MinValue, long.MaxValue)]
        public long Din { get; set; } // REPL-DIN

        [StringLength(4)]
        public string SrcProcess { get; set; } = string.Empty; // REPL-SRC-PROCESS

        [Required]
        public DateTime RunDate { get; set; } // REPL-RUN-DATE

        [Required]
        public int NoOfSubj { get; set; } // REPL-NO-OF-SUBJ

        [Required]
        public List<int> SubjNb { get; set; } = new List<int>(); // REPL-SUBJ-NB(1..2)

        [Required]
        public List<int> SubjSeq { get; set; } = new List<int>(); // REPL-SUBJ-SEQ(1..2)

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(100)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(100)]
        public string? ModifiedBy { get; set; }
    }
}