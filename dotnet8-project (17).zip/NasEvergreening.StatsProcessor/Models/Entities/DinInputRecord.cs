using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("DinInputRecords")]
    public class DinInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [Range(long.MinValue, long.MaxValue)]
        public long Din { get; set; } // D-INP-DIN PIC S9(18) COMP

        [Required]
        [Range(short.MinValue, short.MaxValue)]
        public short SubjNb { get; set; } // D-INP-SUBJ-NB PIC S9(04) COMP

        [Required]
        [Range(short.MinValue, short.MaxValue)]
        public short SubjSeqNb { get; set; } // D-INP-SUBJ-SEQ-NB PIC S9(04) COMP

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(100)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(100)]
        public string? ModifiedBy { get; set; }
    }
}