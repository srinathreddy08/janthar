using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("AuditRecords")]
    public class AuditRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        // Mapping fields from EDFNAECB copybook
        // Assuming fields like DinCount, PinCount, NonStdLinCount, ErrorFlag etc.

        [Required]
        public bool IsError { get; set; } // AUD-ERROR flag equivalent

        [Required]
        public bool IsProcessed { get; set; } // AUD-PROCESSED flag equivalent

        [Range(0, int.MaxValue)]
        public int PinCount { get; set; } // AUD-PIN-COUNT

        [Range(0, int.MaxValue)]
        public int NonStdLinCount { get; set; } // AUD-NON-STD-LIN-COUNT

        // Additional fields as per EDFNAECB copybook can be added here

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(100)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(100)]
        public string? ModifiedBy { get; set; }
    }
}