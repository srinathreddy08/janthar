using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("StatsRecords")]
    public class StatsRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Range(0, int.MaxValue)]
        public int ReapplyDinCount { get; set; } // STAT-REAPPLY-DIN-CT

        [Range(0, int.MaxValue)]
        public int PinCount { get; set; } // STAT-PIN-CT

        [Range(0, int.MaxValue)]
        public int LinDeleted { get; set; } // STAT-LIN-DELETED

        [Range(0, int.MaxValue)]
        public int TotalExistErrorRec { get; set; } // STAT-TOTAL-EXIST-ERROR-REC

        [Range(0, long.MaxValue)]
        public long CpuTime { get; set; } // STAT-EDBNAECE-CPU

        [Range(0, long.MaxValue)]
        public long ElapsedTime { get; set; } // STAT-EDBNAECE-ELP

        [Range(0, long.MaxValue)]
        public long TotalCpuTime { get; set; } // STAT-TOTAL-TIME-CPU

        [Range(0, long.MaxValue)]
        public long TotalElapsedTime { get; set; } // STAT-TOTAL-TIME-ELP

        // Additional statistics fields from COBOL can be added here

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(100)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(100)]
        public string? ModifiedBy { get; set; }
    }
}