namespace NasEvergreening.StatsProcessor.Models
{
    public class WorkingStorage
    {
        public int DinCount { get; set; } = 0;
        public int PinCount { get; set; } = 0;
        public int LinCount { get; set; } = 0;
        public int ErroredRecords { get; set; } = 0;

        public bool EofAuditFile { get; set; } = false;
        public bool EofDinFile { get; set; } = false;

        public char CallMode { get; set; } = 'R'; // 'U' or 'R'

        public long PrevDin { get; set; } = 0;

        public long DinNumeric { get; set; } = 0;
        public string DinAlphanumeric { get; set; } = string.Empty;

        public int LoggingLevel { get; set; } = 0;

        public string ErrorMessage { get; set; } = string.Empty;

        // Additional working storage variables can be added here
    }
}