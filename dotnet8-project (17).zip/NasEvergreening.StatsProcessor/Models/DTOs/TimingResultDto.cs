namespace NasEvergreening.StatsProcessor.Models.DTOs
{
    public class TimingResultDto
    {
        public long CpuTime { get; set; }
        public long ElapsedTime { get; set; }
    }
}