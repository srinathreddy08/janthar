using System.ComponentModel.DataAnnotations;

namespace NasEvergreening.StatsProcessor.Models.DTOs
{
    public class StatsProcessingRequestDto
    {
        [Required]
        [RegularExpression("[UR]", ErrorMessage = "CallMode must be 'U' (Update) or 'R' (Read).")]
        public char CallMode { get; set; }

        [Range(0, 3, ErrorMessage = "LoggingLevel must be between 0 and 3.")]
        public int LoggingLevel { get; set; }
    }
}