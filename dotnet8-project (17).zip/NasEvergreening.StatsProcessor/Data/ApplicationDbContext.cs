using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AuditRecord> AuditRecords { get; set; } = null!;
        public DbSet<DinInputRecord> DinInputRecords { get; set; } = null!;
        public DbSet<StatsRecord> StatsRecords { get; set; } = null!;
        public DbSet<StatsDetailRecord> StatsDetailRecords { get; set; } = null!;
        public DbSet<ReapplyRecord> ReapplyRecords { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure AuditRecord
            modelBuilder.Entity<AuditRecord>(entity =>
            {
                entity.ToTable("AuditRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.IsError).IsRequired();
                entity.Property(e => e.IsProcessed).IsRequired();
                entity.Property(e => e.PinCount).IsRequired();
                entity.Property(e => e.NonStdLinCount).IsRequired();
                entity.Property(e => e.CreatedDate).IsRequired();
                entity.Property(e => e.CreatedBy).HasMaxLength(100);
                entity.Property(e => e.ModifiedBy).HasMaxLength(100);
            });

            // Configure DinInputRecord
            modelBuilder.Entity<DinInputRecord>(entity =>
            {
                entity.ToTable("DinInputRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Din).IsRequired();
                entity.Property(e => e.SubjNb).IsRequired();
                entity.Property(e => e.SubjSeqNb).IsRequired();
                entity.Property(e => e.CreatedDate).IsRequired();
                entity.Property(e => e.CreatedBy).HasMaxLength(100);
                entity.Property(e => e.ModifiedBy).HasMaxLength(100);
            });

            // Configure StatsRecord
            modelBuilder.Entity<StatsRecord>(entity =>
            {
                entity.ToTable("StatsRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ReapplyDinCount).IsRequired();
                entity.Property(e => e.PinCount).IsRequired();
                entity.Property(e => e.LinDeleted).IsRequired();
                entity.Property(e => e.TotalExistErrorRec).IsRequired();
                entity.Property(e => e.CpuTime).IsRequired();
                entity.Property(e => e.ElapsedTime).IsRequired();
                entity.Property(e => e.TotalCpuTime).IsRequired();
                entity.Property(e => e.TotalElapsedTime).IsRequired();
                entity.Property(e => e.CreatedDate).IsRequired();
                entity.Property(e => e.CreatedBy).HasMaxLength(100);
                entity.Property(e => e.ModifiedBy).HasMaxLength(100);
            });

            // Configure StatsDetailRecord
            modelBuilder.Entity<StatsDetailRecord>(entity =>
            {
                entity.ToTable("StatsDetailRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Header).IsRequired().HasMaxLength(40);
                entity.Property(e => e.Details).IsRequired().HasMaxLength(50);
                entity.Property(e => e.CreatedDate).IsRequired();
                entity.Property(e => e.CreatedBy).HasMaxLength(100);
                entity.Property(e => e.ModifiedBy).HasMaxLength(100);
            });

            // Configure ReapplyRecord
            modelBuilder.Entity<ReapplyRecord>(entity =>
            {
                entity.ToTable("ReapplyRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Din).IsRequired();
                entity.Property(e => e.SrcProcess).HasMaxLength(4).IsRequired();
                entity.Property(e => e.RunDate).IsRequired();
                entity.Property(e => e.NoOfSubj).IsRequired();

                // Configure SubjNb and SubjSeq as JSON or separate table
                entity.Property(e => e.SubjNb)
                    .HasConversion(
                        v => System.Text.Json.JsonSerializer.Serialize(v, null),
                        v => System.Text.Json.JsonSerializer.Deserialize<List<int>>(v, null) ?? new List<int>())
                    .HasColumnType("nvarchar(max)");

                entity.Property(e => e.SubjSeq)
                    .HasConversion(
                        v => System.Text.Json.JsonSerializer.Serialize(v, null),
                        v => System.Text.Json.JsonSerializer.Deserialize<List<int>>(v, null) ?? new List<int>())
                    .HasColumnType("nvarchar(max)");

                entity.Property(e => e.CreatedDate).IsRequired();
                entity.Property(e => e.CreatedBy).HasMaxLength(100);
                entity.Property(e => e.ModifiedBy).HasMaxLength(100);
            });
        }
    }
}