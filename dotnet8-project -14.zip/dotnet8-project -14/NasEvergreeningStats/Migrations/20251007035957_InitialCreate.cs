﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NasEvergreeningStats.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "AuditInputRecords",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    ProcStartDate = table.Column<string>(type: "varchar(8)", maxLength: 8, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ProcStartTime = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    NasevgDin = table.Column<long>(type: "bigint", nullable: false),
                    SrcDin = table.Column<long>(type: "bigint", nullable: false),
                    SrcSubjIdNb = table.Column<int>(type: "int", nullable: false),
                    SrcSubjSeqNb = table.Column<int>(type: "int", nullable: false),
                    SrcRef = table.Column<long>(type: "bigint", nullable: false),
                    SrcName = table.Column<string>(type: "varchar(440)", maxLength: 440, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SrcAin = table.Column<int>(type: "int", nullable: false),
                    AddrQty = table.Column<string>(type: "varchar(1)", maxLength: 1, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SrcAddrFrmtCd = table.Column<string>(type: "varchar(2)", maxLength: 2, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SrcAddr = table.Column<string>(type: "varchar(440)", maxLength: 440, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SrcNm = table.Column<string>(type: "varchar(150)", maxLength: 150, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine1 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine2 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine3 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine4 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine5 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine6 = table.Column<string>(type: "varchar(112)", maxLength: 112, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine7 = table.Column<string>(type: "varchar(8)", maxLength: 8, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AinFromNas = table.Column<int>(type: "int", nullable: false),
                    QtyFromNas = table.Column<string>(type: "varchar(1)", maxLength: 1, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AinChangeFlag = table.Column<string>(type: "varchar(1)", maxLength: 1, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    DinFoundFlag = table.Column<string>(type: "varchar(1)", maxLength: 1, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ErrorCode = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ProcessStg = table.Column<string>(type: "varchar(1)", maxLength: 1, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    FieldIndicator = table.Column<string>(type: "varchar(1)", maxLength: 1, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    DataProvider = table.Column<string>(type: "varchar(5)", maxLength: 5, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SequenceNb = table.Column<int>(type: "int", nullable: false),
                    PinCount = table.Column<short>(type: "smallint", nullable: false),
                    NonStdLinCount = table.Column<short>(type: "smallint", nullable: false),
                    DinCount = table.Column<short>(type: "smallint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditInputRecords", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "DinInputRecords",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Din = table.Column<long>(type: "bigint", nullable: false),
                    SubjNb = table.Column<int>(type: "int", nullable: false),
                    SubjSeqNb = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DinInputRecords", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "ReapplyRecords",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Din = table.Column<long>(type: "bigint", nullable: false),
                    SubjNb = table.Column<int>(type: "int", nullable: false),
                    SubjSeq = table.Column<int>(type: "int", nullable: false),
                    NoOfSubj = table.Column<int>(type: "int", nullable: false),
                    SrcProcess = table.Column<int>(type: "int", nullable: false),
                    RunDate = table.Column<string>(type: "varchar(8)", maxLength: 8, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReapplyRecords", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "StatisticsRecords",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false),
                    LqRec = table.Column<int>(type: "int", nullable: false),
                    TxtRec = table.Column<int>(type: "int", nullable: false),
                    TotalExistErrorRec = table.Column<int>(type: "int", nullable: false),
                    TotalRecords = table.Column<int>(type: "int", nullable: false),
                    UnchngdAddr = table.Column<int>(type: "int", nullable: false),
                    TxtLqAinUnchg = table.Column<int>(type: "int", nullable: false),
                    LqHqAinUnchg = table.Column<int>(type: "int", nullable: false),
                    UnchgLqAinChgd = table.Column<int>(type: "int", nullable: false),
                    TxtLqAinChg = table.Column<int>(type: "int", nullable: false),
                    LqHqAinChg = table.Column<int>(type: "int", nullable: false),
                    PinCt = table.Column<int>(type: "int", nullable: false),
                    ReapplyDinCt = table.Column<int>(type: "int", nullable: false),
                    LinDeleted = table.Column<int>(type: "int", nullable: false),
                    EdbnaeCaCpu = table.Column<long>(type: "bigint", nullable: false),
                    EdbnaeCaElp = table.Column<int>(type: "int", nullable: false),
                    EdbnaeCbCpu = table.Column<long>(type: "bigint", nullable: false),
                    EdbnaeCbElp = table.Column<int>(type: "int", nullable: false),
                    EdbnaeCcCpu = table.Column<long>(type: "bigint", nullable: false),
                    EdbnaeCcElp = table.Column<int>(type: "int", nullable: false),
                    EdbnaeCdCpu = table.Column<long>(type: "bigint", nullable: false),
                    EdbnaeCdElp = table.Column<int>(type: "int", nullable: false),
                    EdbnaeCeCpu = table.Column<long>(type: "bigint", nullable: false),
                    EdbnaeCeElp = table.Column<int>(type: "int", nullable: false),
                    TotalTimeCpu = table.Column<long>(type: "bigint", nullable: false),
                    TotalTimeElp = table.Column<int>(type: "int", nullable: false),
                    TxtHqAinChg = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StatisticsRecords", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "AuditDinReapplyArray",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Din = table.Column<long>(type: "bigint", nullable: false),
                    SubjIdNb = table.Column<int>(type: "int", nullable: false),
                    SubjIdSeqNb = table.Column<int>(type: "int", nullable: false),
                    AuditInputRecordId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditDinReapplyArray", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AuditDinReapplyArray_AuditInputRecords_AuditInputRecordId",
                        column: x => x.AuditInputRecordId,
                        principalTable: "AuditInputRecords",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "AuditLinArray",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Lin = table.Column<int>(type: "int", nullable: false),
                    AuditInputRecordId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditLinArray", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AuditLinArray_AuditInputRecords_AuditInputRecordId",
                        column: x => x.AuditInputRecordId,
                        principalTable: "AuditInputRecords",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "AuditPinArray",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Pin = table.Column<int>(type: "int", nullable: false),
                    AuditInputRecordId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditPinArray", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AuditPinArray_AuditInputRecords_AuditInputRecordId",
                        column: x => x.AuditInputRecordId,
                        principalTable: "AuditInputRecords",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateIndex(
                name: "IX_AuditDinReapplyArray_AuditInputRecordId",
                table: "AuditDinReapplyArray",
                column: "AuditInputRecordId");

            migrationBuilder.CreateIndex(
                name: "IX_AuditLinArray_AuditInputRecordId",
                table: "AuditLinArray",
                column: "AuditInputRecordId");

            migrationBuilder.CreateIndex(
                name: "IX_AuditPinArray_AuditInputRecordId",
                table: "AuditPinArray",
                column: "AuditInputRecordId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AuditDinReapplyArray");

            migrationBuilder.DropTable(
                name: "AuditLinArray");

            migrationBuilder.DropTable(
                name: "AuditPinArray");

            migrationBuilder.DropTable(
                name: "DinInputRecords");

            migrationBuilder.DropTable(
                name: "ReapplyRecords");

            migrationBuilder.DropTable(
                name: "StatisticsRecords");

            migrationBuilder.DropTable(
                name: "AuditInputRecords");
        }
    }
}
