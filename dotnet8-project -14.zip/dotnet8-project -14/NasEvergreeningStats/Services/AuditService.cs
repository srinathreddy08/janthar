using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class AuditService : IAuditService
    {
        private readonly IAuditRepository _auditRepository;
        private readonly ILogger<AuditService> _logger;

        public AuditService(IAuditRepository auditRepository, ILogger<AuditService> logger)
        {
            _auditRepository = auditRepository;
            _logger = logger;
        }

        public async Task ProcessAuditRecordsAsync()
        {
            _logger.LogInformation("Starting processing of audit records.");

            try
            {
                var auditRecords = await _auditRepository.GetAllAsync();

                if (auditRecords == null || !auditRecords.Any())
                {
                    _logger.LogInformation("No audit records found to process.");
                    return;
                }

                // Business logic: Accumulate counts from audit records
                int erroredRecords = 0;
                int pinCount = 0;
                int linCount = 0;

                foreach (var record in auditRecords)
                {
                    if (record.ErrorCode != "0000" && !string.IsNullOrWhiteSpace(record.ErrorCode))
                    {
                        erroredRecords++;
                    }
                    else
                    {
                        pinCount += record.PinCount;
                        linCount += record.NonStdLinCount;
                    }
                }

                _logger.LogInformation("Audit processing completed. Errored Records: {ErroredRecords}, PIN Count: {PinCount}, LIN Count: {LinCount}", erroredRecords, pinCount, linCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while processing audit records.");
                throw;
            }
        }

        public async Task<int> GetErroredRecordCountAsync()
        {
            try
            {
                var auditRecords = await _auditRepository.GetAllAsync();
                return auditRecords.Count(r => r.ErrorCode != "0000" && !string.IsNullOrWhiteSpace(r.ErrorCode));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching errored record count.");
                throw;
            }
        }

        public async Task<int> GetPinCountAsync()
        {
            try
            {
                var auditRecords = await _auditRepository.GetAllAsync();
                return auditRecords.Sum(r => r.PinCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching PIN count.");
                throw;
            }
        }

        public async Task<int> GetLinCountAsync()
        {
            try
            {
                var auditRecords = await _auditRepository.GetAllAsync();
                return auditRecords.Sum(r => r.NonStdLinCount);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching LIN count.");
                throw;
            }
        }
    }
}