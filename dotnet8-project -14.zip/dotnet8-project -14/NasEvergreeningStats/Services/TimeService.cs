using System;
using System.Diagnostics;
using System.Threading.Tasks;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class TimeService : ITimeService
    {
        private readonly Stopwatch _stopwatch;

        public TimeService()
        {
            _stopwatch = Stopwatch.StartNew();
        }

        public Task<long> GetCpuTimeAsync()
        {
            // Simulate CPU time in ticks
            long cpuTimeTicks = Process.GetCurrentProcess().TotalProcessorTime.Ticks;
            return Task.FromResult(cpuTimeTicks);
        }

        public Task<int> GetElapsedTimeAsync()
        {
            // Return elapsed time in seconds
            int elapsedSeconds = (int)_stopwatch.Elapsed.TotalSeconds;
            return Task.FromResult(elapsedSeconds);
        }
    }
}