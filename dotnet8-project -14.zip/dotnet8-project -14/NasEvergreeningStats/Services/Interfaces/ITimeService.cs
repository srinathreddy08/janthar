using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface ITimeService
    {
        Task<long> GetCpuTimeAsync();
        Task<int> GetElapsedTimeAsync();
    }
}