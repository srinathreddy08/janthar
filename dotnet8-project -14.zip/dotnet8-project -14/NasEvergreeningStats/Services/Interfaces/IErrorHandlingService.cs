using System;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IErrorHandlingService
    {
        Task HandleErrorAsync(Exception exception, string section);
    }
}