using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreeningStats.Models.DTOs;
using NasEvergreeningStats.Models.Entities;


namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IStatisticsService
    {
        Task<StatisticsRecord?> GetStatisticsAsync();
        Task UpdateStatisticsAsync(StatisticsRecord statisticsRecord);
        Task<IEnumerable<DisplayStatisticsDto>> GenerateDisplayStatisticsAsync();
    }
}