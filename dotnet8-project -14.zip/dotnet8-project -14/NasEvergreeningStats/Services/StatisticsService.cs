using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Models.DTOs;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class StatisticsService : IStatisticsService
    {
        private readonly IStatisticsRepository _statisticsRepository;
        private readonly ILogger<StatisticsService> _logger;

        public StatisticsService(IStatisticsRepository statisticsRepository, ILogger<StatisticsService> logger)
        {
            _statisticsRepository = statisticsRepository;
            _logger = logger;
        }

        public async Task<StatisticsRecord?> GetStatisticsAsync()
        {
            _logger.LogInformation("Retrieving statistics record.");
            try
            {
                return await _statisticsRepository.GetStatisticsAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving statistics record.");
                throw;
            }
        }

        public async Task UpdateStatisticsAsync(StatisticsRecord statisticsRecord)
        {
            _logger.LogInformation("Updating statistics record.");
            if (statisticsRecord == null) throw new ArgumentNullException(nameof(statisticsRecord));

            try
            {
                await _statisticsRepository.UpdateStatisticsAsync(statisticsRecord);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating statistics record.");
                throw;
            }
        }

        public async Task<IEnumerable<DisplayStatisticsDto>> GenerateDisplayStatisticsAsync()
        {
            _logger.LogInformation("Generating display statistics data.");

            try
            {
                var stats = await _statisticsRepository.GetStatisticsAsync();
                if (stats == null)
                {
                    _logger.LogWarning("No statistics record found for display generation.");
                    return Array.Empty<DisplayStatisticsDto>();
                }

                var displayList = new List<DisplayStatisticsDto>
                {
                    new DisplayStatisticsDto { Header = "NUMBER OF LOW QUALITY INPUT RECORDS  :", Detail = stats.LqRec },
                    new DisplayStatisticsDto { Header = "NUMBER OF TEXT QUALITY INPUT RECORDS :", Detail = stats.TxtRec },
                    new DisplayStatisticsDto { Header = "NUMBER OF ERRORED RECORDS            :", Detail = stats.TotalExistErrorRec },
                    new DisplayStatisticsDto { Header = "TOTAL NUMBER OF INPUT RECORDS        :", Detail = stats.TotalRecords },
                    new DisplayStatisticsDto { Header = "NO OF RECORDS WITH AIN AND QLTY UNCHG:", Detail = stats.UnchngdAddr },
                    new DisplayStatisticsDto { Header = "NO OF TEXT TO LQ RECORD WITH SAME AIN:", Detail = stats.TxtLqAinUnchg },
                    new DisplayStatisticsDto { Header = "NO OF LQ TO HQ RECORDS WITH UNCHG AIN:", Detail = stats.LqHqAinUnchg },
                    new DisplayStatisticsDto { Header = "NO OF RECORDS WITH CHNG AIN SAME QLTY:", Detail = stats.UnchgLqAinChgd },
                    new DisplayStatisticsDto { Header = "NO OF TEXT TO LQ RECORD WITH CHNG AIN:", Detail = stats.TxtLqAinChg },
                    new DisplayStatisticsDto { Header = "NO OF LQ TO HQ RECORDS WITH CHNGD AIN:", Detail = stats.LqHqAinChg },
                    new DisplayStatisticsDto { Header = "NO OF TEXT TO HQ RECORD WITH CHNG AIN:", Detail = stats.TxtHqAinChg },
                    new DisplayStatisticsDto { Header = "NUMBER OF PINS IMPACTED              :", Detail = stats.PinCt },
                    new DisplayStatisticsDto { Header = "NUMBER OF DINS SENT TO REAPPLY       :", Detail = stats.ReapplyDinCt },
                    new DisplayStatisticsDto { Header = "NUMBER OF LINS DELETED               :", Detail = stats.LinDeleted },
                    new DisplayStatisticsDto { Header = "TOTAL CPU TIME                       :", Detail = stats.TotalTimeCpu },
                    new DisplayStatisticsDto { Header = "TOTAL ELAPSED TIME                   :", Detail = stats.TotalTimeElp }
                };

                return displayList;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating display statistics data.");
                throw;
            }
        }
    }
}