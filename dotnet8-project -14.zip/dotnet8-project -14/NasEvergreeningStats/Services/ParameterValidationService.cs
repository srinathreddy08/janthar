using System;
using System.Threading.Tasks;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class ParameterValidationService : IParameterValidationService
    {
        public Task ValidateLoggingLevelAsync(string loggingLevel)
        {
            if (string.IsNullOrWhiteSpace(loggingLevel) || !int.TryParse(loggingLevel, out _))
            {
                throw new ArgumentException("Logging level must be a numeric value.", nameof(loggingLevel));
            }
            return Task.CompletedTask;
        }

        public Task ValidateCallModeAsync(string callMode)
        {
            if (string.IsNullOrWhiteSpace(callMode) || (callMode != "U" && callMode != "R"))
            {
                throw new ArgumentException("Call mode must be either 'U' (Update) or 'R' (Read).", nameof(callMode));
            }
            return Task.CompletedTask;
        }
    }
}