using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("ReapplyRecords")]
    public class ReapplyRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        public long Din { get; set; } // REPL-DIN from DIN input

        [Required]
        public int SubjNb { get; set; } // REPL-SUBJ-NB

        [Required]
        public int SubjSeq { get; set; } // REPL-SUBJ-SEQ

        [Required]
        public int NoOfSubj { get; set; } // REPL-NO-OF-SUBJ

        [Required]
        public int SrcProcess { get; set; } // REPL-SRC-PROCESS

        [Required]
        public string RunDate { get; set; } = string.Empty; // REPL-RUN-DATE
    }
}