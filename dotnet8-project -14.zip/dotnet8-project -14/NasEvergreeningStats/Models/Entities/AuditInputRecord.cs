using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("AuditInputRecords")]
    public class AuditInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(8)]
        public string ProcStartDate { get; set; } = string.Empty;

        [Required]
        [StringLength(4)]
        public string ProcStartTime { get; set; } = string.Empty;

        [Required]
        public long NasevgDin { get; set; }

        [Required]
        public long SrcDin { get; set; }

        [Required]
        public int SrcSubjIdNb { get; set; }

        [Required]
        public int SrcSubjSeqNb { get; set; }

        [Required]
        public long SrcRef { get; set; }

        [StringLength(440)]
        public string? SrcName { get; set; }

        [Required]
        public int SrcAin { get; set; }

        [StringLength(1)]
        public string? AddrQty { get; set; }

        [StringLength(2)]
        public string? SrcAddrFrmtCd { get; set; }

        [StringLength(440)]
        public string? SrcAddr { get; set; }

        [StringLength(150)]
        public string? SrcNm { get; set; }

        [StringLength(60)]
        public string? AddrLine1 { get; set; }

        [StringLength(60)]
        public string? AddrLine2 { get; set; }

        [StringLength(60)]
        public string? AddrLine3 { get; set; }

        [StringLength(60)]
        public string? AddrLine4 { get; set; }

        [StringLength(60)]
        public string? AddrLine5 { get; set; }

        [StringLength(112)]
        public string? AddrLine6 { get; set; }

        [StringLength(8)]
        public string? AddrLine7 { get; set; }

        [Required]
        public int AinFromNas { get; set; }

        [StringLength(1)]
        public string? QtyFromNas { get; set; }

        [StringLength(1)]
        public string? AinChangeFlag { get; set; }

        [StringLength(1)]
        public string? DinFoundFlag { get; set; }

        [StringLength(4)]
        public string? ErrorCode { get; set; }

        [StringLength(1)]
        public string? ProcessStg { get; set; }

        [StringLength(1)]
        public string? FieldIndicator { get; set; }

        [StringLength(5)]
        public string? DataProvider { get; set; }

        [Required]
        public int SequenceNb { get; set; }

        [Required]
        public short PinCount { get; set; }

        [Required]
        public short NonStdLinCount { get; set; }

        [Required]
        public short DinCount { get; set; }

        public ICollection<AuditPin> PinArray { get; set; } = new List<AuditPin>();
        public ICollection<AuditLin> LinArray { get; set; } = new List<AuditLin>();
        public ICollection<AuditDinReapply> DinReapply { get; set; } = new List<AuditDinReapply>();
    }

    [Table("AuditPinArray")]
    public class AuditPin
    {
        [Key]
        public long Id { get; set; }

        [Required]
        public int Pin { get; set; }

        [ForeignKey("AuditInputRecord")]
        public long AuditInputRecordId { get; set; }

        public AuditInputRecord AuditInputRecord { get; set; } = null!;
    }

    [Table("AuditLinArray")]
    public class AuditLin
    {
        [Key]
        public long Id { get; set; }

        [Required]
        public int Lin { get; set; }

        [ForeignKey("AuditInputRecord")]
        public long AuditInputRecordId { get; set; }

        public AuditInputRecord AuditInputRecord { get; set; } = null!;
    }

    [Table("AuditDinReapplyArray")]
    public class AuditDinReapply
    {
        [Key]
        public long Id { get; set; }

        [Required]
        public long Din { get; set; }

        [Required]
        public int SubjIdNb { get; set; }

        [Required]
        public int SubjIdSeqNb { get; set; }

        [ForeignKey("AuditInputRecord")]
        public long AuditInputRecordId { get; set; }

        public AuditInputRecord AuditInputRecord { get; set; } = null!;
    }
}
