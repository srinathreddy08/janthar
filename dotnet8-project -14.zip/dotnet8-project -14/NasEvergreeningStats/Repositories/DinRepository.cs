using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;

namespace NasEvergreeningStats.Repositories
{
    public class DinRepository : IDinRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<DinRepository> _logger;

        public DinRepository(ApplicationDbContext context, ILogger<DinRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<DinInputRecord>> GetAllAsync()
        {
            _logger.LogInformation("Fetching all DIN input records.");
            return await _context.DinInputRecords.AsNoTracking().ToListAsync();
        }

        public async Task<DinInputRecord?> GetByIdAsync(long id)
        {
            _logger.LogInformation("Fetching DIN input record with Id: {Id}", id);
            return await _context.DinInputRecords.FirstOrDefaultAsync(d => d.Id == id);
        }

        public async Task AddAsync(DinInputRecord dinRecord)
        {
            _logger.LogInformation("Adding new DIN input record.");
            await _context.DinInputRecords.AddAsync(dinRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(DinInputRecord dinRecord)
        {
            _logger.LogInformation("Updating DIN input record with Id: {Id}", dinRecord.Id);
            _context.DinInputRecords.Update(dinRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(long id)
        {
            _logger.LogInformation("Deleting DIN input record with Id: {Id}", id);
            var entity = await _context.DinInputRecords.FindAsync(id);
            if (entity != null)
            {
                _context.DinInputRecords.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}