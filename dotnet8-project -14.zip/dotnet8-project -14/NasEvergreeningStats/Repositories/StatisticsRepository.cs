using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;

namespace NasEvergreeningStats.Repositories
{
    public class StatisticsRepository : IStatisticsRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<StatisticsRepository> _logger;

        public StatisticsRepository(ApplicationDbContext context, ILogger<StatisticsRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<StatisticsRecord?> GetStatisticsAsync()
        {
            _logger.LogInformation("Fetching statistics record.");
            return await _context.StatisticsRecords.FirstOrDefaultAsync(s => s.Id == 1);
        }

        public async Task UpdateStatisticsAsync(StatisticsRecord statisticsRecord)
        {
            _logger.LogInformation("Updating statistics record.");
            _context.StatisticsRecords.Update(statisticsRecord);
            await _context.SaveChangesAsync();
        }
    }
}