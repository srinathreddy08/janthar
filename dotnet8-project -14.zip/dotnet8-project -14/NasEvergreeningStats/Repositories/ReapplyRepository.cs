using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;

namespace NasEvergreeningStats.Repositories
{
    public class ReapplyRepository : IReapplyRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ReapplyRepository> _logger;

        public ReapplyRepository(ApplicationDbContext context, ILogger<ReapplyRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<ReapplyRecord>> GetAllAsync()
        {
            _logger.LogInformation("Fetching all reapply records.");
            return await _context.ReapplyRecords.AsNoTracking().ToListAsync();
        }

        public async Task AddAsync(ReapplyRecord reapplyRecord)
        {
            _logger.LogInformation("Adding a reapply record.");
            await _context.ReapplyRecords.AddAsync(reapplyRecord);
            await _context.SaveChangesAsync();
        }

        public async Task AddRangeAsync(IEnumerable<ReapplyRecord> reapplyRecords)
        {
            _logger.LogInformation("Adding multiple reapply records.");
            await _context.ReapplyRecords.AddRangeAsync(reapplyRecords);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAllAsync()
        {
            _logger.LogInformation("Deleting all reapply records.");
            _context.ReapplyRecords.RemoveRange(_context.ReapplyRecords);
            await _context.SaveChangesAsync();
        }
    }
}