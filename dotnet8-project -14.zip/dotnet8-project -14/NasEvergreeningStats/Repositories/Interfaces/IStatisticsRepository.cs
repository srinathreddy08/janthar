using System.Threading.Tasks;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IStatisticsRepository
    {
        Task<StatisticsRecord?> GetStatisticsAsync();
        Task UpdateStatisticsAsync(StatisticsRecord statisticsRecord);
    }
}