using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IAuditRepository
    {
        Task<IEnumerable<AuditInputRecord>> GetAllAsync();
        Task<AuditInputRecord?> GetByIdAsync(long id);
        Task AddAsync(AuditInputRecord auditRecord);
        Task UpdateAsync(AuditInputRecord auditRecord);
        Task DeleteAsync(long id);
    }
}