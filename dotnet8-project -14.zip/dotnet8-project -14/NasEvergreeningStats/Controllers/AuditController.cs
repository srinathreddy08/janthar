using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuditController : ControllerBase
    {
        private readonly IAuditService _auditService;
        private readonly ILogger<AuditController> _logger;

        public AuditController(IAuditService auditService, ILogger<AuditController> logger)
        {
            _auditService = auditService;
            _logger = logger;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessAuditRecords()
        {
            _logger.LogInformation("API call to process audit records.");

            try
            {
                await _auditService.ProcessAuditRecordsAsync();
                return Ok(new { Success = true, Message = "Audit records processed successfully." });
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "Error processing audit records.");
                return StatusCode(500, new { Success = false, Message = "Error processing audit records." });
            }
        }
    }
}