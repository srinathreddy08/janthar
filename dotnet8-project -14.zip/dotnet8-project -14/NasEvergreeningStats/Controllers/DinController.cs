using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DinController : ControllerBase
    {
        private readonly IDinService _dinService;
        private readonly ILogger<DinController> _logger;

        public DinController(IDinService dinService, ILogger<DinController> logger)
        {
            _dinService = dinService;
            _logger = logger;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessDinRecords([FromQuery] string callMode)
        {
            _logger.LogInformation("API call to process DIN records with call mode: {CallMode}", callMode);

            if (string.IsNullOrWhiteSpace(callMode))
            {
                return BadRequest(new { Success = false, Message = "Call mode query parameter is required." });
            }

            try
            {
                await _dinService.ProcessDinRecordsAsync(callMode);
                return Ok(new { Success = true, Message = "DIN records processed successfully." });
            }
            catch (System.ArgumentException argEx)
            {
                _logger.LogWarning(argEx, "Validation error in DIN processing.");
                return BadRequest(new { Success = false, Message = argEx.Message });
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "Error processing DIN records.");
                return StatusCode(500, new { Success = false, Message = "Error processing DIN records." });
            }
        }
    }
}