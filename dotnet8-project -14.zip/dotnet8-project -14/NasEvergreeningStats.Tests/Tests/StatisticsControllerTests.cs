using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Models.DTOs;
using NasEvergreeningStats.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class StatisticsControllerTests
    {
        private readonly Mock<IStatisticsService> _mockStatisticsService;
        private readonly Mock<ILogger<StatisticsController>> _mockLogger;
        private readonly StatisticsController _controller;

        public StatisticsControllerTests()
        {
            _mockStatisticsService = new Mock<IStatisticsService>();
            _mockLogger = new Mock<ILogger<StatisticsController>>();
            _controller = new StatisticsController(_mockStatisticsService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task GetDisplayStatistics_ReturnsOkWithDisplayList_WhenStatisticsExist()
        {
            // Arrange
            var displayStats = new List<DisplayStatisticsDto>
            {
                new DisplayStatisticsDto { Header = "Header1", Detail = 1 },
                new DisplayStatisticsDto { Header = "Header2", Detail = 2 }
            };

            _mockStatisticsService.Setup(s => s.GenerateDisplayStatisticsAsync()).ReturnsAsync(displayStats);

            // Act
            var result = await _controller.GetDisplayStatistics();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedList = Assert.IsAssignableFrom<IEnumerable<DisplayStatisticsDto>>(okResult.Value);
            Assert.Equal(displayStats, returnedList);
            _mockLogger.Verify(l => l.LogInformation(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task GetDisplayStatistics_ReturnsStatusCode500_WhenServiceThrowsException()
        {
            // Arrange
            var ex = new Exception("Service failure");
            _mockStatisticsService.Setup(s => s.GenerateDisplayStatisticsAsync()).ThrowsAsync(ex);

            // Act
            var result = await _controller.GetDisplayStatistics();

            // Assert
            var statusResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, statusResult.StatusCode);
            dynamic value = statusResult.Value!;
            Assert.False(value.Success);
            Assert.Equal("Error retrieving display statistics.", value.Message);
            _mockLogger.Verify(l => l.LogError(ex, It.IsAny<string>()), Times.Once);
        }
    }
}