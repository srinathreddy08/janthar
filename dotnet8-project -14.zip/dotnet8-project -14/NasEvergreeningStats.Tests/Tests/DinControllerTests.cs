using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class DinControllerTests
    {
        private readonly Mock<IDinService> _mockDinService;
        private readonly Mock<ILogger<DinController>> _mockLogger;
        private readonly DinController _controller;

        public DinControllerTests()
        {
            _mockDinService = new Mock<IDinService>();
            _mockLogger = new Mock<ILogger<DinController>>();
            _controller = new DinController(_mockDinService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessDinRecords_ReturnsBadRequest_WhenCallModeIsNullOrWhitespace()
        {
            // Arrange
            string? callMode = null;

            // Act
            var resultNull = await _controller.ProcessDinRecords(callMode!);
            var resultEmpty = await _controller.ProcessDinRecords("");
            var resultWhitespace = await _controller.ProcessDinRecords("  ");

            // Assert
            foreach (var result in new[] { resultNull, resultEmpty, resultWhitespace })
            {
                var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
                dynamic value = badRequestResult.Value!;
                Assert.False(value.Success);
                Assert.Equal("Call mode query parameter is required.", value.Message);
            }

            _mockDinService.Verify(s => s.ProcessDinRecordsAsync(It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public async Task ProcessDinRecords_ReturnsOk_WhenProcessingSucceeds()
        {
            // Arrange
            string callMode = "U";
            _mockDinService.Setup(s => s.ProcessDinRecordsAsync(callMode)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.ProcessDinRecords(callMode);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            dynamic value = okResult.Value!;
            Assert.True(value.Success);
            Assert.Equal("DIN records processed successfully.", value.Message);
            _mockDinService.Verify(s => s.ProcessDinRecordsAsync(callMode), Times.Once);
            _mockLogger.Verify(l => l.LogInformation(It.IsAny<string>(), callMode), Times.Once);
        }

        [Fact]
        public async Task ProcessDinRecords_ReturnsBadRequest_WhenServiceThrowsArgumentException()
        {
            // Arrange
            string callMode = "U";
            var argEx = new ArgumentException("Invalid call mode");
            _mockDinService.Setup(s => s.ProcessDinRecordsAsync(callMode)).ThrowsAsync(argEx);

            // Act
            var result = await _controller.ProcessDinRecords(callMode);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            dynamic value = badRequestResult.Value!;
            Assert.False(value.Success);
            Assert.Equal(argEx.Message, value.Message);
            _mockLogger.Verify(l => l.LogWarning(argEx, It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task ProcessDinRecords_ReturnsStatusCode500_WhenServiceThrowsException()
        {
            // Arrange
            string callMode = "R";
            var ex = new Exception("Unexpected error");
            _mockDinService.Setup(s => s.ProcessDinRecordsAsync(callMode)).ThrowsAsync(ex);

            // Act
            var result = await _controller.ProcessDinRecords(callMode);

            // Assert
            var statusResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, statusResult.StatusCode);
            dynamic value = statusResult.Value!;
            Assert.False(value.Success);
            Assert.Equal("Error processing DIN records.", value.Message);
            _mockLogger.Verify(l => l.LogError(ex, It.IsAny<string>()), Times.Once);
        }
    }
}