using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStatistics.Controllers;
using NasEvergreeningStatistics.Models.DTOs;
using NasEvergreeningStatistics.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStatistics.Tests.Controllers
{
    public class StatisticsControllerTests
    {
        private readonly Mock<IStatisticsService> _statisticsServiceMock;
        private readonly Mock<ILogger<StatisticsController>> _loggerMock;
        private readonly StatisticsController _controller;

        public StatisticsControllerTests()
        {
            _statisticsServiceMock = new Mock<IStatisticsService>();
            _loggerMock = new Mock<ILogger<StatisticsController>>();
            _controller = new StatisticsController(_statisticsServiceMock.Object, _loggerMock.Object);
        }

        [Fact]
        public async Task ProcessStatistics_ValidParameters_ReturnsOkResultWithResponse()
        {
            // Arrange
            var parameters = new BatchJobParametersDto { CallMode = 'U', LoggingLevel = 1 };
            var expectedResponse = new StatisticsResponseDto { Success = true, Message = "Processed" };
            _statisticsServiceMock.Setup(s => s.ProcessStatisticsAsync(parameters)).ReturnsAsync(expectedResponse);

            // Act
            var result = await _controller.ProcessStatistics(parameters);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedResponse, okResult.Value);
            _loggerMock.Verify(l => l.LogInformation(It.IsAny<string>(), parameters), Times.Once);
        }

        [Fact]
        public async Task ProcessStatistics_InvalidModelState_ReturnsBadRequest()
        {
            // Arrange
            var parameters = new BatchJobParametersDto { CallMode = 'U', LoggingLevel = 1 };
            _controller.ModelState.AddModelError("CallMode", "Required");

            // Act
            var result = await _controller.ProcessStatistics(parameters);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.IsType<SerializableError>(badRequestResult.Value);
            _loggerMock.Verify(l => l.LogWarning(It.IsAny<string>(), parameters), Times.Once);
        }

        [Fact]
        public async Task ProcessStatistics_ServiceThrowsArgumentException_ReturnsBadRequestWithMessage()
        {
            // Arrange
            var parameters = new BatchJobParametersDto { CallMode = 'U', LoggingLevel = 1 };
            var exceptionMessage = "Invalid call mode";
            _statisticsServiceMock.Setup(s => s.ProcessStatisticsAsync(parameters))
                .ThrowsAsync(new ArgumentException(exceptionMessage));

            // Act
            var result = await _controller.ProcessStatistics(parameters);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var response = Assert.IsType<dynamic>(badRequestResult.Value);
            Assert.False((bool)response.success);
            Assert.Equal(exceptionMessage, (string)response.message);
            _loggerMock.Verify(l => l.LogError(It.IsAny<ArgumentException>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task ProcessStatistics_ServiceThrowsException_ReturnsInternalServerError()
        {
            // Arrange
            var parameters = new BatchJobParametersDto { CallMode = 'U', LoggingLevel = 1 };
            _statisticsServiceMock.Setup(s => s.ProcessStatisticsAsync(parameters))
                .ThrowsAsync(new Exception("Unexpected error"));

            // Act
            var result = await _controller.ProcessStatistics(parameters);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            var response = Assert.IsType<dynamic>(objectResult.Value);
            Assert.False((bool)response.success);
            Assert.Equal("Internal server error", (string)response.message);
            _loggerMock.Verify(l => l.LogError(It.IsAny<Exception>(), It.IsAny<string>()), Times.Once);
        }
    }
}
