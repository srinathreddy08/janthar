using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStatistics.Data;
using NasEvergreeningStatistics.Models.Entities;
using NasEvergreeningStatistics.Repositories.Interfaces;

namespace NasEvergreeningStatistics.Repositories
{
    public class StatisticsRepository : IStatisticsRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<StatisticsRepository> _logger;

        public StatisticsRepository(ApplicationDbContext context, ILogger<StatisticsRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<StatisticsRecord?> GetLatestAsync()
        {
            _logger.LogInformation("Retrieving latest statistics record");
            return await _context.StatisticsRecords.OrderByDescending(s => s.Id).FirstOrDefaultAsync();
        }

        public async Task AddAsync(StatisticsRecord statisticsRecord)
        {
            _logger.LogInformation("Adding new statistics record");
            await _context.StatisticsRecords.AddAsync(statisticsRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(StatisticsRecord statisticsRecord)
        {
            _logger.LogInformation("Updating statistics record with id: {Id}", statisticsRecord.Id);
            _context.StatisticsRecords.Update(statisticsRecord);
            await _context.SaveChangesAsync();
        }
    }
}