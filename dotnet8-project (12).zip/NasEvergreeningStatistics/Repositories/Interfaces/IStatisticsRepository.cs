using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreeningStatistics.Models.Entities;

namespace NasEvergreeningStatistics.Repositories.Interfaces
{
    public interface IStatisticsRepository
    {
        Task<StatisticsRecord?> GetLatestAsync();
        Task AddAsync(StatisticsRecord statisticsRecord);
        Task UpdateAsync(StatisticsRecord statisticsRecord);
    }
}