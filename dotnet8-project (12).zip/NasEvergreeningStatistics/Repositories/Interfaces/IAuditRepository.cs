using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreeningStatistics.Models.Entities;

namespace NasEvergreeningStatistics.Repositories.Interfaces
{
    public interface IAuditRepository
    {
        Task<IEnumerable<AuditRecord>> GetAllAsync();
        Task<AuditRecord?> GetByIdAsync(long id);
        Task AddAsync(AuditRecord auditRecord);
        Task UpdateAsync(AuditRecord auditRecord);
        Task DeleteAsync(long id);
    }
}