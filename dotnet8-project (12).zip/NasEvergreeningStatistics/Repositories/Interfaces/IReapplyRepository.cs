using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreeningStatistics.Models.Entities;

namespace NasEvergreeningStatistics.Repositories.Interfaces
{
    public interface IReapplyRepository
    {
        Task<IEnumerable<ReapplyRecord>> GetAllAsync();
        Task AddAsync(ReapplyRecord reapplyRecord);
        Task DeleteAllAsync();
    }
}