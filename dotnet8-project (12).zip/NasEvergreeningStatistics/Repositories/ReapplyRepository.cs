using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStatistics.Data;
using NasEvergreeningStatistics.Models.Entities;
using NasEvergreeningStatistics.Repositories.Interfaces;

namespace NasEvergreeningStatistics.Repositories
{
    public class ReapplyRepository : IReapplyRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ReapplyRepository> _logger;

        public ReapplyRepository(ApplicationDbContext context, ILogger<ReapplyRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<ReapplyRecord>> GetAllAsync()
        {
            _logger.LogInformation("Retrieving all reapply records");
            return await _context.ReapplyRecords.AsNoTracking().ToListAsync();
        }

        public async Task AddAsync(ReapplyRecord reapplyRecord)
        {
            _logger.LogInformation("Adding new reapply record for DIN: {Din}", reapplyRecord.Din);
            await _context.ReapplyRecords.AddAsync(reapplyRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAllAsync()
        {
            _logger.LogInformation("Deleting all reapply records");
            var allRecords = await _context.ReapplyRecords.ToListAsync();
            _context.ReapplyRecords.RemoveRange(allRecords);
            await _context.SaveChangesAsync();
        }
    }
}