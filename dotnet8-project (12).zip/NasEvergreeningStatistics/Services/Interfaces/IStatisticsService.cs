using System.Threading.Tasks;
using NasEvergreeningStatistics.Models.DTOs;

namespace NasEvergreeningStatistics.Services.Interfaces
{
    public interface IStatisticsService
    {
        Task<StatisticsResponseDto> ProcessStatisticsAsync(BatchJobParametersDto parameters);
    }
}