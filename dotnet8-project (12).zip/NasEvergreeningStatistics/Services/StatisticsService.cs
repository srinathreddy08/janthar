using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStatistics.Models.DTOs;
using NasEvergreeningStatistics.Models.Entities;
using NasEvergreeningStatistics.Repositories.Interfaces;
using NasEvergreeningStatistics.Services.Interfaces;

namespace NasEvergreeningStatistics.Services
{
    public class StatisticsService : IStatisticsService
    {
        private readonly IAuditRepository _auditRepository;
        private readonly IDinInputRepository _dinInputRepository;
        private readonly IStatisticsRepository _statisticsRepository;
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ILogger<StatisticsService> _logger;

        public StatisticsService(
            IAuditRepository auditRepository,
            IDinInputRepository dinInputRepository,
            IStatisticsRepository statisticsRepository,
            IReapplyRepository reapplyRepository,
            ILogger<StatisticsService> logger)
        {
            _auditRepository = auditRepository;
            _dinInputRepository = dinInputRepository;
            _statisticsRepository = statisticsRepository;
            _reapplyRepository = reapplyRepository;
            _logger = logger;
        }

        public async Task<StatisticsResponseDto> ProcessStatisticsAsync(BatchJobParametersDto parameters)
        {
            _logger.LogInformation("Starting statistics processing with mode: {Mode} and logging level: {LoggingLevel}", parameters.CallMode, parameters.LoggingLevel);

            if (parameters == null)
                throw new ArgumentNullException(nameof(parameters), "Batch job parameters cannot be null");

            if (parameters.CallMode != 'U' && parameters.CallMode != 'R')
            {
                var errorMsg = $"Invalid call mode: {parameters.CallMode}. Allowed values are 'U' (Update) or 'R' (Read).";
                _logger.LogError(errorMsg);
                throw new ArgumentException(errorMsg, nameof(parameters.CallMode));
            }

            if (parameters.LoggingLevel < 0)
            {
                var errorMsg = "Logging level must be zero or positive integer.";
                _logger.LogError(errorMsg);
                throw new ArgumentException(errorMsg, nameof(parameters.LoggingLevel));
            }

            try
            {
                // Initialize accumulators
                long dinCount = 0;
                int pinCount = 0;
                int linCount = 0;
                int erroredRecords = 0;

                // Read all audit records
                var auditRecords = await _auditRepository.GetAllAsync();

                foreach (var audit in auditRecords)
                {
                    if (audit.IsErrored)
                    {
                        erroredRecords += 1;
                    }
                    else if (audit.IsProcessed)
                    {
                        pinCount += audit.AuditPinCount;
                        linCount += audit.AuditLinCount;
                    }
                }

                // Read all DIN input records
                var dinInputRecords = await _dinInputRepository.GetAllAsync();

                // Clear existing reapply records if update mode
                if (parameters.CallMode == 'U')
                {
                    await _reapplyRepository.DeleteAllAsync();
                }

                foreach (var dinInput in dinInputRecords)
                {
                    dinCount++;

                    if (parameters.CallMode == 'U')
                    {
                        var reapplyRecord = new ReapplyRecord
                        {
                            Din = dinInput.Din,
                            SourceProcess = ExtractSourceProcessFromDin(dinInput.Din),
                            RunDate = DateTime.UtcNow,
                            SubjectNumbers = new List<int> { dinInput.SubjectNumber },
                            SubjectSequenceNumbers = new List<int> { dinInput.SubjectSequenceNumber }
                        };

                        await _reapplyRepository.AddAsync(reapplyRecord);
                    }
                }

                // Retrieve latest statistics record or create new
                var statisticsRecord = await _statisticsRepository.GetLatestAsync() ?? new StatisticsRecord();

                // Update statistics record with accumulated counts
                statisticsRecord.ReapplyDinCount = (int)dinCount;
                statisticsRecord.PinCount = pinCount;
                statisticsRecord.LinDeletedCount = linCount;
                statisticsRecord.ErroredRecordCount = erroredRecords;

                // Simulate CPU and elapsed time measurement
                statisticsRecord.CpuTime = TimeSpan.FromSeconds(1.23); // Placeholder for actual measurement
                statisticsRecord.ElapsedTime = TimeSpan.FromSeconds(2.34); // Placeholder for actual measurement

                // Update other statistics fields with zero or default values
                statisticsRecord.LowQualityRecordCount = 0;
                statisticsRecord.TextQualityRecordCount = 0;
                statisticsRecord.TotalRecords = (int)(dinCount + erroredRecords);
                statisticsRecord.UnchangedAddressCount = 0;
                statisticsRecord.TextToLowQualityUnchangedCount = 0;
                statisticsRecord.LowToHighQualityUnchangedCount = 0;
                statisticsRecord.UnchangedLowQualityAddressChangedCount = 0;
                statisticsRecord.TextToLowQualityAddressChangedCount = 0;
                statisticsRecord.LowToHighQualityAddressChangedCount = 0;
                statisticsRecord.TextToHighQualityAddressChangedCount = 0;

                if (statisticsRecord.Id == 0)
                {
                    await _statisticsRepository.AddAsync(statisticsRecord);
                }
                else
                {
                    await _statisticsRepository.UpdateAsync(statisticsRecord);
                }

                _logger.LogInformation("Statistics processing completed successfully. DIN Count: {DinCount}, PIN Count: {PinCount}, LIN Count: {LinCount}, Errored Records: {ErroredRecords}", dinCount, pinCount, linCount, erroredRecords);

                return new StatisticsResponseDto
                {
                    Success = true,
                    Message = "Statistics processed successfully",
                    DinCount = dinCount,
                    PinCount = pinCount,
                    LinCount = linCount,
                    ErroredRecords = erroredRecords
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during statistics processing");
                throw;
            }
        }

        private string ExtractSourceProcessFromDin(long din)
        {
            // Extract source process code from DIN numeric value as per COBOL logic
            // COBOL extracts substring WS-DIN-APLHANUM(7:4) which is 4 chars starting at position 7
            // Here we convert DIN to string and extract substring
            var dinStr = din.ToString().PadLeft(19, '0');
            if (dinStr.Length >= 10)
            {
                return dinStr.Substring(6, 4); // zero-based index 6 for 7th char
            }
            return string.Empty;
        }
    }
}