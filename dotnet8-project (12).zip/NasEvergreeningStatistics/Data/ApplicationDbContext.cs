using Microsoft.EntityFrameworkCore;
using NasEvergreeningStatistics.Models.Entities;

namespace NasEvergreeningStatistics.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AuditRecord> AuditRecords { get; set; } = null!;
        public DbSet<DinInputRecord> DinInputRecords { get; set; } = null!;
        public DbSet<StatisticsRecord> StatisticsRecords { get; set; } = null!;
        public DbSet<ReapplyRecord> ReapplyRecords { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<AuditRecord>(entity =>
            {
                entity.ToTable("AuditRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.DinCount).IsRequired();
                entity.Property(e => e.PinCount).IsRequired();
                entity.Property(e => e.LinCount).IsRequired();
                entity.Property(e => e.ErrorFlag).IsRequired();
                entity.Property(e => e.ProcessedFlag).IsRequired();
                entity.Property(e => e.NonStandardLinCount).IsRequired();

                entity.HasIndex(e => e.DinCount).HasDatabaseName("IX_AuditRecords_DinCount");
            });

            modelBuilder.Entity<DinInputRecord>(entity =>
            {
                entity.ToTable("DinInputRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Din).IsRequired();
                entity.Property(e => e.SubjectNumber).IsRequired();
                entity.Property(e => e.SubjectSequenceNumber).IsRequired();

                entity.HasIndex(e => e.Din).HasDatabaseName("IX_DinInputRecords_Din");
            });

            modelBuilder.Entity<StatisticsRecord>(entity =>
            {
                entity.ToTable("StatisticsRecords");
                entity.HasKey(e => e.Id);

                entity.Property(e => e.ReapplyDinCount).IsRequired();
                entity.Property(e => e.PinCount).IsRequired();
                entity.Property(e => e.LinDeletedCount).IsRequired();
                entity.Property(e => e.ErroredRecordCount).IsRequired();
                entity.Property(e => e.CpuTime).IsRequired();
                entity.Property(e => e.ElapsedTime).IsRequired();
                entity.Property(e => e.LowQualityRecordCount).IsRequired();
                entity.Property(e => e.TextQualityRecordCount).IsRequired();
                entity.Property(e => e.TotalRecords).IsRequired();
                entity.Property(e => e.UnchangedAddressCount).IsRequired();
                entity.Property(e => e.TextToLowQualityUnchangedCount).IsRequired();
                entity.Property(e => e.LowToHighQualityUnchangedCount).IsRequired();
                entity.Property(e => e.UnchangedLowQualityAddressChangedCount).IsRequired();
                entity.Property(e => e.TextToLowQualityAddressChangedCount).IsRequired();
                entity.Property(e => e.LowToHighQualityAddressChangedCount).IsRequired();
                entity.Property(e => e.TextToHighQualityAddressChangedCount).IsRequired();

                entity.HasIndex(e => e.ReapplyDinCount).HasDatabaseName("IX_StatisticsRecords_ReapplyDinCount");
            });

            modelBuilder.Entity<ReapplyRecord>(entity =>
            {
                entity.ToTable("ReapplyRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Din).IsRequired();
                entity.Property(e => e.SourceProcess).HasMaxLength(4).IsRequired();
                entity.Property(e => e.RunDate).IsRequired();

                entity.Ignore(e => e.SubjectNumbers);
                entity.Ignore(e => e.SubjectSequenceNumbers);

                // For SubjectNumbers and SubjectSequenceNumbers, consider separate tables or JSON columns if needed
            });
        }
    }
}