using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStatistics.Models.Entities
{
    [Table("AuditRecords")]
    public class AuditRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        public long DinCount { get; set; } // Corresponds to DIN count in audit

        [Required]
        public int PinCount { get; set; } // Corresponds to PIN count in audit

        [Required]
        public int LinCount { get; set; } // Corresponds to LIN count in audit

        [Required]
        public bool ErrorFlag { get; set; } // True if record errored

        [Required]
        public bool ProcessedFlag { get; set; } // True if processed

        [Required]
        public int NonStandardLinCount { get; set; } // Non standard LIN count

        // Audit record error indicator
        [NotMapped]
        public bool IsErrored => ErrorFlag;

        // Audit record processed indicator
        [NotMapped]
        public bool IsProcessed => ProcessedFlag;

        // Audit record PIN count accessor
        [NotMapped]
        public int AuditPinCount => PinCount;

        // Audit record LIN count accessor
        [NotMapped]
        public int AuditLinCount => LinCount + NonStandardLinCount;

        // Audit record error count accessor
        [NotMapped]
        public int AuditErrorCount => ErrorFlag ? 1 : 0;

        // Audit record PIN count for accumulation
        [NotMapped]
        public int AuditPinCountForAccumulation => PinCount;
    }
}