using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStatistics.Models.Entities
{
    [Table("StatisticsRecords")]
    public class StatisticsRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public int ReapplyDinCount { get; set; }

        [Required]
        public int PinCount { get; set; }

        [Required]
        public int LinDeletedCount { get; set; }

        [Required]
        public int ErroredRecordCount { get; set; }

        [Required]
        public TimeSpan CpuTime { get; set; }

        [Required]
        public TimeSpan ElapsedTime { get; set; }

        [Required]
        public int LowQualityRecordCount { get; set; }

        [Required]
        public int TextQualityRecordCount { get; set; }

        [Required]
        public int TotalRecords { get; set; }

        [Required]
        public int UnchangedAddressCount { get; set; }

        [Required]
        public int TextToLowQualityUnchangedCount { get; set; }

        [Required]
        public int LowToHighQualityUnchangedCount { get; set; }

        [Required]
        public int UnchangedLowQualityAddressChangedCount { get; set; }

        [Required]
        public int TextToLowQualityAddressChangedCount { get; set; }

        [Required]
        public int LowToHighQualityAddressChangedCount { get; set; }

        [Required]
        public int TextToHighQualityAddressChangedCount { get; set; }
    }
}