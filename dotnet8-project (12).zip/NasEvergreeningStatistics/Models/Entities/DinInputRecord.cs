using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStatistics.Models.Entities
{
    [Table("DinInputRecords")]
    public class DinInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [Column(TypeName = "bigint")]
        public long Din { get; set; }

        [Required]
        public int SubjectNumber { get; set; }

        [Required]
        public int SubjectSequenceNumber { get; set; }
    }
}