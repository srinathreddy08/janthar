using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStatistics.Models.Entities
{
    [Table("ReapplyRecords")]
    public class ReapplyRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [Column(TypeName = "bigint")]
        public long Din { get; set; }

        [Required]
        [StringLength(4)]
        public string SourceProcess { get; set; } = string.Empty;

        [Required]
        public DateTime RunDate { get; set; }

        [Required]
        public List<int> SubjectNumbers { get; set; } = new List<int>();

        [Required]
        public List<int> SubjectSequenceNumbers { get; set; } = new List<int>();
    }
}