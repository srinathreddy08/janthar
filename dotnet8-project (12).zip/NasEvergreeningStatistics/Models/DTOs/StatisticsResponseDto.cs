namespace NasEvergreeningStatistics.Models.DTOs
{
    public class StatisticsResponseDto
    {
        public bool Success { get; set; }
        public string? Message { get; set; }
        public long DinCount { get; set; }
        public int PinCount { get; set; }
        public int LinCount { get; set; }
        public int ErroredRecords { get; set; }
    }
}