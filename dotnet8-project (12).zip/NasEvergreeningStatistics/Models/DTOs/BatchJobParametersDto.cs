using System.ComponentModel.DataAnnotations;

namespace NasEvergreeningStatistics.Models.DTOs
{
    public class BatchJobParametersDto
    {
        [Required]
        [RegularExpression("[UR]", ErrorMessage = "CallMode must be 'U' (Update) or 'R' (Read).")]
        public char CallMode { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "LoggingLevel must be zero or positive integer.")]
        public int LoggingLevel { get; set; }
    }
}