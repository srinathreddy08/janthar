using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreeningStatistics.Models.DTOs;
using NasEvergreeningStatistics.Services.Interfaces;

namespace NasEvergreeningStatistics.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatisticsController : ControllerBase
    {
        private readonly IStatisticsService _statisticsService;
        private readonly ILogger<StatisticsController> _logger;

        public StatisticsController(IStatisticsService statisticsService, ILogger<StatisticsController> logger)
        {
            _statisticsService = statisticsService;
            _logger = logger;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessStatistics([FromBody] BatchJobParametersDto parameters)
        {
            _logger.LogInformation("Received request to process statistics with parameters: {@Parameters}", parameters);

            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid model state for parameters: {@Parameters}", parameters);
                return BadRequest(ModelState);
            }

            try
            {
                var result = await _statisticsService.ProcessStatisticsAsync(parameters);
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                _logger.LogError(ex, "Argument exception during statistics processing");
                return BadRequest(new { success = false, message = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during statistics processing");
                return StatusCode(500, new { success = false, message = "Internal server error" });
            }
        }
    }
}