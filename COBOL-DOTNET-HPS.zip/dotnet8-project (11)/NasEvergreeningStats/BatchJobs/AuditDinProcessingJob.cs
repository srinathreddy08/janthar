using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.BatchJobs
{
    public class AuditDinProcessingJob : BackgroundService
    {
        private readonly IAuditProcessingService _auditProcessingService;
        private readonly IDinProcessingService _dinProcessingService;
        private readonly IStatisticsService _statisticsService;
        private readonly IPerformanceService _performanceService;
        private readonly ILogger<AuditDinProcessingJob> _logger;

        public AuditDinProcessingJob(
            IAuditProcessingService auditProcessingService,
            IDinProcessingService dinProcessingService,
            IStatisticsService statisticsService,
            IPerformanceService performanceService,
            ILogger<AuditDinProcessingJob> logger)
        {
            _auditProcessingService = auditProcessingService;
            _dinProcessingService = dinProcessingService;
            _statisticsService = statisticsService;
            _performanceService = performanceService;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("AuditDinProcessingJob started at: {time}", DateTimeOffset.Now);

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await _auditProcessingService.ProcessAuditFilesAsync();

                    // Assuming call mode is fetched from DB or config; here hardcoded to 'U' for update
                    char callMode = 'U';
                    await _dinProcessingService.ProcessDinFilesAsync(callMode);

                    var cpuTime = await _performanceService.GetCpuTimeAsync();
                    var elapsedTime = await _performanceService.GetElapsedTimeAsync();

                    // For demonstration, dummy counts; in real scenario, get from audit processing service
                    int dinCount = 0; // Should be accumulated from audit processing
                    int pinCount = 0;
                    int linCount = 0;
                    int erroredRecCount = 0;

                    await _statisticsService.UpdateStatisticsAsync(dinCount, pinCount, linCount, erroredRecCount, cpuTime, elapsedTime);

                    var latestStats = await _statisticsService.GetDisplayStatisticsAsync();
                    // Optionally generate display statistics details

                    _logger.LogInformation("AuditDinProcessingJob completed cycle at: {time}", DateTimeOffset.Now);

                    // Wait for configured interval or exit if cancellation requested
                    await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error occurred in AuditDinProcessingJob.");
                    await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
                }
            }

            _logger.LogInformation("AuditDinProcessingJob is stopping at: {time}", DateTimeOffset.Now);
        }
    }
}