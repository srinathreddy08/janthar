using Microsoft.AspNetCore.Mvc;
using NasEvergreeningStats.Services.Interfaces;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuditController : ControllerBase
    {
        private readonly IAuditProcessingService _auditProcessingService;
        private readonly ILogger<AuditController> _logger;

        public AuditController(IAuditProcessingService auditProcessingService, ILogger<AuditController> logger)
        {
            _auditProcessingService = auditProcessingService;
            _logger = logger;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessAuditFiles()
        {
            _logger.LogInformation("Received request to process audit files.");

            try
            {
                await _auditProcessingService.ProcessAuditFilesAsync();
                return Ok("Audit files processed successfully.");
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "Error processing audit files.");
                return StatusCode(500, "Internal server error processing audit files.");
            }
        }
    }
}