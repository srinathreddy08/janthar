using Microsoft.AspNetCore.Mvc;
using NasEvergreeningStats.Services.Interfaces;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatisticsController : ControllerBase
    {
        private readonly IStatisticsService _statisticsService;
        private readonly ILogger<StatisticsController> _logger;

        public StatisticsController(IStatisticsService statisticsService, ILogger<StatisticsController> logger)
        {
            _statisticsService = statisticsService;
            _logger = logger;
        }

        [HttpGet("display")]
        public async Task<IActionResult> GetDisplayStatistics()
        {
            _logger.LogInformation("Received request to get display statistics.");

            try
            {
                var stats = await _statisticsService.GetDisplayStatisticsAsync();
                return Ok(stats);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "Error retrieving display statistics.");
                return StatusCode(500, "Internal server error retrieving display statistics.");
            }
        }
    }
}