using Microsoft.AspNetCore.Mvc;
using NasEvergreeningStats.Services.Interfaces;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DinController : ControllerBase
    {
        private readonly IDinProcessingService _dinProcessingService;
        private readonly ILogger<DinController> _logger;

        public DinController(IDinProcessingService dinProcessingService, ILogger<DinController> logger)
        {
            _dinProcessingService = dinProcessingService;
            _logger = logger;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessDinFiles([FromQuery] char callMode)
        {
            _logger.LogInformation("Received request to process DIN files with call mode {CallMode}.", callMode);

            if (callMode != 'U' && callMode != 'R')
            {
                return BadRequest("Invalid call mode. Allowed values are 'U' (Update) or 'R' (Read).");
            }

            try
            {
                await _dinProcessingService.ProcessDinFilesAsync(callMode);
                return Ok("DIN files processed successfully.");
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "Error processing DIN files.");
                return StatusCode(500, "Internal server error processing DIN files.");
            }
        }
    }
}