using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class AuditProcessingService : IAuditProcessingService
    {
        private readonly IAuditRepository _auditRepository;
        private readonly ILogger<AuditProcessingService> _logger;

        // Accumulators analogous to WA-ACCUMULATORS
        private int _dinCount;
        private int _pinCount;
        private int _linCount;
        private int _erroredRecCount;

        private readonly IStatisticsService _statisticsService;

        public AuditProcessingService(
            IAuditRepository auditRepository,
            IStatisticsService statisticsService,
            ILogger<AuditProcessingService> logger)
        {
            _auditRepository = auditRepository;
            _statisticsService = statisticsService;
            _logger = logger;
        }


        public async Task ProcessAuditFilesAsync()
        {
            _logger.LogInformation("Starting audit file processing.");

            try
            {
                var auditRecords = await _auditRepository.GetAllAsync();

                _dinCount = 0;
                _pinCount = 0;
                _linCount = 0;
                _erroredRecCount = 0;

                foreach (var record in auditRecords)
                {
                    if (record.ErrorCode != "0000" && !string.IsNullOrWhiteSpace(record.ErrorCode))
                    {
                        _erroredRecCount++;
                        continue;
                    }

                    if (record.ProcessStg == 'P') // Processed
                    {
                        _pinCount += record.PinCount;
                        _linCount += record.NonStdLinCount;
                    }

                    _dinCount += record.DinCount;
                }

                _logger.LogInformation("Audit file processing completed. DIN Count: {DinCount}, PIN Count: {PinCount}, LIN Count: {LinCount}, Errored Records: {ErroredCount}",
                    _dinCount, _pinCount, _linCount, _erroredRecCount);

                // Create statistics record
                var stats = new StatisticsRecord
                {
                    ReapplyDinCount = _dinCount,
                    PinCount = _pinCount,
                    LinDeleted = _linCount,
                    TotalExistErrorRec = _erroredRecCount,
                    TotalRecords = _dinCount + _pinCount + _linCount + _erroredRecCount,
                    CpuTime = 0,
                    ElapsedTime = 0
                };

                // Update and generate display statistics
                await _statisticsService.UpdateStatisticsAsync(
                    _dinCount, _pinCount, _linCount, _erroredRecCount, 0, 0);

                await _statisticsService.GenerateDisplayStatisticsAsync(stats);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during audit file processing.");
                throw;
            }
        }

        public async Task<IEnumerable<AuditInputFile>> GetAllAuditRecordsAsync()
        {
            return await _auditRepository.GetAllAsync();
        }
    }
}