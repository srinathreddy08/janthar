using System;
using System.Diagnostics;
using System.Threading.Tasks;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class PerformanceService : IPerformanceService
    {
        private readonly Stopwatch _cpuStopwatch;
        private readonly Stopwatch _elapsedStopwatch;

        public PerformanceService()
        {
            _cpuStopwatch = new Stopwatch();
            _elapsedStopwatch = new Stopwatch();
            _cpuStopwatch.Start();
            _elapsedStopwatch.Start();
        }

        public Task<long> GetCpuTimeAsync()
        {
            // Simulate CPU time in milliseconds
            return Task.FromResult(_cpuStopwatch.ElapsedMilliseconds);
        }

        public Task<long> GetElapsedTimeAsync()
        {
            return Task.FromResult(_elapsedStopwatch.ElapsedMilliseconds);
        }
    }
}