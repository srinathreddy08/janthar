using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class StatisticsService : IStatisticsService
    {
        private readonly IStatisticsRepository _statisticsRepository;
        private readonly ILogger<StatisticsService> _logger;

        public StatisticsService(IStatisticsRepository statisticsRepository, ILogger<StatisticsService> logger)
        {
            _statisticsRepository = statisticsRepository;
            _logger = logger;
        }

        public async Task UpdateStatisticsAsync(int dinCount, int pinCount, int linCount, int erroredRecCount, long cpuTime, long elapsedTime)
        {
            _logger.LogInformation("Updating statistics record.");

            try
            {
                var stats = await _statisticsRepository.GetLatestAsync() ?? new StatisticsRecord();

                stats.ReapplyDinCount = dinCount;
                stats.PinCount = pinCount;
                stats.LinDeleted = linCount;
                stats.TotalExistErrorRec = erroredRecCount;
                stats.TotalRecords = dinCount + pinCount + linCount + erroredRecCount; // Approximation
                stats.CpuTime = cpuTime;
                stats.ElapsedTime = elapsedTime;

                if (stats.Id == 0)
                {
                    await _statisticsRepository.AddAsync(stats);
                }
                else
                {
                    await _statisticsRepository.UpdateAsync(stats);
                }

                _logger.LogInformation("Statistics record updated successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating statistics record.");
                throw;
            }
        }

        public async Task<IEnumerable<DisplayStatisticsDetail>> GetDisplayStatisticsAsync()
        {
            return await _statisticsRepository.GetDisplayStatisticsAsync();
        }

        public async Task GenerateDisplayStatisticsAsync(StatisticsRecord stats)
        {
            _logger.LogInformation("Generating display statistics details.");

            try
            {
                var details = new List<DisplayStatisticsDetail>
                {
                    new DisplayStatisticsDetail { Header = "NUMBER OF LOW QUALITY INPUT RECORDS  :", Details = stats.TotalExistErrorRec.ToString() },
                    new DisplayStatisticsDetail { Header = "NUMBER OF TEXT QUALITY INPUT RECORDS :", Details = stats.PinCount.ToString() },
                    new DisplayStatisticsDetail { Header = "NUMBER OF ERRORED RECORDS            :", Details = stats.TotalExistErrorRec.ToString() },
                    new DisplayStatisticsDetail { Header = "TOTAL NUMBER OF INPUT RECORDS        :", Details = stats.TotalRecords.ToString() },
                    new DisplayStatisticsDetail { Header = "NO OF RECORDS WITH AIN AND QLTY UNCHG:", Details = stats.UnchangedAddr.ToString() },
                    new DisplayStatisticsDetail { Header = "NO OF TEXT TO LQ RECORD WITH SAME AIN:", Details = stats.TxtLqAinUnchg.ToString() },
                    new DisplayStatisticsDetail { Header = "NO OF LQ TO HQ RECORDS WITH UNCHG AIN:", Details = stats.LqHqAinUnchg.ToString() },
                    new DisplayStatisticsDetail { Header = "NO OF RECORDS WITH CHNG AIN SAME QLTY:", Details = stats.UnchgLqAinChgd.ToString() },
                    new DisplayStatisticsDetail { Header = "NO OF TEXT TO LQ RECORD WITH CHNG AIN:", Details = stats.TxtLqAinChg.ToString() },
                    new DisplayStatisticsDetail { Header = "NO OF LQ TO HQ RECORDS WITH CHNGD AIN:", Details = stats.LqHqAinChgd.ToString() },
                    new DisplayStatisticsDetail { Header = "NUMBER OF PINS IMPACTED              :", Details = stats.PinCount.ToString() },
                    new DisplayStatisticsDetail { Header = "NUMBER OF DINS SENT TO REAPPLY       :", Details = stats.ReapplyDinCount.ToString() },
                    new DisplayStatisticsDetail { Header = "NUMBER OF LINS DELETED               :", Details = stats.LinDeleted.ToString() },
                    new DisplayStatisticsDetail { Header = "TOTAL CPU TIME                       :", Details = stats.CpuTime.ToString() },
                    new DisplayStatisticsDetail { Header = "TOTAL ELAPSED TIME                   :", Details = stats.ElapsedTime.ToString() }
                };

                foreach (var detail in details)
                {
                    await _statisticsRepository.AddDisplayStatisticAsync(detail);
                }

                _logger.LogInformation("Display statistics details generated successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating display statistics details.");
                throw;
            }
        }
    }
}