using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using NasEvergreeningStats.Services.Interfaces;
using System.Collections.Generic;

namespace NasEvergreeningStats.Services
{
    public class DinProcessingService : IDinProcessingService
    {
        private readonly IDinRepository _dinRepository;
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ILogger<DinProcessingService> _logger;

        public DinProcessingService(IDinRepository dinRepository, IReapplyRepository reapplyRepository, ILogger<DinProcessingService> logger)
        {
            _dinRepository = dinRepository;
            _reapplyRepository = reapplyRepository;
            _logger = logger;
        }

        public async Task ProcessDinFilesAsync(char callMode)
        {
            _logger.LogInformation("Starting DIN file processing with call mode {CallMode}.", callMode);

            if (callMode != 'U' && callMode != 'R')
            {
                throw new ArgumentException("Invalid call mode. Only 'U' (Update) or 'R' (Read) are allowed.", nameof(callMode));
            }

            try
            {
                var dinRecords = await _dinRepository.GetAllAsync();

                // Clear existing reapply records if update mode
                if (callMode == 'U')
                {
                    await _reapplyRepository.DeleteAllAsync();
                }

                foreach (var dinRecord in dinRecords)
                {
                    // Business logic: For update mode, write reapply record
                    if (callMode == 'U')
                    {
                        var reapplyRecord = new ReapplyRecord
                        {
                            Din = dinRecord.Din,
                            SrcProcess = "    ", // Placeholder, actual logic to determine source process
                            RunDate = DateTime.UtcNow.Date,
                            SubjNb = dinRecord.SubjNb,
                            SubjSeq = dinRecord.SubjSeqNb,
                            NoOfSubj = 1
                        };

                        await _reapplyRepository.AddAsync(reapplyRecord);
                        _logger.LogInformation("Added reapply record for DIN {Din}", dinRecord.Din);
                    }
                }

                _logger.LogInformation("DIN file processing completed.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during DIN file processing.");
                throw;
            }
        }
    }
}