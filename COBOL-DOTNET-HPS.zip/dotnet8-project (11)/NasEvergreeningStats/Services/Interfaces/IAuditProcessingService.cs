using NasEvergreeningStats.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IAuditProcessingService
    {
        Task ProcessAuditFilesAsync();
        Task<IEnumerable<AuditInputFile>> GetAllAuditRecordsAsync();
    }
}