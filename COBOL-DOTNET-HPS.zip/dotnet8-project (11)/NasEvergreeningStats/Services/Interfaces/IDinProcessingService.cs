using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IDinProcessingService
    {
        Task ProcessDinFilesAsync(char callMode);
    }
}