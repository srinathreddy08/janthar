using NasEvergreeningStats.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IStatisticsService
    {
        Task UpdateStatisticsAsync(int dinCount, int pinCount, int linCount, int erroredRecCount, long cpuTime, long elapsedTime);
        Task<IEnumerable<DisplayStatisticsDetail>> GetDisplayStatisticsAsync();
        Task GenerateDisplayStatisticsAsync(StatisticsRecord stats);
    }
}