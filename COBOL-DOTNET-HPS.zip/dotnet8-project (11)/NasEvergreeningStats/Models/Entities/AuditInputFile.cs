using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    public class AuditInputFile
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required, StringLength(8)]
        public string ProcStartDate { get; set; } = string.Empty;

        [Required, StringLength(4)]
        public string ProcStartTime { get; set; } = string.Empty;

        public long NasevgDin { get; set; }
        public long SrcDin { get; set; }
        public int SrcSubjIdNb { get; set; }
        public int SrcSubjSeqNb { get; set; }
        public long SrcRef { get; set; }

        [Required, StringLength(440)]
        public string SrcName { get; set; } = string.Empty;

        public int SrcAin { get; set; }

        [Required]
        [Column(TypeName = "char(1)")]
        public char AddrQty { get; set; }

        [Required, StringLength(2)]
        public string SrcAddrFrmtCd { get; set; } = string.Empty;

        [Required, StringLength(440)]
        public string SrcAddr { get; set; } = string.Empty;

        [Required]
        public FormattedAddress? FormattedAddr { get; set; }

        public int AinFromNas { get; set; }

        [Required]
        [Column(TypeName = "char(1)")]
        public char QtyFromNas { get; set; }

        [Required]
        [Column(TypeName = "char(1)")]
        public char AinChangeFlag { get; set; }

        [Required]
        [Column(TypeName = "char(1)")]
        public char DinFoundFlag { get; set; }

        [Required, StringLength(4)]
        public string ErrorCode { get; set; } = string.Empty;

        [Required]
        [Column(TypeName = "char(1)")]
        public char ProcessStg { get; set; }

        [Required]
        [Column(TypeName = "char(1)")]
        public char FieldIndicator { get; set; }

        [Required, StringLength(5)]
        public string DataProvider { get; set; } = string.Empty;

        public int SequenceNb { get; set; }
        public int PinCount { get; set; }
        public int NonStdLinCount { get; set; }
        public int DinCount { get; set; }

        public List<PinItem> PinArray { get; set; } = new();
        public List<LinItem> LinArray { get; set; } = new();
        public List<DinReapplyItem> DinReapply { get; set; } = new();
    }

    public class FormattedAddress
    {
        [Key]
        public long AuditInputFileId { get; set; }

        [Required, StringLength(150)]
        public string SrcNm { get; set; } = string.Empty;

        [Required, StringLength(60)]
        public string AddrLine1 { get; set; } = string.Empty;

        [Required, StringLength(60)]
        public string AddrLine2 { get; set; } = string.Empty;

        [Required, StringLength(60)]
        public string AddrLine3 { get; set; } = string.Empty;

        [Required, StringLength(60)]
        public string AddrLine4 { get; set; } = string.Empty;

        [Required, StringLength(60)]
        public string AddrLine5 { get; set; } = string.Empty;

        [Required, StringLength(112)]
        public string AddrLine6 { get; set; } = string.Empty;

        [Required, StringLength(8)]
        public string AddrLine7 { get; set; } = string.Empty;

        [ForeignKey("AuditInputFileId")]
        public AuditInputFile? AuditInputFile { get; set; }
    }

    public class DinReapplyItem
    {
        [Key]
        public long Id { get; set; }

        public long NDin { get; set; }
        public int NSubjIdNb { get; set; }
        public int NSubjIdSeqNb { get; set; }

        public long AuditInputFileId { get; set; }

        [ForeignKey("AuditInputFileId")]
        public AuditInputFile? AuditInputFile { get; set; }
    }

    public class PinItem
    {
        [Key]
        public long Id { get; set; }

        public long Value { get; set; }

        public long AuditInputFileId { get; set; }

        [ForeignKey("AuditInputFileId")]
        public AuditInputFile? AuditInputFile { get; set; }
    }

    public class LinItem
    {
        [Key]
        public long Id { get; set; }

        public long Value { get; set; }

        public long AuditInputFileId { get; set; }

        [ForeignKey("AuditInputFileId")]
        public AuditInputFile? AuditInputFile { get; set; }
    }
}
