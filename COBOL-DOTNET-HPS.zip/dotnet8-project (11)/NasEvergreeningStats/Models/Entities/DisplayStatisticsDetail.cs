using System.ComponentModel.DataAnnotations;

namespace NasEvergreeningStats.Models.Entities
{
    public class DisplayStatisticsDetail
    {
        [Key]
        public long Id { get; set; }

        [Required, StringLength(40)]
        public string Header { get; set; } = string.Empty;

        [Required]
        public string Details { get; set; } = string.Empty;
    }
}