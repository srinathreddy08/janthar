using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    public class ReapplyRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public long Din { get; set; }

        [Required, StringLength(4)]
        public string SrcProcess { get; set; } = string.Empty;

        public DateTime RunDate { get; set; }

        public int SubjNb { get; set; }

        public int SubjSeq { get; set; }

        public int NoOfSubj { get; set; }
    }
}