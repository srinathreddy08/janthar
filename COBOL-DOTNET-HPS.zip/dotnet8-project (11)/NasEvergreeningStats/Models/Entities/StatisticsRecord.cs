using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    public class StatisticsRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public int ReapplyDinCount { get; set; }

        public int PinCount { get; set; }

        public int LinDeleted { get; set; }

        public int TotalExistErrorRec { get; set; }

        public int TotalRecords { get; set; }

        public int UnchangedAddr { get; set; }

        public int TxtLqAinUnchg { get; set; }

        public int LqHqAinUnchg { get; set; }

        public int UnchgLqAinChgd { get; set; }

        public int TxtLqAinChg { get; set; }

        public int LqHqAinChgd { get; set; }

        public int TxtHqAinChg { get; set; }

        public long CpuTime { get; set; }

        public long ElapsedTime { get; set; }
    }
}