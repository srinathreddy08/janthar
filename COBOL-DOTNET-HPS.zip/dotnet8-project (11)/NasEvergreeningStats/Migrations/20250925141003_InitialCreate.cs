﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NasEvergreeningStats.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "AuditInputFiles",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    ProcStartDate = table.Column<string>(type: "varchar(8)", maxLength: 8, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ProcStartTime = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    NasevgDin = table.Column<long>(type: "bigint", nullable: false),
                    SrcDin = table.Column<long>(type: "bigint", nullable: false),
                    SrcSubjIdNb = table.Column<int>(type: "int", nullable: false),
                    SrcSubjSeqNb = table.Column<int>(type: "int", nullable: false),
                    SrcRef = table.Column<long>(type: "bigint", nullable: false),
                    SrcName = table.Column<string>(type: "varchar(440)", maxLength: 440, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SrcAin = table.Column<int>(type: "int", nullable: false),
                    AddrQty = table.Column<string>(type: "char(1)", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SrcAddrFrmtCd = table.Column<string>(type: "varchar(2)", maxLength: 2, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SrcAddr = table.Column<string>(type: "varchar(440)", maxLength: 440, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AinFromNas = table.Column<int>(type: "int", nullable: false),
                    QtyFromNas = table.Column<string>(type: "char(1)", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AinChangeFlag = table.Column<string>(type: "char(1)", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    DinFoundFlag = table.Column<string>(type: "char(1)", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ErrorCode = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ProcessStg = table.Column<string>(type: "char(1)", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    FieldIndicator = table.Column<string>(type: "char(1)", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    DataProvider = table.Column<string>(type: "varchar(5)", maxLength: 5, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    SequenceNb = table.Column<int>(type: "int", nullable: false),
                    PinCount = table.Column<int>(type: "int", nullable: false),
                    NonStdLinCount = table.Column<int>(type: "int", nullable: false),
                    DinCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditInputFiles", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "DinInputRecords",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Din = table.Column<long>(type: "bigint", nullable: false),
                    SubjNb = table.Column<int>(type: "int", nullable: false),
                    SubjSeqNb = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DinInputRecords", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "DisplayStatisticsDetails",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Header = table.Column<string>(type: "varchar(40)", maxLength: 40, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Details = table.Column<string>(type: "longtext", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DisplayStatisticsDetails", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "ReapplyRecords",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Din = table.Column<long>(type: "bigint", nullable: false),
                    SrcProcess = table.Column<string>(type: "varchar(4)", maxLength: 4, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    RunDate = table.Column<DateTime>(type: "datetime(6)", nullable: false),
                    SubjNb = table.Column<int>(type: "int", nullable: false),
                    SubjSeq = table.Column<int>(type: "int", nullable: false),
                    NoOfSubj = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReapplyRecords", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "StatisticsRecords",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    ReapplyDinCount = table.Column<int>(type: "int", nullable: false),
                    PinCount = table.Column<int>(type: "int", nullable: false),
                    LinDeleted = table.Column<int>(type: "int", nullable: false),
                    TotalExistErrorRec = table.Column<int>(type: "int", nullable: false),
                    TotalRecords = table.Column<int>(type: "int", nullable: false),
                    UnchangedAddr = table.Column<int>(type: "int", nullable: false),
                    TxtLqAinUnchg = table.Column<int>(type: "int", nullable: false),
                    LqHqAinUnchg = table.Column<int>(type: "int", nullable: false),
                    UnchgLqAinChgd = table.Column<int>(type: "int", nullable: false),
                    TxtLqAinChg = table.Column<int>(type: "int", nullable: false),
                    LqHqAinChgd = table.Column<int>(type: "int", nullable: false),
                    TxtHqAinChg = table.Column<int>(type: "int", nullable: false),
                    CpuTime = table.Column<long>(type: "bigint", nullable: false),
                    ElapsedTime = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StatisticsRecords", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "DinReapplyItems",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    NDin = table.Column<long>(type: "bigint", nullable: false),
                    NSubjIdNb = table.Column<int>(type: "int", nullable: false),
                    NSubjIdSeqNb = table.Column<int>(type: "int", nullable: false),
                    AuditInputFileId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DinReapplyItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DinReapplyItems_AuditInputFiles_AuditInputFileId",
                        column: x => x.AuditInputFileId,
                        principalTable: "AuditInputFiles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "FormattedAddresses",
                columns: table => new
                {
                    AuditInputFileId = table.Column<long>(type: "bigint", nullable: false),
                    SrcNm = table.Column<string>(type: "varchar(150)", maxLength: 150, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine1 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine2 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine3 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine4 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine5 = table.Column<string>(type: "varchar(60)", maxLength: 60, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine6 = table.Column<string>(type: "varchar(112)", maxLength: 112, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    AddrLine7 = table.Column<string>(type: "varchar(8)", maxLength: 8, nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FormattedAddresses", x => x.AuditInputFileId);
                    table.ForeignKey(
                        name: "FK_FormattedAddresses_AuditInputFiles_AuditInputFileId",
                        column: x => x.AuditInputFileId,
                        principalTable: "AuditInputFiles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "LinItem",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Value = table.Column<long>(type: "bigint", nullable: false),
                    AuditInputFileId = table.Column<long>(type: "bigint", nullable: false),
                    AuditInputFileId1 = table.Column<long>(type: "bigint", nullable: true),
                    AuditInputFileId2 = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LinItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LinItem_AuditInputFiles_AuditInputFileId",
                        column: x => x.AuditInputFileId,
                        principalTable: "AuditInputFiles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_LinItem_AuditInputFiles_AuditInputFileId1",
                        column: x => x.AuditInputFileId1,
                        principalTable: "AuditInputFiles",
                        principalColumn: "Id");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "PinItem",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Value = table.Column<long>(type: "bigint", nullable: false),
                    AuditInputFileId = table.Column<long>(type: "bigint", nullable: false),
                    AuditInputFileId1 = table.Column<long>(type: "bigint", nullable: true),
                    AuditInputFileId2 = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PinItem", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PinItem_AuditInputFiles_AuditInputFileId",
                        column: x => x.AuditInputFileId,
                        principalTable: "AuditInputFiles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PinItem_AuditInputFiles_AuditInputFileId1",
                        column: x => x.AuditInputFileId1,
                        principalTable: "AuditInputFiles",
                        principalColumn: "Id");
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateIndex(
                name: "IX_DinReapplyItems_AuditInputFileId",
                table: "DinReapplyItems",
                column: "AuditInputFileId");

            migrationBuilder.CreateIndex(
                name: "IX_LinItem_AuditInputFileId",
                table: "LinItem",
                column: "AuditInputFileId");

            migrationBuilder.CreateIndex(
                name: "IX_LinItem_AuditInputFileId1",
                table: "LinItem",
                column: "AuditInputFileId1");

            migrationBuilder.CreateIndex(
                name: "IX_PinItem_AuditInputFileId",
                table: "PinItem",
                column: "AuditInputFileId");

            migrationBuilder.CreateIndex(
                name: "IX_PinItem_AuditInputFileId1",
                table: "PinItem",
                column: "AuditInputFileId1");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DinInputRecords");

            migrationBuilder.DropTable(
                name: "DinReapplyItems");

            migrationBuilder.DropTable(
                name: "DisplayStatisticsDetails");

            migrationBuilder.DropTable(
                name: "FormattedAddresses");

            migrationBuilder.DropTable(
                name: "LinItem");

            migrationBuilder.DropTable(
                name: "PinItem");

            migrationBuilder.DropTable(
                name: "ReapplyRecords");

            migrationBuilder.DropTable(
                name: "StatisticsRecords");

            migrationBuilder.DropTable(
                name: "AuditInputFiles");
        }
    }
}
