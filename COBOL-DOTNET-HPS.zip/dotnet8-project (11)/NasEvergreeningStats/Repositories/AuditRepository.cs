using Microsoft.EntityFrameworkCore;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace NasEvergreeningStats.Repositories
{
    public class AuditRepository : IAuditRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AuditRepository> _logger;

        public AuditRepository(ApplicationDbContext context, ILogger<AuditRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task AddAsync(AuditInputFile auditInputFile)
        {
            try
            {
                await _context.AuditInputFiles.AddAsync(auditInputFile);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Added AuditInputFile with Id {Id}", auditInputFile.Id);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error adding AuditInputFile");
                throw;
            }
        }

        public async Task DeleteAsync(long id)
        {
            try
            {
                var entity = await _context.AuditInputFiles.FindAsync(id);
                if (entity == null)
                {
                    _logger.LogWarning("AuditInputFile with Id {Id} not found for deletion", id);
                    return;
                }
                _context.AuditInputFiles.Remove(entity);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Deleted AuditInputFile with Id {Id}", id);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error deleting AuditInputFile with Id {Id}", id);
                throw;
            }
        }

        public async Task<IEnumerable<AuditInputFile>> GetAllAsync()
        {
            return await _context.AuditInputFiles
                .Include(a => a.FormattedAddr)
                .Include(a => a.DinReapply)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<AuditInputFile?> GetByIdAsync(long id)
        {
            return await _context.AuditInputFiles
                .Include(a => a.FormattedAddr)
                .Include(a => a.DinReapply)
                .AsNoTracking()
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task UpdateAsync(AuditInputFile auditInputFile)
        {
            try
            {
                _context.AuditInputFiles.Update(auditInputFile);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Updated AuditInputFile with Id {Id}", auditInputFile.Id);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error updating AuditInputFile with Id {Id}", auditInputFile.Id);
                throw;
            }
        }
    }
}