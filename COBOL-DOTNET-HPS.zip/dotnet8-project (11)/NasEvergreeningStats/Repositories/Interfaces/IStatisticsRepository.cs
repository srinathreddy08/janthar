using NasEvergreeningStats.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IStatisticsRepository
    {
        Task<StatisticsRecord?> GetLatestAsync();
        Task AddAsync(StatisticsRecord statisticsRecord);
        Task UpdateAsync(StatisticsRecord statisticsRecord);
        Task<IEnumerable<DisplayStatisticsDetail>> GetDisplayStatisticsAsync();
        Task AddDisplayStatisticAsync(DisplayStatisticsDetail detail);
    }
}