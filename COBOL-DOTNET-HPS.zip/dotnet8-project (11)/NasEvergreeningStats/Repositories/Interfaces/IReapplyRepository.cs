using NasEvergreeningStats.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IReapplyRepository
    {
        Task<IEnumerable<ReapplyRecord>> GetAllAsync();
        Task AddAsync(ReapplyRecord reapplyRecord);
        Task DeleteAllAsync();
    }
}