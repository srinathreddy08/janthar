using NasEvergreeningStats.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IAuditRepository
    {
        Task<IEnumerable<AuditInputFile>> GetAllAsync();
        Task<AuditInputFile?> GetByIdAsync(long id);
        Task AddAsync(AuditInputFile auditInputFile);
        Task UpdateAsync(AuditInputFile auditInputFile);
        Task DeleteAsync(long id);
    }
}