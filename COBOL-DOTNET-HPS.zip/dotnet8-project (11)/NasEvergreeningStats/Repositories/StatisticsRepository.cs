using Microsoft.EntityFrameworkCore;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace NasEvergreeningStats.Repositories
{
    public class StatisticsRepository : IStatisticsRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<StatisticsRepository> _logger;

        public StatisticsRepository(ApplicationDbContext context, ILogger<StatisticsRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task AddAsync(StatisticsRecord statisticsRecord)
        {
            try
            {
                await _context.StatisticsRecords.AddAsync(statisticsRecord);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Added StatisticsRecord with Id {Id}", statisticsRecord.Id);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error adding StatisticsRecord");
                throw;
            }
        }

        public async Task<IEnumerable<DisplayStatisticsDetail>> GetDisplayStatisticsAsync()
        {
            return await _context.DisplayStatisticsDetails.AsNoTracking().ToListAsync();
        }

        public async Task<StatisticsRecord?> GetLatestAsync()
        {
            return await _context.StatisticsRecords.OrderByDescending(s => s.Id).FirstOrDefaultAsync();
        }

        public async Task AddDisplayStatisticAsync(DisplayStatisticsDetail detail)
        {
            try
            {
                await _context.DisplayStatisticsDetails.AddAsync(detail);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Added DisplayStatisticsDetail with Id {Id}", detail.Id);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error adding DisplayStatisticsDetail");
                throw;
            }
        }

        public async Task UpdateAsync(StatisticsRecord statisticsRecord)
        {
            try
            {
                _context.StatisticsRecords.Update(statisticsRecord);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Updated StatisticsRecord with Id {Id}", statisticsRecord.Id);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error updating StatisticsRecord with Id {Id}", statisticsRecord.Id);
                throw;
            }
        }
    }
}