using Microsoft.EntityFrameworkCore;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace NasEvergreeningStats.Repositories
{
    public class ReapplyRepository : IReapplyRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ReapplyRepository> _logger;

        public ReapplyRepository(ApplicationDbContext context, ILogger<ReapplyRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task AddAsync(ReapplyRecord reapplyRecord)
        {
            try
            {
                await _context.ReapplyRecords.AddAsync(reapplyRecord);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Added ReapplyRecord with Id {Id}", reapplyRecord.Id);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error adding ReapplyRecord");
                throw;
            }
        }

        public async Task DeleteAllAsync()
        {
            try
            {
                _context.ReapplyRecords.RemoveRange(_context.ReapplyRecords);
                await _context.SaveChangesAsync();
                _logger.LogInformation("Deleted all ReapplyRecords");
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error deleting all ReapplyRecords");
                throw;
            }
        }

        public async Task<IEnumerable<ReapplyRecord>> GetAllAsync()
        {
            return await _context.ReapplyRecords.AsNoTracking().ToListAsync();
        }
    }
}