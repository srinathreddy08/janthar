using Microsoft.EntityFrameworkCore;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Data.Configurations;

namespace NasEvergreeningStats.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AuditInputFile> AuditInputFiles { get; set; } = null!;
        public DbSet<FormattedAddress> FormattedAddresses { get; set; } = null!;
        public DbSet<DinReapplyItem> DinReapplyItems { get; set; } = null!;
        public DbSet<DinInputRecord> DinInputRecords { get; set; } = null!;
        public DbSet<StatisticsRecord> StatisticsRecords { get; set; } = null!;
        public DbSet<ReapplyRecord> ReapplyRecords { get; set; } = null!;
        public DbSet<DisplayStatisticsDetail> DisplayStatisticsDetails { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AuditInputFileConfiguration());
            modelBuilder.ApplyConfiguration(new DinInputRecordConfiguration());
            modelBuilder.ApplyConfiguration(new StatisticsRecordConfiguration());
            modelBuilder.ApplyConfiguration(new ReapplyRecordConfiguration());

            modelBuilder.Entity<FormattedAddress>()
                .HasOne(fa => fa.AuditInputFile)
                .WithOne(ai => ai.FormattedAddr)
                .HasForeignKey<FormattedAddress>(fa => fa.AuditInputFileId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<DinReapplyItem>()
                .HasOne(dr => dr.AuditInputFile)
                .WithMany(ai => ai.DinReapply)
                .HasForeignKey(dr => dr.AuditInputFileId)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }
    }
}