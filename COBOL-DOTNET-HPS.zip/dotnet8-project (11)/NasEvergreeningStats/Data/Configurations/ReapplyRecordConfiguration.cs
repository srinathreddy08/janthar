using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data.Configurations
{
    public class ReapplyRecordConfiguration : IEntityTypeConfiguration<ReapplyRecord>
    {
        public void Configure(EntityTypeBuilder<ReapplyRecord> builder)
        {
            builder.ToTable("ReapplyRecords");

            builder.Property(r => r.Din).IsRequired();
            builder.Property(r => r.SrcProcess).HasMaxLength(4).IsRequired();
            builder.Property(r => r.RunDate).IsRequired();
            builder.Property(r => r.SubjNb).IsRequired();
            builder.Property(r => r.SubjSeq).IsRequired();
            builder.Property(r => r.NoOfSubj).IsRequired();
        }
    }
}