using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data.Configurations
{
    public class DinInputRecordConfiguration : IEntityTypeConfiguration<DinInputRecord>
    {
        public void Configure(EntityTypeBuilder<DinInputRecord> builder)
        {
            builder.ToTable("DinInputRecords");

            builder.Property(d => d.Din).IsRequired();
            builder.Property(d => d.SubjNb).IsRequired();
            builder.Property(d => d.SubjSeqNb).IsRequired();
        }
    }
}