using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data.Configurations
{
    public class AuditInputFileConfiguration : IEntityTypeConfiguration<AuditInputFile>
    {
        public void Configure(EntityTypeBuilder<AuditInputFile> builder)
        {
            builder.ToTable("AuditInputFiles");

            builder.Property(a => a.ProcStartDate).HasMaxLength(8).IsRequired();
            builder.Property(a => a.ProcStartTime).HasMaxLength(4).IsRequired();
            builder.Property(a => a.SrcName).HasMaxLength(440).IsRequired();
            builder.Property(a => a.AddrQty).HasColumnType("char(1)").IsRequired();
            builder.Property(a => a.SrcAddrFrmtCd).HasMaxLength(2).IsRequired();
            builder.Property(a => a.SrcAddr).HasMaxLength(440).IsRequired();
            builder.Property(a => a.QtyFromNas).HasColumnType("char(1)").IsRequired();
            builder.Property(a => a.AinChangeFlag).HasColumnType("char(1)").IsRequired();
            builder.Property(a => a.DinFoundFlag).HasColumnType("char(1)").IsRequired();
            builder.Property(a => a.ErrorCode).HasMaxLength(4).IsRequired();
            builder.Property(a => a.ProcessStg).HasColumnType("char(1)").IsRequired();
            builder.Property(a => a.FieldIndicator).HasColumnType("char(1)").IsRequired();
            builder.Property(a => a.DataProvider).HasMaxLength(5).IsRequired();

            builder.HasMany(a => a.PinArray).WithOne().HasForeignKey("AuditInputFileId").OnDelete(DeleteBehavior.Cascade);
            builder.HasMany(a => a.LinArray).WithOne().HasForeignKey("AuditInputFileId").OnDelete(DeleteBehavior.Cascade);

            builder.HasMany(a => a.DinReapply).WithOne(d => d.AuditInputFile).HasForeignKey(d => d.AuditInputFileId).OnDelete(DeleteBehavior.Cascade);
        }
    }
}