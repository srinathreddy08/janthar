using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data.Configurations
{
    public class StatisticsRecordConfiguration : IEntityTypeConfiguration<StatisticsRecord>
    {
        public void Configure(EntityTypeBuilder<StatisticsRecord> builder)
        {
            builder.ToTable("StatisticsRecords");

            builder.Property(s => s.ReapplyDinCount).IsRequired();
            builder.Property(s => s.PinCount).IsRequired();
            builder.Property(s => s.LinDeleted).IsRequired();
            builder.Property(s => s.TotalExistErrorRec).IsRequired();
            builder.Property(s => s.TotalRecords).IsRequired();
            builder.Property(s => s.UnchangedAddr).IsRequired();
            builder.Property(s => s.TxtLqAinUnchg).IsRequired();
            builder.Property(s => s.LqHqAinUnchg).IsRequired();
            builder.Property(s => s.UnchgLqAinChgd).IsRequired();
            builder.Property(s => s.TxtLqAinChg).IsRequired();
            builder.Property(s => s.LqHqAinChgd).IsRequired();
            builder.Property(s => s.TxtHqAinChg).IsRequired();
            builder.Property(s => s.CpuTime).IsRequired();
            builder.Property(s => s.ElapsedTime).IsRequired();
        }
    }
}