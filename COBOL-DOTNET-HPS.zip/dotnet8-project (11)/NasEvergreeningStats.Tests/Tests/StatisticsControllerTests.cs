using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class StatisticsControllerTests
    {
        private readonly Mock<IStatisticsService> _mockStatisticsService;
        private readonly Mock<ILogger<StatisticsController>> _mockLogger;
        private readonly StatisticsController _controller;

        public StatisticsControllerTests()
        {
            _mockStatisticsService = new Mock<IStatisticsService>();
            _mockLogger = new Mock<ILogger<StatisticsController>>();
            _controller = new StatisticsController(_mockStatisticsService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task GetDisplayStatistics_ReturnsOkWithStatistics_WhenServiceReturnsData()
        {
            // Arrange
            var statsList = new List<DisplayStatisticsDetail>
            {
                new DisplayStatisticsDetail { Header = "Header1", Details = "Detail1" },
                new DisplayStatisticsDetail { Header = "Header2", Details = "Detail2" }
            };

            _mockStatisticsService.Setup(s => s.GetDisplayStatisticsAsync()).ReturnsAsync(statsList);

            // Act
            var result = await _controller.GetDisplayStatistics();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedStats = Assert.IsAssignableFrom<IEnumerable<DisplayStatisticsDetail>>(okResult.Value);
            Assert.Equal(statsList, returnedStats);
            _mockStatisticsService.Verify(s => s.GetDisplayStatisticsAsync(), Times.Once);
        }

        [Fact]
        public async Task GetDisplayStatistics_ReturnsInternalServerError_WhenServiceThrowsException()
        {
            // Arrange
            _mockStatisticsService.Setup(s => s.GetDisplayStatisticsAsync()).ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.GetDisplayStatistics();

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal("Internal server error retrieving display statistics.", objectResult.Value);
            _mockStatisticsService.Verify(s => s.GetDisplayStatisticsAsync(), Times.Once);
        }
    }
}