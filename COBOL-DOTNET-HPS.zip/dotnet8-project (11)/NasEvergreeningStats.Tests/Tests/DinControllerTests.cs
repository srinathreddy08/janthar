using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class DinControllerTests
    {
        private readonly Mock<IDinProcessingService> _mockDinProcessingService;
        private readonly Mock<ILogger<DinController>> _mockLogger;
        private readonly DinController _controller;

        public DinControllerTests()
        {
            _mockDinProcessingService = new Mock<IDinProcessingService>();
            _mockLogger = new Mock<ILogger<DinController>>();
            _controller = new DinController(_mockDinProcessingService.Object, _mockLogger.Object);
        }

        [Theory]
        [InlineData('U')]
        [InlineData('R')]
        public async Task ProcessDinFiles_ReturnsOk_WhenCallModeIsValid(char callMode)
        {
            // Arrange
            _mockDinProcessingService.Setup(s => s.ProcessDinFilesAsync(callMode)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.ProcessDinFiles(callMode);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("DIN files processed successfully.", okResult.Value);
            _mockDinProcessingService.Verify(s => s.ProcessDinFilesAsync(callMode), Times.Once);
        }

        [Theory]
        [InlineData('A')]
        [InlineData(' ')]
        [InlineData('1')]
        [InlineData('u')]
        [InlineData('r')]
        public async Task ProcessDinFiles_ReturnsBadRequest_WhenCallModeIsInvalid(char callMode)
        {
            // Act
            var result = await _controller.ProcessDinFiles(callMode);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Invalid call mode. Allowed values are 'U' (Update) or 'R' (Read).", badRequestResult.Value);
            _mockDinProcessingService.Verify(s => s.ProcessDinFilesAsync(It.IsAny<char>()), Times.Never);
        }

        [Fact]
        public async Task ProcessDinFiles_ReturnsInternalServerError_WhenProcessingThrowsException()
        {
            // Arrange
            char callMode = 'U';
            _mockDinProcessingService.Setup(s => s.ProcessDinFilesAsync(callMode)).ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.ProcessDinFiles(callMode);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal("Internal server error processing DIN files.", objectResult.Value);
            _mockDinProcessingService.Verify(s => s.ProcessDinFilesAsync(callMode), Times.Once);
        }
    }
}