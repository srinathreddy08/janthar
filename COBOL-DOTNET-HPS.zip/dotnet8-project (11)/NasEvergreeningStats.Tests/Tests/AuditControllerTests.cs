using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class AuditControllerTests
    {
        private readonly Mock<IAuditProcessingService> _mockAuditProcessingService;
        private readonly Mock<ILogger<AuditController>> _mockLogger;
        private readonly AuditController _controller;

        public AuditControllerTests()
        {
            _mockAuditProcessingService = new Mock<IAuditProcessingService>();
            _mockLogger = new Mock<ILogger<AuditController>>();
            _controller = new AuditController(_mockAuditProcessingService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessAuditFiles_ReturnsOk_WhenProcessingSucceeds()
        {
            // Arrange
            _mockAuditProcessingService.Setup(s => s.ProcessAuditFilesAsync()).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.ProcessAuditFiles();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Audit files processed successfully.", okResult.Value);
            _mockAuditProcessingService.Verify(s => s.ProcessAuditFilesAsync(), Times.Once);
        }

        [Fact]
        public async Task ProcessAuditFiles_ReturnsInternalServerError_WhenProcessingThrowsException()
        {
            // Arrange
            _mockAuditProcessingService.Setup(s => s.ProcessAuditFilesAsync()).ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.ProcessAuditFiles();

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal("Internal server error processing audit files.", objectResult.Value);
            _mockAuditProcessingService.Verify(s => s.ProcessAuditFilesAsync(), Times.Once);
        }
    }
}