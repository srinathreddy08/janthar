using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatsController : ControllerBase
    {
        private readonly IStatsProcessingService _statsProcessingService;
        private readonly ILogger<StatsController> _logger;

        public StatsController(IStatsProcessingService statsProcessingService, ILogger<StatsController> logger)
        {
            _statsProcessingService = statsProcessingService ?? throw new ArgumentNullException(nameof(statsProcessingService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessStats([FromBody] ProcessingParameters parameters)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                _logger.LogInformation("API call to process stats with parameters: {@Parameters}", parameters);

                await _statsProcessingService.ProcessAsync(parameters);

                return Ok(new { Message = "Statistics processing completed successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing statistics.");
                return StatusCode(500, new { Error = ex.Message });
            }
        }

        [HttpGet("statistics")]
        public async Task<IActionResult> GetStatistics()
        {
            try
            {
                var stats = await _statsProcessingService.GetStatisticsAsync();
                return Ok(stats);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving statistics.");
                return StatusCode(500, new { Error = ex.Message });
            }
        }

        [HttpGet("stats-details")]
        public async Task<IActionResult> GetStatsDetails()
        {
            try
            {
                var details = await _statsProcessingService.GetStatsDetailsAsync();
                return Ok(details);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving stats details.");
                return StatusCode(500, new { Error = ex.Message });
            }
        }

        [HttpGet("reapply-records")]
        public async Task<IActionResult> GetReapplyRecords()
        {
            try
            {
                var records = await _statsProcessingService.GetReapplyRecordsAsync();
                return Ok(records);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving reapply records.");
                return StatusCode(500, new { Error = ex.Message });
            }
        }
    }
}