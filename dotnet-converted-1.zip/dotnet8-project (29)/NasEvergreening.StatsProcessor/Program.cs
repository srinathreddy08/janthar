using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NasEvergreening.StatsProcessor.BatchJobs;
using NasEvergreening.StatsProcessor.Data;
using NasEvergreening.StatsProcessor.Repositories;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using NasEvergreening.StatsProcessor.Services;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using NasEvergreening.StatsProcessor.Security;
using NasEvergreening.StatsProcessor.Logging;

var builder = WebApplication.CreateBuilder(args);

// Configuration
var configuration = builder.Configuration;

// Add services to the container.
builder.Services.AddControllers();

// Add logging
builder.Services.AddLogging();

// Add DbContext (placeholder, no DB tables currently)
builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    // Configure DB provider here when needed
});

// Add repositories
builder.Services.AddScoped<IAuditRepository>(sp => new AuditRepository(
    sp.GetRequiredService<Microsoft.Extensions.Logging.ILogger<AuditRepository>>(),
    configuration["FileSettings:AuditInputFilePath"] ?? throw new InvalidOperationException("AuditInputFilePath not configured")));

builder.Services.AddScoped<IDinRepository>(sp => new DinRepository(
    sp.GetRequiredService<Microsoft.Extensions.Logging.ILogger<DinRepository>>(),
    configuration["FileSettings:DinInputFilePath"] ?? throw new InvalidOperationException("DinInputFilePath not configured")));

builder.Services.AddScoped<IStatsRepository>(sp => new StatsRepository(
    sp.GetRequiredService<Microsoft.Extensions.Logging.ILogger<StatsRepository>>(),
    configuration["FileSettings:StatsOutputFilePath"] ?? throw new InvalidOperationException("StatsOutputFilePath not configured"),
    configuration["FileSettings:StatsDetailOutputFilePath"] ?? throw new InvalidOperationException("StatsDetailOutputFilePath not configured")));

builder.Services.AddScoped<IReapplyRepository>(sp => new ReapplyRepository(
    sp.GetRequiredService<Microsoft.Extensions.Logging.ILogger<ReapplyRepository>>(),
    configuration["FileSettings:ReapplyOutputFilePath"] ?? throw new InvalidOperationException("ReapplyOutputFilePath not configured")));

// Add services
builder.Services.AddScoped<IStatsProcessingService, StatsProcessingService>();
builder.Services.AddScoped<ILoggingService, LoggingService>();
builder.Services.AddScoped<ITimeService, TimeService>();

// Add JWT Authentication
builder.Services.AddJwtAuthentication(configuration);

// Add Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Add background job
builder.Services.AddHostedService<StatsProcessingJob>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.UseMiddleware<ErrorHandlingMiddleware>();

app.MapControllers();

app.Run();