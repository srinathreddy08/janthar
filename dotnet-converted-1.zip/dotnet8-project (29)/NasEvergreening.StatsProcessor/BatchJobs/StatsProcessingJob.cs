using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.BatchJobs
{
    public class StatsProcessingJob : BackgroundService
    {
        private readonly IStatsProcessingService _statsProcessingService;
        private readonly ILogger<StatsProcessingJob> _logger;

        public StatsProcessingJob(IStatsProcessingService statsProcessingService, ILogger<StatsProcessingJob> logger)
        {
            _statsProcessingService = statsProcessingService;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("StatsProcessingJob started.");

            var parameters = new ProcessingParameters
            {
                LoggingLevel = 1, // Default or configurable
                CallMode = "U" // Default or configurable
            };

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await _statsProcessingService.ProcessAsync(parameters);
                    _logger.LogInformation("Stats processing job completed successfully.");
                }
                catch (System.Exception ex)
                {
                    _logger.LogError(ex, "Error occurred during stats processing job.");
                }

                // Wait for configured interval before next run
                await Task.Delay(3600000, stoppingToken); // 1 hour delay
            }

            _logger.LogInformation("StatsProcessingJob stopping.");
        }
    }
}