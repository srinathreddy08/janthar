using System.ComponentModel.DataAnnotations;

namespace NasEvergreening.StatsProcessor.Models.DTOs
{
    public class ProcessingParameters
    {
        [Range(0, 9)]
        public int LoggingLevel { get; set; } = 0;

        [Required]
        [RegularExpression("[UR]", ErrorMessage = "CallMode must be 'U' (Update) or 'R' (Read).")]
        public string CallMode { get; set; } = "R";
    }
}