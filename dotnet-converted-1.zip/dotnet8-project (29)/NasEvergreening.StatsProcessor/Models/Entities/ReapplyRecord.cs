using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    public class ReapplyRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        // Properties mapped from EXPFDREQ copybook fields
        // For brevity, assuming string content representing the record
        [Required]
        [StringLength(207)]
        public string RecordContent { get; set; } = string.Empty;
    }
}