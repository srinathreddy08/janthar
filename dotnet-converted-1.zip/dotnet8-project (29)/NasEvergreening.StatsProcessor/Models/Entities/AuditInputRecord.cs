using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    public class AuditInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(8)]
        public string ProcStartDate { get; set; } = string.Empty; // N-PROC-START-DT PIC X(08)

        [Required]
        [StringLength(4)]
        public string ProcStartTime { get; set; } = string.Empty; // N-PROC-START-TM PIC X(04)

        [Required]
        public long NasevgDin { get; set; } // PIC S9(18) COMP

        [Required]
        public long SrcDin { get; set; } // PIC S9(18) COMP

        [Required]
        public short SrcSubjIdNb { get; set; } // PIC S9(04) COMP

        [Required]
        public short SrcSubjSeqNb { get; set; } // PIC S9(04) COMP

        [Required]
        public long SrcRef { get; set; } // PIC S9(18) COMP

        [Required]
        [StringLength(440)]
        public string SrcName { get; set; } = string.Empty; // PIC X(440)

        [Required]
        public int SrcAin { get; set; } // PIC S9(09) COMP

        [Required]
        [StringLength(1)]
        public string AddrQty { get; set; } = string.Empty; // PIC X(01) with 88-levels

        [StringLength(2)]
        public string SrcAddrFrmtCd { get; set; } = string.Empty; // PIC X(02)

        [StringLength(440)]
        public string SrcAddr { get; set; } = string.Empty; // PIC X(440)

        // Formatted Address Fields
        [StringLength(150)]
        public string SrcNm { get; set; } = string.Empty; // PIC X(150)

        [StringLength(60)]
        public string AddrLine1 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(60)]
        public string AddrLine2 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(60)]
        public string AddrLine3 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(60)]
        public string AddrLine4 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(60)]
        public string AddrLine5 { get; set; } = string.Empty; // PIC X(60)

        [StringLength(112)]
        public string AddrLine6 { get; set; } = string.Empty; // PIC X(112)

        [StringLength(8)]
        public string AddrLine7 { get; set; } = string.Empty; // PIC X(08)

        [Required]
        public int AinFromNas { get; set; } // PIC S9(09) COMP

        [Required]
        [StringLength(1)]
        public string QtyFromNas { get; set; } = string.Empty; // PIC X(01) with 88-levels

        [Required]
        [StringLength(1)]
        public string AinChangeFlag { get; set; } = string.Empty; // PIC X(01) with 88-levels

        [Required]
        [StringLength(1)]
        public string DinFoundFlag { get; set; } = string.Empty; // PIC X(01) with 88-levels

        [StringLength(4)]
        public string ErrorCode { get; set; } = string.Empty; // PIC X(04) with 88-levels

        [Required]
        [StringLength(1)]
        public string ProcessStg { get; set; } = string.Empty; // PIC X(01) with 88-levels

        [Required]
        [StringLength(1)]
        public string FieldIndicator { get; set; } = string.Empty; // PIC X(01) with 88-levels

        [StringLength(5)]
        public string DataProvider { get; set; } = string.Empty; // PIC X(05)

        [Range(0, 999999)]
        public int SequenceNb { get; set; } // PIC 9(06)

        [Required]
        public short PinCount { get; set; } // PIC S9(04) COMP

        [Required]
        public short NonStdLinCount { get; set; } // PIC S9(04) COMP

        [Required]
        public short DinCount { get; set; } // PIC S9(04) COMP

        // Arrays
        public List<long> PinArray { get; set; } = new(); // N-PIN-ARRAY OCCURS 0 TO 500 TIMES

        public List<long> LinArray { get; set; } = new(); // N-LIN-ARRAY OCCURS 0 TO 200 TIMES

        public List<AuditDinReapply> DinReapply { get; set; } = new(); // N-DIN-REAPPLY OCCURS 0 TO 2200 TIMES

        // AuditDinReapply nested class
        public class AuditDinReapply
        {
            public long Din { get; set; } // PIC S9(18) COMP
            public short SubjIdNb { get; set; } // PIC S9(04) COMP
            public short SubjIdSeqNb { get; set; } // PIC S9(04) COMP
        }

        // Audit flags derived from 88-levels
        [NotMapped]
        public bool IsHighQuality => AddrQty == "H";

        [NotMapped]
        public bool IsLowQuality => AddrQty == "L";

        [NotMapped]
        public bool IsTextQuality => AddrQty == "T";

        [NotMapped]
        public bool AinChanged => AinChangeFlag == "Y";

        [NotMapped]
        public bool DinFound => DinFoundFlag == "Y";

        [NotMapped]
        public bool IsError => ProcessStg == "E";

        [NotMapped]
        public bool IsProcessed => ProcessStg == "P";

        [NotMapped]
        public bool IsAinUpdated => ProcessStg == "U";

        [NotMapped]
        public bool IsToAddress => FieldIndicator == "T";

        [NotMapped]
        public bool IsFromAddress => FieldIndicator == "F";

        [NotMapped]
        public bool IsPostStdAin => FieldIndicator == "S";

        [NotMapped]
        public bool IsEmpAin => FieldIndicator == "E";

        [NotMapped]
        public bool IsUpdateAll => FieldIndicator == "A";
    }
}