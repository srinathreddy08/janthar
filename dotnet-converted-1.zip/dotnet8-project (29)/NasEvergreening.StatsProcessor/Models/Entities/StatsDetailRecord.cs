using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    public class StatsDetailRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(40)]
        public string Header { get; set; } = string.Empty; // STAD-HEADER

        [Required]
        [StringLength(20)]
        public string Details { get; set; } = string.Empty; // STAD-DETAILS
    }
}