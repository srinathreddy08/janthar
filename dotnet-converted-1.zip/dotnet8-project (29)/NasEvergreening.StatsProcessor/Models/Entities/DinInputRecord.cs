using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    public class DinInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        public long Din { get; set; } // PIC S9(18) COMP

        [Required]
        public short SubjNb { get; set; } // PIC S9(04) COMP

        [Required]
        public short SubjSeqNb { get; set; } // PIC S9(04) COMP
    }
}