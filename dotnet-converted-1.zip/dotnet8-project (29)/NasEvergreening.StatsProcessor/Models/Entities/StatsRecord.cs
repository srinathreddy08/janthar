using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    public class StatsRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public int ReapplyDinCount { get; set; } // STAT-REAPPLY-DIN-CT

        public int PinCount { get; set; } // STAT-PIN-CT

        public int LinDeleted { get; set; } // STAT-LIN-DELETED

        public int TotalExistErrorRec { get; set; } // STAT-TOTAL-EXIST-ERROR-REC

        public int TotalRecords { get; set; } // STAT-TOTAL-RECORDS

        public int UnchangedAddr { get; set; } // STAT-UNCHNGD-ADDR

        public int TxtLqAinUnchg { get; set; } // STAT-TXT-LQ-AIN-UNCHG

        public int LqHqAinUnchg { get; set; } // STAT-LQ-HQ-AIN-UNCHG

        public int UnchgLqAinChgd { get; set; } // STAT-UNCHG-LQ-AIN-CHGD

        public int TxtLqAinChg { get; set; } // STAT-TXT-LQ-AIN-CHG

        public int LqHqAinChg { get; set; } // STAT-LQ-HQ-AIN-CHG

        public int TxtHqAinChg { get; set; } // STAT-TXT-HQ-AIN-CHG

        public int TotalCpuTime { get; set; } // STAT-TOTAL-TIME-CPU

        public int TotalElapsedTime { get; set; } // STAT-TOTAL-TIME-ELP

        public int EdbnaeceCpu { get; set; } // STAT-EDBNAECE-CPU

        public int EdbnaeceElapsed { get; set; } // STAT-EDBNAECE-ELP

        public DateTime LastUpdated { get; set; } = DateTime.UtcNow;

        [StringLength(50)]
        public string UpdatedBy { get; set; } = string.Empty;
    }
}