using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        // No DB2 tables used currently, placeholder for future EF Core entities

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // Configure entities here when DB tables are added
        }
    }
}