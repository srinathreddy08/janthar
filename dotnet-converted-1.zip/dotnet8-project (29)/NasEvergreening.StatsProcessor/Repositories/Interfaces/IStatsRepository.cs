using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IStatsRepository
    {
        Task OpenAsync();
        Task ReadStatsAsync();
        Task UpdateStatsAsync(StatsRecord statsRecord);
        Task WriteStatsDetailAsync(StatsDetailRecord detailRecord);
        Task CloseAsync();

        Task<IEnumerable<StatsRecord>> GetAllStatsAsync();
        Task<IEnumerable<StatsDetailRecord>> GetAllStatsDetailsAsync();
    }
}