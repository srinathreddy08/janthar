using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IAuditRepository
    {
        Task OpenAsync();
        Task ReadNextAsync();
        Task CloseAsync();

        AuditInputRecord? CurrentRecord { get; }
        bool IsEndOfFile { get; }
    }
}