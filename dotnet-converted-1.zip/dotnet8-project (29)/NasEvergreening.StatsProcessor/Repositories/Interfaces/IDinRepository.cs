using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IDinRepository
    {
        Task OpenAsync();
        Task ReadNextAsync();
        Task CloseAsync();

        DinInputRecord? CurrentRecord { get; }
        bool IsEndOfFile { get; }
    }
}