using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class DinRepository : IDinRepository
    {
        private readonly ILogger<DinRepository> _logger;
        private StreamReader? _reader;
        private readonly string _filePath;

        public DinInputRecord? CurrentRecord { get; private set; }
        public bool IsEndOfFile { get; private set; } = false;

        public DinRepository(ILogger<DinRepository> logger, string filePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _filePath = filePath ?? throw new ArgumentNullException(nameof(filePath));
        }

        public async Task OpenAsync()
        {
            try
            {
                _reader = new StreamReader(_filePath);
                IsEndOfFile = false;
                CurrentRecord = null;
                _logger.LogInformation("DIN file opened: {FilePath}", _filePath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to open DIN file: {FilePath}", _filePath);
                throw;
            }
        }

        public async Task ReadNextAsync()
        {
            if (_reader == null)
                throw new InvalidOperationException("DIN file not opened.");

            try
            {
                var line = await _reader.ReadLineAsync();
                if (line == null)
                {
                    IsEndOfFile = true;
                    CurrentRecord = null;
                    _logger.LogInformation("Reached end of DIN file.");
                    return;
                }

                // Assuming JSON lines for demo; replace with actual parsing logic
                CurrentRecord = JsonSerializer.Deserialize<DinInputRecord>(line);

                if (CurrentRecord == null)
                {
                    _logger.LogWarning("Parsed DIN record is null.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error reading DIN file.");
                throw;
            }
        }

        public async Task CloseAsync()
        {
            if (_reader != null)
            {
                _reader.Dispose();
                _reader = null;
                _logger.LogInformation("DIN file closed.");
            }
        }
    }
}