using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class StatsRepository : IStatsRepository
    {
        private readonly ILogger<StatsRepository> _logger;
        private readonly string _statsFilePath;
        private readonly string _statsDetailFilePath;

        private StatsRecord? _currentStatsRecord;

        public StatsRepository(ILogger<StatsRepository> logger, string statsFilePath, string statsDetailFilePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _statsFilePath = statsFilePath ?? throw new ArgumentNullException(nameof(statsFilePath));
            _statsDetailFilePath = statsDetailFilePath ?? throw new ArgumentNullException(nameof(statsDetailFilePath));
        }

        public Task OpenAsync()
        {
            // No persistent open needed for file-based implementation
            _logger.LogInformation("Stats repository initialized.");
            return Task.CompletedTask;
        }

        public async Task ReadStatsAsync()
        {
            try
            {
                if (!File.Exists(_statsFilePath))
                {
                    _logger.LogWarning("Stats file not found: {FilePath}", _statsFilePath);
                    _currentStatsRecord = new StatsRecord();
                    return;
                }

                var json = await File.ReadAllTextAsync(_statsFilePath);
                _currentStatsRecord = JsonSerializer.Deserialize<StatsRecord>(json) ?? new StatsRecord();
                _logger.LogInformation("Stats file read successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to read stats file.");
                throw;
            }
        }

        public async Task UpdateStatsAsync(StatsRecord statsRecord)
        {
            if (statsRecord == null) throw new ArgumentNullException(nameof(statsRecord));

            try
            {
                var json = JsonSerializer.Serialize(statsRecord, new JsonSerializerOptions { WriteIndented = true });
                await File.WriteAllTextAsync(_statsFilePath, json);
                _logger.LogInformation("Stats file updated successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update stats file.");
                throw;
            }
        }

        public async Task WriteStatsDetailAsync(StatsDetailRecord detailRecord)
        {
            if (detailRecord == null) throw new ArgumentNullException(nameof(detailRecord));

            try
            {
                // Append detail record as JSON line
                var json = JsonSerializer.Serialize(detailRecord);
                await File.AppendAllTextAsync(_statsDetailFilePath, json + Environment.NewLine);
                _logger.LogInformation("Stats detail record written.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to write stats detail record.");
                throw;
            }
        }

        public Task CloseAsync()
        {
            // No persistent resources to close
            _logger.LogInformation("Stats repository closed.");
            return Task.CompletedTask;
        }

        public async Task<IEnumerable<StatsRecord>> GetAllStatsAsync()
        {
            try
            {
                if (!File.Exists(_statsFilePath))
                    return new List<StatsRecord>();

                var json = await File.ReadAllTextAsync(_statsFilePath);
                var stats = JsonSerializer.Deserialize<StatsRecord>(json);
                return stats != null ? new List<StatsRecord> { stats } : new List<StatsRecord>();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get all stats.");
                throw;
            }
        }

        public async Task<IEnumerable<StatsDetailRecord>> GetAllStatsDetailsAsync()
        {
            var details = new List<StatsDetailRecord>();
            try
            {
                if (!File.Exists(_statsDetailFilePath))
                    return details;

                using var reader = new StreamReader(_statsDetailFilePath);
                string? line;
                while ((line = await reader.ReadLineAsync()) != null)
                {
                    var detail = JsonSerializer.Deserialize<StatsDetailRecord>(line);
                    if (detail != null)
                        details.Add(detail);
                }

                return details;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get all stats details.");
                throw;
            }
        }
    }
}