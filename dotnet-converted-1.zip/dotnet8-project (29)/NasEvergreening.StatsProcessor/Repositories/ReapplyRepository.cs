using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class ReapplyRepository : IReapplyRepository
    {
        private readonly ILogger<ReapplyRepository> _logger;
        private readonly string _filePath;

        private StreamWriter? _writer;

        public ReapplyRepository(ILogger<ReapplyRepository> logger, string filePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _filePath = filePath ?? throw new ArgumentNullException(nameof(filePath));
        }

        public async Task WriteAsync(ReapplyRecord record)
        {
            if (record == null) throw new ArgumentNullException(nameof(record));

            if (_writer == null)
            {
                _writer = new StreamWriter(_filePath, append: true);
                _logger.LogInformation("Reapply file opened for writing: {FilePath}", _filePath);
            }

            try
            {
                var json = JsonSerializer.Serialize(record);
                await _writer.WriteLineAsync(json);
                await _writer.FlushAsync();
                _logger.LogDebug("Reapply record written.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to write reapply record.");
                throw;
            }
        }

        public async Task CloseAsync()
        {
            if (_writer != null)
            {
                await _writer.DisposeAsync();
                _writer = null;
                _logger.LogInformation("Reapply file closed.");
            }
        }

        public async Task<IEnumerable<ReapplyRecord>> GetAllAsync()
        {
            var records = new List<ReapplyRecord>();
            try
            {
                if (!File.Exists(_filePath))
                    return records;

                using var reader = new StreamReader(_filePath);
                string? line;
                while ((line = await reader.ReadLineAsync()) != null)
                {
                    var record = JsonSerializer.Deserialize<ReapplyRecord>(line);
                    if (record != null)
                        records.Add(record);
                }

                return records;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to read reapply records.");
                throw;
            }
        }
    }
}