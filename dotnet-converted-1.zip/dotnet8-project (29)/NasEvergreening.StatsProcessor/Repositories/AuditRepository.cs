using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class AuditRepository : IAuditRepository
    {
        private readonly ILogger<AuditRepository> _logger;
        private StreamReader? _reader;
        private readonly string _filePath;

        public AuditInputRecord? CurrentRecord { get; private set; }
        public bool IsEndOfFile { get; private set; } = false;

        public AuditRepository(ILogger<AuditRepository> logger, string filePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _filePath = filePath ?? throw new ArgumentNullException(nameof(filePath));
        }

        public async Task OpenAsync()
        {
            try
            {
                _reader = new StreamReader(_filePath);
                IsEndOfFile = false;
                CurrentRecord = null;
                _logger.LogInformation("Audit file opened: {FilePath}", _filePath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to open audit file: {FilePath}", _filePath);
                throw;
            }
        }

        public async Task ReadNextAsync()
        {
            if (_reader == null)
                throw new InvalidOperationException("Audit file not opened.");

            try
            {
                var line = await _reader.ReadLineAsync();
                if (line == null)
                {
                    IsEndOfFile = true;
                    CurrentRecord = null;
                    _logger.LogInformation("Reached end of audit file.");
                    return;
                }

                // Assuming JSON lines for demo; replace with actual parsing logic
                CurrentRecord = JsonSerializer.Deserialize<AuditInputRecord>(line);

                if (CurrentRecord == null)
                {
                    _logger.LogWarning("Parsed audit record is null.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error reading audit file.");
                throw;
            }
        }

        public async Task CloseAsync()
        {
            if (_reader != null)
            {
                _reader.Dispose();
                _reader = null;
                _logger.LogInformation("Audit file closed.");
            }
        }
    }
}