using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using NasEvergreening.StatsProcessor.Services;

namespace NasEvergreening.StatsProcessor.Services
{
    public class StatsProcessingService : IStatsProcessingService
    {
        private readonly IAuditRepository _auditRepository;
        private readonly IDinRepository _dinRepository;
        private readonly IStatsRepository _statsRepository;
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ILoggingService _loggingService;
        private readonly ITimeService _timeService;
        private readonly ILogger<StatsProcessingService> _logger;

        // Accumulators for statistics
        private int _waDinCount;
        private int _waPinCount;
        private int _waLinCount;
        private int _waErroredRec;

        public StatsProcessingService(
            IAuditRepository auditRepository,
            IDinRepository dinRepository,
            IStatsRepository statsRepository,
            IReapplyRepository reapplyRepository,
            ILoggingService loggingService,
            ITimeService timeService,
            ILogger<StatsProcessingService> logger)
        {
            _auditRepository = auditRepository ?? throw new ArgumentNullException(nameof(auditRepository));
            _dinRepository = dinRepository ?? throw new ArgumentNullException(nameof(dinRepository));
            _statsRepository = statsRepository ?? throw new ArgumentNullException(nameof(statsRepository));
            _reapplyRepository = reapplyRepository ?? throw new ArgumentNullException(nameof(reapplyRepository));
            _loggingService = loggingService ?? throw new ArgumentNullException(nameof(loggingService));
            _timeService = timeService ?? throw new ArgumentNullException(nameof(timeService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task ProcessAsync(ProcessingParameters parameters)
        {
            if (parameters == null)
                throw new ArgumentNullException(nameof(parameters));

            if (parameters.LoggingLevel < 0 || parameters.LoggingLevel > 9)
                throw new ArgumentOutOfRangeException(nameof(parameters.LoggingLevel), "LoggingLevel must be between 0 and 9.");

            if (parameters.CallMode != "U" && parameters.CallMode != "R")
                throw new ArgumentException("CallMode must be 'U' (Update) or 'R' (Read).", nameof(parameters.CallMode));

            _logger.LogInformation("Starting stats processing with LoggingLevel={LoggingLevel} and CallMode={CallMode}", parameters.LoggingLevel, parameters.CallMode);

            try
            {
                // Initialization
                await InitializeAsync(parameters);

                // Main processing
                await MainProcessAsync(parameters);

                // Termination
                await TerminateAsync(parameters);

                _logger.LogInformation("Completed stats processing successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during stats processing.");
                throw;
            }
        }

        private async Task InitializeAsync(ProcessingParameters parameters)
        {
            _logger.LogDebug("Initializing processing environment.");

            // Reset accumulators
            _waDinCount = 0;
            _waPinCount = 0;
            _waLinCount = 0;
            _waErroredRec = 0;

            // Initialize time service
            await _timeService.InitializeAsync();

            // Open and read initial records
            await _auditRepository.OpenAsync();
            await _dinRepository.OpenAsync();
            await _statsRepository.OpenAsync();

            await _auditRepository.ReadNextAsync();
            await _statsRepository.ReadStatsAsync();
            await _dinRepository.ReadNextAsync();

            _logger.LogDebug("Initialization complete.");
        }

        private async Task MainProcessAsync(ProcessingParameters parameters)
        {
            _logger.LogDebug("Starting main processing loop.");

            // Process audit file until EOF
            while (!_auditRepository.IsEndOfFile)
            {
                var auditRecord = _auditRepository.CurrentRecord;
                if (auditRecord == null)
                {
                    _logger.LogWarning("Audit record is null during processing.");
                    break;
                }

                // Evaluate audit record process stage
                if (auditRecord.IsError)
                {
                    _waErroredRec++;
                }
                else if (auditRecord.IsProcessed)
                {
                    _waPinCount += auditRecord.PinCount;
                    _waLinCount += auditRecord.NonStdLinCount;
                }

                await _auditRepository.ReadNextAsync();
            }

            // Process DIN file until EOF
            while (!_dinRepository.IsEndOfFile)
            {
                var dinRecord = _dinRepository.CurrentRecord;
                if (dinRecord == null)
                {
                    _logger.LogWarning("DIN record is null during processing.");
                    break;
                }

                // Prepare reapply record
                var reapplyRecord = new ReapplyRecord
                {
                    RecordContent = GenerateReapplyRecordContent(dinRecord)
                };

                if (parameters.CallMode == "U")
                {
                    await _reapplyRepository.WriteAsync(reapplyRecord);
                }

                _waDinCount++;

                await _dinRepository.ReadNextAsync();
            }

            _logger.LogDebug("Main processing loop completed.");
        }

        private string GenerateReapplyRecordContent(DinInputRecord dinRecord)
        {
            // Compose reapply record content based on DIN input record
            // This is a simplified placeholder for actual formatting logic
            return $"DIN:{dinRecord.Din},SUBJNB:{dinRecord.SubjNb},SUBJSEQ:{dinRecord.SubjSeqNb}";
        }

        private async Task TerminateAsync(ProcessingParameters parameters)
        {
            _logger.LogDebug("Starting termination process.");

            // Close files
            await _auditRepository.CloseAsync();
            await _dinRepository.CloseAsync();
            await _reapplyRepository.CloseAsync();

            // Populate stats record
            var statsRecord = new StatsRecord
            {
                ReapplyDinCount = _waDinCount,
                PinCount = _waPinCount,
                LinDeleted = _waLinCount,
                TotalExistErrorRec = _waErroredRec,
                TotalRecords = _waDinCount + _waPinCount + _waLinCount + _waErroredRec, // Approximation
                EdbnaeceCpu = _timeService.CpuTime,
                EdbnaeceElapsed = _timeService.ElapsedTime,
                TotalCpuTime = _timeService.CpuTime, // Assuming total equals EDBNAECE CPU
                TotalElapsedTime = _timeService.ElapsedTime,
                LastUpdated = DateTime.UtcNow,
                UpdatedBy = "System"
            };

            await _statsRepository.UpdateStatsAsync(statsRecord);

            // Write detailed stats display records
            var detailRecords = GenerateStatsDetailRecords(statsRecord);
            foreach (var detail in detailRecords)
            {
                await _statsRepository.WriteStatsDetailAsync(detail);
            }

            await _statsRepository.CloseAsync();

            _logger.LogInformation("Termination process completed. DINS to be reapplied: {DinCount}, Records errored out: {ErroredCount}", _waDinCount, _waErroredRec);
        }

        private IEnumerable<StatsDetailRecord> GenerateStatsDetailRecords(StatsRecord stats)
        {
            return new List<StatsDetailRecord>
            {
                new StatsDetailRecord { Header = "NUMBER OF LOW QUALITY INPUT RECORDS  :", Details = stats.LinDeleted.ToString() },
                new StatsDetailRecord { Header = "NUMBER OF TEXT QUALITY INPUT RECORDS :", Details = stats.PinCount.ToString() },
                new StatsDetailRecord { Header = "NUMBER OF ERRORED RECORDS            :", Details = stats.TotalExistErrorRec.ToString() },
                new StatsDetailRecord { Header = "TOTAL NUMBER OF INPUT RECORDS        :", Details = stats.TotalRecords.ToString() },
                new StatsDetailRecord { Header = "NUMBER OF PINS IMPACTED              :", Details = stats.PinCount.ToString() },
                new StatsDetailRecord { Header = "NUMBER OF DINS SENT TO REAPPLY       :", Details = stats.ReapplyDinCount.ToString() },
                new StatsDetailRecord { Header = "NUMBER OF LINS DELETED               :", Details = stats.LinDeleted.ToString() },
                new StatsDetailRecord { Header = "TOTAL CPU TIME                       :", Details = stats.TotalCpuTime.ToString() },
                new StatsDetailRecord { Header = "TOTAL ELAPSED TIME                   :", Details = stats.TotalElapsedTime.ToString() }
            };
        }

        public async Task<IEnumerable<StatsRecord>> GetStatisticsAsync()
        {
            try
            {
                return await _statsRepository.GetAllStatsAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve statistics.");
                throw;
            }
        }

        public async Task<IEnumerable<StatsDetailRecord>> GetStatsDetailsAsync()
        {
            try
            {
                return await _statsRepository.GetAllStatsDetailsAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve stats details.");
                throw;
            }
        }

        public async Task<IEnumerable<ReapplyRecord>> GetReapplyRecordsAsync()
        {
            try
            {
                return await _reapplyRepository.GetAllAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve reapply records.");
                throw;
            }
        }
    }
}