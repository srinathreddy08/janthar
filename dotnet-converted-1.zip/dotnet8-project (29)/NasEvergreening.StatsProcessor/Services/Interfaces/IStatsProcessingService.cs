using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Models.Entities;
using System.Collections.Generic;

namespace NasEvergreening.StatsProcessor.Services.Interfaces
{
    public interface IStatsProcessingService
    {
        Task ProcessAsync(ProcessingParameters parameters);

        Task<IEnumerable<StatsRecord>> GetStatisticsAsync();

        Task<IEnumerable<StatsDetailRecord>> GetStatsDetailsAsync();

        Task<IEnumerable<ReapplyRecord>> GetReapplyRecordsAsync();
    }
}