using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Services.Interfaces
{
    public interface ITimeService
    {
        Task InitializeAsync();
        int CpuTime { get; }
        int ElapsedTime { get; }
    }
}