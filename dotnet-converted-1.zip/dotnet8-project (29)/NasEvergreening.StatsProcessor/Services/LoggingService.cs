using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Services
{
    public class LoggingService : ILoggingService
    {
        private readonly ILogger<LoggingService> _logger;

        public LoggingService(ILogger<LoggingService> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public Task LogInformationAsync(string message, params object[] args)
        {
            _logger.LogInformation(message, args);
            return Task.CompletedTask;
        }

        public Task LogWarningAsync(string message, params object[] args)
        {
            _logger.LogWarning(message, args);
            return Task.CompletedTask;
        }

        public Task LogErrorAsync(string message, params object[] args)
        {
            _logger.LogError(message, args);
            return Task.CompletedTask;
        }

        public Task LogErrorAsync(Exception ex, string message, params object[] args)
        {
            _logger.LogError(ex, message, args);
            return Task.CompletedTask;
        }
    }
}