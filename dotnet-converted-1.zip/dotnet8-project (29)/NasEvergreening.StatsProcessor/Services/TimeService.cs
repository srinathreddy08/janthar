using System;
using System.Diagnostics;
using System.Threading.Tasks;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Services
{
    public class TimeService : ITimeService
    {
        private Stopwatch _stopwatch = new();

        public int CpuTime { get; private set; }
        public int ElapsedTime { get; private set; }

        public Task InitializeAsync()
        {
            _stopwatch.Restart();
            CpuTime = 0;
            ElapsedTime = 0;
            return Task.CompletedTask;
        }

        // This method should be called periodically or at end to update times
        public void UpdateTimes()
        {
            ElapsedTime = (int)_stopwatch.ElapsedMilliseconds;
            // CPU time simulation: for demo, equal to elapsed
            CpuTime = ElapsedTime;
        }
    }
}