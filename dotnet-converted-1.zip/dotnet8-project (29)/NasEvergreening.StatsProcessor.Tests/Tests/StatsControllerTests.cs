using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreening.StatsProcessor.Controllers;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using NUnit.Framework;

namespace NasEvergreening.StatsProcessor.Tests.Controllers
{
    [TestFixture]
    public class StatsControllerTests
    {
        private Mock<IStatsProcessingService> _mockService;
        private Mock<ILogger<StatsController>> _mockLogger;
        private StatsController _controller;

        [SetUp]
        public void Setup()
        {
            _mockService = new Mock<IStatsProcessingService>(MockBehavior.Strict);
            _mockLogger = new Mock<ILogger<StatsController>>();
            _controller = new StatsController(_mockService.Object, _mockLogger.Object);
        }

        [Test]
        public async Task ProcessStats_ValidParameters_ReturnsOk()
        {
            // Arrange
            var parameters = new ProcessingParameters();
            _controller.ModelState.Clear();
            _mockService.Setup(s => s.ProcessAsync(parameters)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.ProcessStats(parameters);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.That(okResult.Value, Is.Not.Null);
            Assert.That(okResult.Value.ToString(), Does.Contain("Statistics processing completed successfully"));
            _mockService.Verify(s => s.ProcessAsync(parameters), Times.Once);
        }

        [Test]
        public async Task ProcessStats_InvalidModelState_ReturnsBadRequest()
        {
            // Arrange
            _controller.ModelState.AddModelError("Key", "Error");
            var parameters = new ProcessingParameters();

            // Act
            var result = await _controller.ProcessStats(parameters);

            // Assert
            Assert.IsInstanceOf<BadRequestObjectResult>(result);
        }

        [Test]
        public async Task ProcessStats_ServiceThrowsException_ReturnsStatusCode500()
        {
            // Arrange
            var parameters = new ProcessingParameters();
            _controller.ModelState.Clear();
            _mockService.Setup(s => s.ProcessAsync(parameters)).ThrowsAsync(new Exception("Service failure"));

            // Act
            var result = await _controller.ProcessStats(parameters);

            // Assert
            Assert.IsInstanceOf<ObjectResult>(result);
            var objResult = (ObjectResult)result;
            Assert.AreEqual(500, objResult.StatusCode);
            Assert.That(objResult.Value.ToString(), Does.Contain("Service failure"));
            _mockService.Verify(s => s.ProcessAsync(parameters), Times.Once);
        }

        [Test]
        public async Task GetStatistics_ReturnsOkWithData()
        {
            // Arrange
            var stats = new List<Models.Entities.StatsRecord> { new Models.Entities.StatsRecord() };
            _mockService.Setup(s => s.GetStatisticsAsync()).ReturnsAsync(stats);

            // Act
            var result = await _controller.GetStatistics();

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.AreSame(stats, okResult.Value);
            _mockService.Verify(s => s.GetStatisticsAsync(), Times.Once);
        }

        [Test]
        public async Task GetStatistics_ServiceThrowsException_ReturnsStatusCode500()
        {
            // Arrange
            _mockService.Setup(s => s.GetStatisticsAsync()).ThrowsAsync(new Exception("Failure"));

            // Act
            var result = await _controller.GetStatistics();

            // Assert
            Assert.IsInstanceOf<ObjectResult>(result);
            var objResult = (ObjectResult)result;
            Assert.AreEqual(500, objResult.StatusCode);
            Assert.That(objResult.Value.ToString(), Does.Contain("Failure"));
            _mockService.Verify(s => s.GetStatisticsAsync(), Times.Once);
        }

        [Test]
        public async Task GetStatsDetails_ReturnsOkWithData()
        {
            // Arrange
            var details = new List<Models.Entities.StatsDetailRecord> { new Models.Entities.StatsDetailRecord() };
            _mockService.Setup(s => s.GetStatsDetailsAsync()).ReturnsAsync(details);

            // Act
            var result = await _controller.GetStatsDetails();

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.AreSame(details, okResult.Value);
            _mockService.Verify(s => s.GetStatsDetailsAsync(), Times.Once);
        }

        [Test]
        public async Task GetStatsDetails_ServiceThrowsException_ReturnsStatusCode500()
        {
            // Arrange
            _mockService.Setup(s => s.GetStatsDetailsAsync()).ThrowsAsync(new Exception("Failure"));

            // Act
            var result = await _controller.GetStatsDetails();

            // Assert
            Assert.IsInstanceOf<ObjectResult>(result);
            var objResult = (ObjectResult)result;
            Assert.AreEqual(500, objResult.StatusCode);
            Assert.That(objResult.Value.ToString(), Does.Contain("Failure"));
            _mockService.Verify(s => s.GetStatsDetailsAsync(), Times.Once);
        }

        [Test]
        public async Task GetReapplyRecords_ReturnsOkWithData()
        {
            // Arrange
            var records = new List<Models.Entities.ReapplyRecord> { new Models.Entities.ReapplyRecord() };
            _mockService.Setup(s => s.GetReapplyRecordsAsync()).ReturnsAsync(records);

            // Act
            var result = await _controller.GetReapplyRecords();

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.AreSame(records, okResult.Value);
            _mockService.Verify(s => s.GetReapplyRecordsAsync(), Times.Once);
        }

        [Test]
        public async Task GetReapplyRecords_ServiceThrowsException_ReturnsStatusCode500()
        {
            // Arrange
            _mockService.Setup(s => s.GetReapplyRecordsAsync()).ThrowsAsync(new Exception("Failure"));

            // Act
            var result = await _controller.GetReapplyRecords();

            // Assert
            Assert.IsInstanceOf<ObjectResult>(result);
            var objResult = (ObjectResult)result;
            Assert.AreEqual(500, objResult.StatusCode);
            Assert.That(objResult.Value.ToString(), Does.Contain("Failure"));
            _mockService.Verify(s => s.GetReapplyRecordsAsync(), Times.Once);
        }
    }
}
