using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreening.StatsProcessor.Controllers;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using Xunit;

namespace NasEvergreening.StatsProcessor.Tests.Controllers
{
    public class StatsControllerTests
    {
        private readonly Mock<IStatsProcessingService> _mockService;
        private readonly Mock<ILogger<StatsController>> _mockLogger;
        private readonly StatsController _controller;

        public StatsControllerTests()
        {
            _mockService = new Mock<IStatsProcessingService>();
            _mockLogger = new Mock<ILogger<StatsController>>();
            _controller = new StatsController(_mockService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessStatistics_ValidParameters_ReturnsOk()
        {
            // Arrange
            var parameters = new ProcessingParametersDto { LoggingLevel = 5, CallMode = "U" };

            // Act
            var result = await _controller.ProcessStatistics(parameters);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);
            Assert.Contains("Statistics processing completed successfully", okResult.Value.ToString());
            _mockService.Verify(s => s.ProcessStatisticsAsync(parameters), Times.Once);
        }

        [Fact]
        public async Task ProcessStatistics_InvalidModelState_ReturnsBadRequest()
        {
            // Arrange
            _controller.ModelState.AddModelError("CallMode", "Required");
            var parameters = new ProcessingParametersDto();

            // Act
            var result = await _controller.ProcessStatistics(parameters);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.NotNull(badRequestResult.Value);
            _mockService.Verify(s => s.ProcessStatisticsAsync(It.IsAny<ProcessingParametersDto>()), Times.Never);
        }

        [Fact]
        public async Task ProcessStatistics_ServiceThrowsArgumentException_ReturnsBadRequestWithError()
        {
            // Arrange
            var parameters = new ProcessingParametersDto { LoggingLevel = 5, CallMode = "U" };
            var exceptionMessage = "Invalid parameter";
            _mockService.Setup(s => s.ProcessStatisticsAsync(parameters))
                .ThrowsAsync(new ArgumentException(exceptionMessage));

            // Act
            var result = await _controller.ProcessStatistics(parameters);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.NotNull(badRequestResult.Value);
            Assert.Contains(exceptionMessage, badRequestResult.Value.ToString());
            _mockService.Verify(s => s.ProcessStatisticsAsync(parameters), Times.Once);
        }

        [Fact]
        public async Task ProcessStatistics_ServiceThrowsException_ReturnsStatusCode500()
        {
            // Arrange
            var parameters = new ProcessingParametersDto { LoggingLevel = 5, CallMode = "U" };
            _mockService.Setup(s => s.ProcessStatisticsAsync(parameters))
                .ThrowsAsync(new Exception("Unexpected error"));

            // Act
            var result = await _controller.ProcessStatistics(parameters);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.NotNull(objectResult.Value);
            Assert.Contains("An unexpected error occurred", objectResult.Value.ToString());
            _mockService.Verify(s => s.ProcessStatisticsAsync(parameters), Times.Once);
        }

        [Fact]
        public async Task GetStatisticsSummary_Successful_ReturnsOkWithData()
        {
            // Arrange
            var expectedData = new { Some = "Data" };
            var processingResult = new ProcessingResultDto
            {
                Success = true,
                Message = "Statistics data retrieved successfully.",
                Data = expectedData
            };
            _mockService.Setup(s => s.GetStatisticsSummaryAsync())
                .ReturnsAsync(processingResult);

            // Act
            var result = await _controller.GetStatisticsSummary();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(expectedData, okResult.Value);
            _mockService.Verify(s => s.GetStatisticsSummaryAsync(), Times.Once);
        }

        [Fact]
        public async Task GetStatisticsSummary_Failure_ReturnsNotFoundWithError()
        {
            // Arrange
            var errorMessage = "No data found";
            var processingResult = new ProcessingResultDto
            {
                Success = false,
                Message = errorMessage,
                Data = null
            };
            _mockService.Setup(s => s.GetStatisticsSummaryAsync())
                .ReturnsAsync(processingResult);

            // Act
            var result = await _controller.GetStatisticsSummary();

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.NotNull(notFoundResult.Value);
            Assert.Contains(errorMessage, notFoundResult.Value.ToString());
            _mockService.Verify(s => s.GetStatisticsSummaryAsync(), Times.Once);
        }
    }
}
