using NasEvergreening.StatsProcessor.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IDinInputRepository
    {
        Task<IEnumerable<DinInputRecord>> GetAllAsync();
        Task<DinInputRecord?> GetByIdAsync(long id);
        Task AddAsync(DinInputRecord dinInputRecord);
        Task UpdateAsync(DinInputRecord dinInputRecord);
        Task DeleteAsync(long id);
    }
}