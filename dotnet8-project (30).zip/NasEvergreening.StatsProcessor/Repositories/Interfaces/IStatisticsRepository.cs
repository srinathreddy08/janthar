using NasEvergreening.StatsProcessor.Models.Entities;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IStatisticsRepository
    {
        Task<StatisticsRecord?> GetLatestAsync();
        Task AddAsync(StatisticsRecord statisticsRecord);
        Task UpdateAsync(StatisticsRecord statisticsRecord);
    }
}