using NasEvergreening.StatsProcessor.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IAuditRepository
    {
        Task<IEnumerable<AuditRecord>> GetAllAsync();
        Task<AuditRecord?> GetByIdAsync(long id);
        Task AddAsync(AuditRecord auditRecord);
        Task UpdateAsync(AuditRecord auditRecord);
        Task DeleteAsync(long id);
    }
}