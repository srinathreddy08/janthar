using NasEvergreening.StatsProcessor.Models.Entities;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Repositories.Interfaces
{
    public interface IReapplyRepository
    {
        Task AddAsync(ReapplyRecord reapplyRecord);
        Task DeleteAllAsync();
    }
}