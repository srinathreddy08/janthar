using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Data;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class ReapplyRepository : IReapplyRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ReapplyRepository> _logger;

        public ReapplyRepository(ApplicationDbContext context, ILogger<ReapplyRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task AddAsync(ReapplyRecord reapplyRecord)
        {
            _logger.LogDebug("Adding new reapply record.");
            await _context.ReapplyRecords.AddAsync(reapplyRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAllAsync()
        {
            _logger.LogDebug("Deleting all reapply records.");
            var allRecords = await _context.ReapplyRecords.ToListAsync();
            _context.ReapplyRecords.RemoveRange(allRecords);
            await _context.SaveChangesAsync();
        }
    }
}