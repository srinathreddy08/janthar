using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Data;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class StatisticsRepository : IStatisticsRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<StatisticsRepository> _logger;

        public StatisticsRepository(ApplicationDbContext context, ILogger<StatisticsRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<StatisticsRecord?> GetLatestAsync()
        {
            _logger.LogDebug("Fetching latest statistics record.");
            return await _context.StatisticsRecords.OrderByDescending(s => s.Id).FirstOrDefaultAsync();
        }

        public async Task AddAsync(StatisticsRecord statisticsRecord)
        {
            _logger.LogDebug("Adding new statistics record.");
            await _context.StatisticsRecords.AddAsync(statisticsRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(StatisticsRecord statisticsRecord)
        {
            _logger.LogDebug("Updating statistics record with Id: {Id}", statisticsRecord.Id);
            _context.StatisticsRecords.Update(statisticsRecord);
            await _context.SaveChangesAsync();
        }
    }
}