using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Data;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class DinInputRepository : IDinInputRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<DinInputRepository> _logger;

        public DinInputRepository(ApplicationDbContext context, ILogger<DinInputRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<DinInputRecord>> GetAllAsync()
        {
            _logger.LogDebug("Fetching all DIN input records.");
            return await _context.DinInputRecords.AsNoTracking().ToListAsync();
        }

        public async Task<DinInputRecord?> GetByIdAsync(long id)
        {
            _logger.LogDebug("Fetching DIN input record by Id: {Id}", id);
            return await _context.DinInputRecords.FindAsync(id);
        }

        public async Task AddAsync(DinInputRecord dinInputRecord)
        {
            _logger.LogDebug("Adding new DIN input record.");
            await _context.DinInputRecords.AddAsync(dinInputRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(DinInputRecord dinInputRecord)
        {
            _logger.LogDebug("Updating DIN input record with Id: {Id}", dinInputRecord.Id);
            _context.DinInputRecords.Update(dinInputRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(long id)
        {
            _logger.LogDebug("Deleting DIN input record with Id: {Id}", id);
            var entity = await _context.DinInputRecords.FindAsync(id);
            if (entity != null)
            {
                _context.DinInputRecords.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}