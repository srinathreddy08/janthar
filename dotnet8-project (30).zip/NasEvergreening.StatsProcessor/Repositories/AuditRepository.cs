using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Data;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Repositories
{
    public class AuditRepository : IAuditRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AuditRepository> _logger;

        public AuditRepository(ApplicationDbContext context, ILogger<AuditRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<AuditRecord>> GetAllAsync()
        {
            _logger.LogDebug("Fetching all audit records.");
            return await _context.AuditRecords.AsNoTracking().ToListAsync();
        }

        public async Task<AuditRecord?> GetByIdAsync(long id)
        {
            _logger.LogDebug("Fetching audit record by Id: {Id}", id);
            return await _context.AuditRecords.FindAsync(id);
        }

        public async Task AddAsync(AuditRecord auditRecord)
        {
            _logger.LogDebug("Adding new audit record.");
            await _context.AuditRecords.AddAsync(auditRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(AuditRecord auditRecord)
        {
            _logger.LogDebug("Updating audit record with Id: {Id}", auditRecord.Id);
            _context.AuditRecords.Update(auditRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(long id)
        {
            _logger.LogDebug("Deleting audit record with Id: {Id}", id);
            var entity = await _context.AuditRecords.FindAsync(id);
            if (entity != null)
            {
                _context.AuditRecords.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}