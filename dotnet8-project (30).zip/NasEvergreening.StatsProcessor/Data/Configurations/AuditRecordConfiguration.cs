using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Data.Configurations
{
    public class AuditRecordConfiguration : IEntityTypeConfiguration<AuditRecord>
    {
        public void Configure(EntityTypeBuilder<AuditRecord> builder)
        {
            builder.ToTable("Audit");

            builder.HasKey(a => a.Id);

            builder.Property(a => a.AudError).IsRequired();
            builder.Property(a => a.AudProcessed).IsRequired();
            builder.Property(a => a.AudPinCount).IsRequired();
            builder.Property(a => a.AudNonStdLinCount).IsRequired();

            builder.Property(a => a.CreatedDate).IsRequired();
            builder.Property(a => a.CreatedBy).HasMaxLength(50).IsRequired();
            builder.Property(a => a.ModifiedDate);
            builder.Property(a => a.ModifiedBy).HasMaxLength(50);

            builder.HasIndex(a => a.AudProcessed);
            builder.HasIndex(a => a.AudError);
        }
    }
}