using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Data.Configurations
{
    public class DinInputRecordConfiguration : IEntityTypeConfiguration<DinInputRecord>
    {
        public void Configure(EntityTypeBuilder<DinInputRecord> builder)
        {
            builder.ToTable("DinInput");

            builder.HasKey(d => d.Id);

            builder.Property(d => d.Din).HasColumnType("decimal(18,0)").IsRequired();
            builder.Property(d => d.SubjNb).IsRequired();
            builder.Property(d => d.SubjSeqNb).IsRequired();

            builder.Property(d => d.CreatedDate).IsRequired();
            builder.Property(d => d.CreatedBy).HasMaxLength(50).IsRequired();
            builder.Property(d => d.ModifiedDate);
            builder.Property(d => d.ModifiedBy).HasMaxLength(50);

            builder.HasIndex(d => d.Din);
        }
    }
}