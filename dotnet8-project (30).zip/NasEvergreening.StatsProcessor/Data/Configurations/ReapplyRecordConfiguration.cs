using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Data.Configurations
{
    public class ReapplyRecordConfiguration : IEntityTypeConfiguration<ReapplyRecord>
    {
        public void Configure(EntityTypeBuilder<ReapplyRecord> builder)
        {
            builder.ToTable("Reapply");

            builder.HasKey(r => r.Id);

            builder.Property(r => r.Din).HasColumnType("decimal(18,0)").IsRequired();
            builder.Property(r => r.SrcProcess).HasMaxLength(4).IsRequired();
            builder.Property(r => r.RunDate).IsRequired();
            builder.Property(r => r.NoOfSubj).IsRequired();
            builder.Property(r => r.SubjNb1).IsRequired();
            builder.Property(r => r.SubjSeq1).IsRequired();
            builder.Property(r => r.SubjNb2);
            builder.Property(r => r.SubjSeq2);

            builder.Property(r => r.CreatedDate).IsRequired();
            builder.Property(r => r.CreatedBy).HasMaxLength(50).IsRequired();
            builder.Property(r => r.ModifiedDate);
            builder.Property(r => r.ModifiedBy).HasMaxLength(50);

            builder.HasIndex(r => r.Din);
        }
    }
}