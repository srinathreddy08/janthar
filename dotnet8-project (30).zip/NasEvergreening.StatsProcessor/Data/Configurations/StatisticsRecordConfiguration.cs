using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Data.Configurations
{
    public class StatisticsRecordConfiguration : IEntityTypeConfiguration<StatisticsRecord>
    {
        public void Configure(EntityTypeBuilder<StatisticsRecord> builder)
        {
            builder.ToTable("Statistics");

            builder.HasKey(s => s.Id);

            builder.Property(s => s.ReapplyDinCount).IsRequired();
            builder.Property(s => s.PinCount).IsRequired();
            builder.Property(s => s.LinDeleted).IsRequired();
            builder.Property(s => s.TotalExistErrorRec).IsRequired();

            builder.Property(s => s.CpuTime).IsRequired();
            builder.Property(s => s.ElapsedTime).IsRequired();
            builder.Property(s => s.TotalTimeCpu).IsRequired();
            builder.Property(s => s.TotalTimeElp).IsRequired();

            builder.Property(s => s.LqRec).IsRequired();
            builder.Property(s => s.TxtRec).IsRequired();
            builder.Property(s => s.TotalRecords).IsRequired();
            builder.Property(s => s.UnchngdAddr).IsRequired();
            builder.Property(s => s.TxtLqAinUnchg).IsRequired();
            builder.Property(s => s.LqHqAinUnchg).IsRequired();
            builder.Property(s => s.UnchgLqAinChgd).IsRequired();
            builder.Property(s => s.TxtLqAinChg).IsRequired();
            builder.Property(s => s.LqHqAinChg).IsRequired();
            builder.Property(s => s.TxtHqAinChg).IsRequired();

            builder.Property(s => s.CreatedDate).IsRequired();
            builder.Property(s => s.CreatedBy).HasMaxLength(50).IsRequired();
            builder.Property(s => s.ModifiedDate);
            builder.Property(s => s.ModifiedBy).HasMaxLength(50);
        }
    }
}