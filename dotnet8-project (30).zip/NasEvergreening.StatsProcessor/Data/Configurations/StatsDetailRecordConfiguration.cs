using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreening.StatsProcessor.Models.Entities;

namespace NasEvergreening.StatsProcessor.Data.Configurations
{
    public class StatsDetailRecordConfiguration : IEntityTypeConfiguration<StatsDetailRecord>
    {
        public void Configure(EntityTypeBuilder<StatsDetailRecord> builder)
        {
            builder.ToTable("StatsDetail");

            builder.HasKey(sd => sd.Id);

            builder.Property(sd => sd.Header).HasMaxLength(40).IsRequired();
            builder.Property(sd => sd.Details).HasMaxLength(50).IsRequired();

            builder.Property(sd => sd.CreatedDate).IsRequired();
            builder.Property(sd => sd.CreatedBy).HasMaxLength(50).IsRequired();
            builder.Property(sd => sd.ModifiedDate);
            builder.Property(sd => sd.ModifiedBy).HasMaxLength(50);
        }
    }
}