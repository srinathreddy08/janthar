using Microsoft.EntityFrameworkCore;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Data.Configurations;

namespace NasEvergreening.StatsProcessor.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<AuditRecord> AuditRecords { get; set; } = null!;
        public DbSet<DinInputRecord> DinInputRecords { get; set; } = null!;
        public DbSet<StatisticsRecord> StatisticsRecords { get; set; } = null!;
        public DbSet<StatsDetailRecord> StatsDetailRecords { get; set; } = null!;
        public DbSet<ReapplyRecord> ReapplyRecords { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AuditRecordConfiguration());
            modelBuilder.ApplyConfiguration(new DinInputRecordConfiguration());
            modelBuilder.ApplyConfiguration(new StatisticsRecordConfiguration());
            modelBuilder.ApplyConfiguration(new StatsDetailRecordConfiguration());
            modelBuilder.ApplyConfiguration(new ReapplyRecordConfiguration());

            base.OnModelCreating(modelBuilder);
        }
    }
}