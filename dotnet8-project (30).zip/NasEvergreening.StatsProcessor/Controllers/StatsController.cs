using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Services.Interfaces;
using System;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatsController : ControllerBase
    {
        private readonly IStatsProcessingService _statsProcessingService;
        private readonly ILogger<StatsController> _logger;

        public StatsController(IStatsProcessingService statsProcessingService, ILogger<StatsController> logger)
        {
            _statsProcessingService = statsProcessingService;
            _logger = logger;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessStatistics([FromBody] ProcessingParametersDto parameters)
        {
            _logger.LogInformation("Received request to process statistics.");

            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid model state for processing parameters.");
                return BadRequest(ModelState);
            }

            try
            {
                await _statsProcessingService.ProcessStatisticsAsync(parameters);
                return Ok(new { Message = "Statistics processing completed successfully." });
            }
            catch (ArgumentException ex)
            {
                _logger.LogWarning(ex, "Validation error during statistics processing.");
                return BadRequest(new { Error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during statistics processing.");
                return StatusCode(500, new { Error = "An unexpected error occurred." });
            }
        }

        [HttpGet("summary")]
        public async Task<IActionResult> GetStatisticsSummary()
        {
            _logger.LogInformation("Received request to get statistics summary.");

            var result = await _statsProcessingService.GetStatisticsSummaryAsync();

            if (!result.Success)
            {
                _logger.LogWarning("Statistics summary retrieval failed: {Message}", result.Message);
                return NotFound(new { Error = result.Message });
            }

            return Ok(result.Data);
        }
    }
}