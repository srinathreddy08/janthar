using NasEvergreening.StatsProcessor.Models.DTOs;
using System.Threading.Tasks;

namespace NasEvergreening.StatsProcessor.Services.Interfaces
{
    public interface IStatsProcessingService
    {
        Task ProcessStatisticsAsync(ProcessingParametersDto parameters);
        Task<ProcessingResultDto> GetStatisticsSummaryAsync();
    }

    public class ProcessingResultDto
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public object? Data { get; set; }
    }
}