using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreening.StatsProcessor.Models.DTOs;
using NasEvergreening.StatsProcessor.Models.Entities;
using NasEvergreening.StatsProcessor.Repositories.Interfaces;
using NasEvergreening.StatsProcessor.Services.Interfaces;

namespace NasEvergreening.StatsProcessor.Services
{
    public class StatsProcessingService : IStatsProcessingService
    {
        private readonly IAuditRepository _auditRepository;
        private readonly IDinInputRepository _dinInputRepository;
        private readonly IStatisticsRepository _statisticsRepository;
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ILogger<StatsProcessingService> _logger;

        public StatsProcessingService(
            IAuditRepository auditRepository,
            IDinInputRepository dinInputRepository,
            IStatisticsRepository statisticsRepository,
            IReapplyRepository reapplyRepository,
            ILogger<StatsProcessingService> logger)
        {
            _auditRepository = auditRepository;
            _dinInputRepository = dinInputRepository;
            _statisticsRepository = statisticsRepository;
            _reapplyRepository = reapplyRepository;
            _logger = logger;
        }

        public async Task ProcessStatisticsAsync(ProcessingParametersDto parameters)
        {
            _logger.LogInformation("Starting statistics processing with LoggingLevel={LoggingLevel} and CallMode={CallMode}", parameters.LoggingLevel, parameters.CallMode);

            if (parameters == null)
                throw new ArgumentNullException(nameof(parameters), "Processing parameters cannot be null.");

            if (parameters.LoggingLevel < 0 || parameters.LoggingLevel > 9)
                throw new ArgumentOutOfRangeException(nameof(parameters.LoggingLevel), "LoggingLevel must be between 0 and 9.");

            if (parameters.CallMode != "U" && parameters.CallMode != "R")
                throw new ArgumentException("CallMode must be 'U' (Update) or 'R' (Read).", nameof(parameters.CallMode));

            try
            {
                // Initialize accumulators
                int waDinCount = 0;
                int waPinCount = 0;
                int waLinCount = 0;
                int waErroredRec = 0;

                // Read all audit records
                var auditRecords = await _auditRepository.GetAllAsync();

                foreach (var audit in auditRecords)
                {
                    if (audit == null) continue;

                    if (audit.AudError)
                    {
                        waErroredRec += 1;
                    }
                    else if (audit.AudProcessed)
                    {
                        waPinCount += audit.AudPinCount;
                        waLinCount += audit.AudNonStdLinCount;
                    }
                }

                // Read all DIN input records
                var dinRecords = await _dinInputRepository.GetAllAsync();

                // Clear existing reapply records if update mode
                if (parameters.CallMode == "U")
                {
                    await _reapplyRepository.DeleteAllAsync();
                }

                foreach (var din in dinRecords)
                {
                    if (din == null) continue;

                    waDinCount++;

                    if (parameters.CallMode == "U")
                    {
                        // Prepare reapply record
                        var reapplyRecord = new ReapplyRecord
                        {
                            Din = din.Din,
                            SrcProcess = ExtractSrcProcessFromDin(din.Din),
                            RunDate = DateTime.UtcNow.Date,
                            NoOfSubj = 1,
                            SubjNb1 = din.SubjNb,
                            SubjSeq1 = din.SubjSeqNb,
                            CreatedDate = DateTime.UtcNow,
                            CreatedBy = "System"
                        };

                        // Additional logic for SrcProcess values 80,60,70,50
                        if (new[] { 80, 60, 70, 50 }.Contains(ParseSrcProcessCode(reapplyRecord.SrcProcess)))
                        {
                            reapplyRecord.NoOfSubj = 2;
                            reapplyRecord.SubjNb2 = 2;
                            reapplyRecord.SubjSeq2 = din.SubjSeqNb;
                        }

                        await _reapplyRepository.AddAsync(reapplyRecord);
                    }
                }

                // Update statistics record
                var stats = await _statisticsRepository.GetLatestAsync() ?? new StatisticsRecord
                {
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "System"
                };

                stats.ReapplyDinCount = waDinCount;
                stats.PinCount = waPinCount;
                stats.LinDeleted = waLinCount;
                stats.TotalExistErrorRec = waErroredRec;

                // Simulate CPU and elapsed time measurement
                var cpuTime = GetCpuTime();
                var elapsedTime = GetElapsedTime();

                stats.CpuTime = cpuTime;
                stats.ElapsedTime = elapsedTime;

                stats.TotalTimeCpu += cpuTime;
                stats.TotalTimeElp += elapsedTime;

                stats.ModifiedDate = DateTime.UtcNow;
                stats.ModifiedBy = "System";

                if (stats.Id == 0)
                {
                    await _statisticsRepository.AddAsync(stats);
                }
                else
                {
                    await _statisticsRepository.UpdateAsync(stats);
                }

                _logger.LogInformation("Statistics processing completed successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during statistics processing.");
                throw;
            }
        }

        public async Task<ProcessingResultDto> GetStatisticsSummaryAsync()
        {
            try
            {
                var stats = await _statisticsRepository.GetLatestAsync();
                if (stats == null)
                {
                    return new ProcessingResultDto
                    {
                        Success = false,
                        Message = "No statistics data found.",
                        Data = null
                    };
                }

                return new ProcessingResultDto
                {
                    Success = true,
                    Message = "Statistics data retrieved successfully.",
                    Data = stats
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving statistics summary.");
                return new ProcessingResultDto
                {
                    Success = false,
                    Message = "Error retrieving statistics summary: " + ex.Message
                };
            }
        }

        private string ExtractSrcProcessFromDin(decimal din)
        {
            // Extract substring from DIN numeric value as string
            var dinStr = din.ToString("F0");
            if (dinStr.Length >= 10)
            {
                return dinStr.Substring(6, 4); // 7th to 10th character (0-based index 6)
            }
            return string.Empty;
        }

        private int ParseSrcProcessCode(string srcProcess)
        {
            if (int.TryParse(srcProcess, out int code))
                return code;
            return -1;
        }

        private long GetCpuTime()
        {
            // Placeholder for CPU time measurement logic
            // In real implementation, integrate with performance counters or diagnostics
            return DateTime.UtcNow.Ticks % 1000000; // Simulated value
        }

        private long GetElapsedTime()
        {
            // Placeholder for elapsed time measurement logic
            return DateTime.UtcNow.Ticks % 1000000; // Simulated value
        }
    }
}