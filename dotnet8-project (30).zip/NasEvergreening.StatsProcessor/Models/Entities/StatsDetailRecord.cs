using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("StatsDetail")]
    public class StatsDetailRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(40)]
        public string Header { get; set; } = string.Empty; // STAD-HEADER

        [Required]
        [StringLength(50)]
        public string Details { get; set; } = string.Empty; // STAD-DETAILS

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(50)]
        public string? ModifiedBy { get; set; }
    }
}