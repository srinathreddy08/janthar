using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("Statistics")]
    public class StatisticsRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        // Accumulated counts
        public int ReapplyDinCount { get; set; } // STAT-REAPPLY-DIN-CT
        public int PinCount { get; set; } // STAT-PIN-CT
        public int LinDeleted { get; set; } // STAT-LIN-DELETED
        public int TotalExistErrorRec { get; set; } // STAT-TOTAL-EXIST-ERROR-REC

        // Timing info
        public long CpuTime { get; set; } // STAT-EDBNAECE-CPU
        public long ElapsedTime { get; set; } // STAT-EDBNAECE-ELP

        public long TotalTimeCpu { get; set; } // STAT-TOTAL-TIME-CPU
        public long TotalTimeElp { get; set; } // STAT-TOTAL-TIME-ELP

        // Additional statistics fields from COBOL headers
        public int LqRec { get; set; } // STAT-LQ-REC
        public int TxtRec { get; set; } // STAT-TXT-REC
        public int TotalRecords { get; set; } // STAT-TOTAL-RECORDS
        public int UnchngdAddr { get; set; } // STAT-UNCHNGD-ADDR
        public int TxtLqAinUnchg { get; set; } // STAT-TXT-LQ-AIN-UNCHG
        public int LqHqAinUnchg { get; set; } // STAT-LQ-HQ-AIN-UNCHG
        public int UnchgLqAinChgd { get; set; } // STAT-UNCHG-LQ-AIN-CHGD
        public int TxtLqAinChg { get; set; } // STAT-TXT-LQ-AIN-CHG
        public int LqHqAinChg { get; set; } // STAT-LQ-HQ-AIN-CHG
        public int TxtHqAinChg { get; set; } // STAT-TXT-HQ-AIN-CHG

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(50)]
        public string? ModifiedBy { get; set; }
    }
}