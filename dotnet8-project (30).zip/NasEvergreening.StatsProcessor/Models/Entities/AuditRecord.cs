using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("Audit")]
    public class AuditRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        // Assuming fields from EDFNAECB copybook mapped here
        // Example fields based on usage in COBOL

        [Required]
        public bool AudError { get; set; } // AUD-ERROR flag

        [Required]
        public bool AudProcessed { get; set; } // AUD-PROCESSED flag

        [Range(0, int.MaxValue)]
        public int AudPinCount { get; set; } // AUD-PIN-COUNT

        [Range(0, int.MaxValue)]
        public int AudNonStdLinCount { get; set; } // AUD-NON-STD-LIN-COUNT

        // Additional audit fields as needed

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(50)]
        public string? ModifiedBy { get; set; }
    }
}