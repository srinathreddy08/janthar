using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("Reapply")]
    public class ReapplyRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,0)")]
        public decimal Din { get; set; } // REPL-DIN

        [StringLength(4)]
        public string SrcProcess { get; set; } = string.Empty; // REPL-SRC-PROCESS

        [Required]
        public DateTime RunDate { get; set; } // REPL-RUN-DATE

        [Required]
        public int NoOfSubj { get; set; } // REPL-NO-OF-SUBJ

        [Required]
        public int SubjNb1 { get; set; } // REPL-SUBJ-NB(1)

        [Required]
        public int SubjSeq1 { get; set; } // REPL-SUBJ-SEQ(1)

        public int? SubjNb2 { get; set; } // REPL-SUBJ-NB(2) optional

        public int? SubjSeq2 { get; set; } // REPL-SUBJ-SEQ(2) optional

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(50)]
        public string? ModifiedBy { get; set; }
    }
}