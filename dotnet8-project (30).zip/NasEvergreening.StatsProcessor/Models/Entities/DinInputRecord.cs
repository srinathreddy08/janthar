using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreening.StatsProcessor.Models.Entities
{
    [Table("DinInput")]
    public class DinInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,0)")]
        public decimal Din { get; set; } // D-INP-DIN PIC S9(18) COMP

        [Required]
        public int SubjNb { get; set; } // D-INP-SUBJ-NB PIC S9(04) COMP

        [Required]
        public int SubjSeqNb { get; set; } // D-INP-SUBJ-SEQ-NB PIC S9(04) COMP

        // Audit fields
        [Required]
        public DateTime CreatedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        public DateTime? ModifiedDate { get; set; }

        [StringLength(50)]
        public string? ModifiedBy { get; set; }
    }
}