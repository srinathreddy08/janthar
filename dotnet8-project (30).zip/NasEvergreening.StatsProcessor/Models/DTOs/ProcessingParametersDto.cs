using System.ComponentModel.DataAnnotations;

namespace NasEvergreening.StatsProcessor.Models.DTOs
{
    public class ProcessingParametersDto
    {
        [Required]
        [Range(0, 9, ErrorMessage = "LoggingLevel must be between 0 and 9.")]
        public int LoggingLevel { get; set; }

        [Required]
        [RegularExpression("[UR]", ErrorMessage = "CallMode must be 'U' (Update) or 'R' (Read).")]
        public string CallMode { get; set; } = string.Empty;
    }
}