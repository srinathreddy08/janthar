using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("StatisticsRecords")]
    public class StatisticsRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int ReapplyDinCount { get; set; }

        public int PinCount { get; set; }

        public int LinDeletedCount { get; set; }

        public int TotalExistErrorRecords { get; set; }

        public long CpuTime { get; set; } // CPU time in milliseconds or ticks

        public long ElapsedTime { get; set; } // Elapsed time in milliseconds or ticks

        public long TotalCpuTime { get; set; }

        public long TotalElapsedTime { get; set; }

        // Additional statistics fields from COBOL headers can be added here

        // Audit fields
        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        [StringLength(50)]
        public string ModifiedBy { get; set; } = string.Empty;
    }
}