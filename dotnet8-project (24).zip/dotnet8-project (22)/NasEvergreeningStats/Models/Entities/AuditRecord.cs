using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("AuditRecords")]
    public class AuditRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, StringLength(8)]
        public string ProcStartDate { get; set; } = string.Empty; // N-PROC-START-DT PIC X(08)

        [Required, StringLength(4)]
        public string ProcStartTime { get; set; } = string.Empty; // N-PROC-START-TM PIC X(4)

        [Required]
        public long NasevgDin { get; set; } // N-NASEVG-DIN PIC S9(18) COMP

        [Required]
        public long SrcDin { get; set; } // N-SRC-DIN PIC S9(18) COMP

        [Required]
        public short SrcSubjIdNb { get; set; } // N-SRC-SUBJ-ID-NB PIC S9(4) COMP

        [Required]
        public short SrcSubjSeqNb { get; set; } // N-SRC-SUBJ-SEQ-NB PIC S9(4) COMP

        [Required]
        public long SrcRef { get; set; } // N-SRC-REF PIC S9(18) COMP

        [Required, StringLength(440)]
        public string SrcName { get; set; } = string.Empty; // N-SRC-NAME PIC X(440)

        [Required]
        public int SrcAin { get; set; } // N-SRC-AIN PIC S9(9) COMP

        [Required, StringLength(1)]
        public string AddrQty { get; set; } = string.Empty; // N-ADDR-QTY PIC X(1)

        [Required, StringLength(2)]
        public string SrcAddrFrmtCd { get; set; } = string.Empty; // N-SRC-ADDR-FRMT-CD PIC X(2)

        [Required, StringLength(440)]
        public string SrcAddr { get; set; } = string.Empty; // N-SRC-ADDR PIC X(440)

        // Formatted Address Fields
        [Required, StringLength(150)]
        public string SrcNm { get; set; } = string.Empty; // N-SRC-NM PIC X(150)

        [Required, StringLength(60)]
        public string AddrLine1 { get; set; } = string.Empty; // N-ADDR-LINE1 PIC X(60)

        [Required, StringLength(60)]
        public string AddrLine2 { get; set; } = string.Empty; // N-ADDR-LINE2 PIC X(60)

        [Required, StringLength(60)]
        public string AddrLine3 { get; set; } = string.Empty; // N-ADDR-LINE3 PIC X(60)

        [Required, StringLength(60)]
        public string AddrLine4 { get; set; } = string.Empty; // N-ADDR-LINE4 PIC X(60)

        [Required, StringLength(60)]
        public string AddrLine5 { get; set; } = string.Empty; // N-ADDR-LINE5 PIC X(60)

        [Required, StringLength(112)]
        public string AddrLine6 { get; set; } = string.Empty; // N-ADDR-LINE6 PIC X(112)

        [Required, StringLength(8)]
        public string AddrLine7 { get; set; } = string.Empty; // N-ADDR-LINE7 PIC X(8)

        [Required]
        public int AinFromNas { get; set; } // N-AIN-FROM-NAS PIC S9(9) COMP

        [Required, StringLength(1)]
        public string QtyFromNas { get; set; } = string.Empty; // N-QTY-FROM-NAS PIC X(1)

        [Required, StringLength(1)]
        public string AinChangeFlag { get; set; } = string.Empty; // N-AIN-CHANGE-FLAG PIC X(1)

        [Required, StringLength(1)]
        public string DinFoundFlag { get; set; } = string.Empty; // N-DIN-FOUND-FLAG PIC X(1)

        [Required, StringLength(4)]
        public string ErrorCode { get; set; } = string.Empty; // N-ERROR-CODE PIC X(4)

        [Required, StringLength(1)]
        public string ProcessStg { get; set; } = string.Empty; // N-PROCESS-STG PIC X(1)

        [Required, StringLength(1)]
        public string FieldIndicator { get; set; } = string.Empty; // N-FIELD-INDICATOR PIC X(1)

        [Required, StringLength(5)]
        public string DataProvider { get; set; } = string.Empty; // N-DATA-PROVIDER PIC X(5)

        [Required]
        public int SequenceNb { get; set; } // N-SEQUENCE-NB PIC 9(6)

        [Required]
        public short PinCount { get; set; } // N-PIN-COUNT PIC S9(4) COMP

        [Required]
        public short NonStdLinCount { get; set; } // N-NON-STD-LIN-COUNT PIC S9(4) COMP

        [Required]
        public short DinCount { get; set; } // N-DIN-COUNT PIC S9(4) COMP

        // Collections for OCCURS
        public List<long> PinArray { get; set; } = new(); // N-PIN-ARRAY OCCURS

        public List<long> LinArray { get; set; } = new(); // N-LIN-ARRAY OCCURS

        public List<AuditDinReapply> DinReapply { get; set; } = new(); // N-DIN-REAPPLY OCCURS

        // Audit fields
        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        [StringLength(50)]
        public string ModifiedBy { get; set; } = string.Empty;
    }

    public class AuditDinReapply
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public long Din { get; set; } // N-DIN PIC S9(18) COMP

        [Required]
        public short SubjIdNb { get; set; } // N-SUBJ-ID-NB PIC S9(4) COMP

        [Required]
        public short SubjIdSeqNb { get; set; } // N-SUBJ-ID-SEQ-NB PIC S9(4) COMP

        [ForeignKey("AuditRecord")]
        public int AuditRecordId { get; set; }

        public AuditRecord? AuditRecord { get; set; }
    }
}