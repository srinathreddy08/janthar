using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("ReapplyRecords")]
    public class ReapplyRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public long Din { get; set; }

        [Required]
        public short SubjNb { get; set; }

        [Required]
        public short SubjSeqNb { get; set; }

        [Required, StringLength(50)]
        public string SrcProcess { get; set; } = string.Empty;

        [Required]
        public DateTime RunDate { get; set; }

        [Required]
        public int NoOfSubj { get; set; }

        // Audit fields
        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        [StringLength(50)]
        public string ModifiedBy { get; set; } = string.Empty;
    }
}