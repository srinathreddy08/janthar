using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("DinInputRecords")]
    public class DinInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        public long Din { get; set; } // D-INP-DIN PIC S9(18) COMP

        [Required]
        public short SubjNb { get; set; } // D-INP-SUBJ-NB PIC S9(4) COMP

        [Required]
        public short SubjSeqNb { get; set; } // D-INP-SUBJ-SEQ-NB PIC S9(4) COMP

        // Audit fields
        public DateTime CreatedDate { get; set; }

        public DateTime ModifiedDate { get; set; }

        [StringLength(50)]
        public string CreatedBy { get; set; } = string.Empty;

        [StringLength(50)]
        public string ModifiedBy { get; set; } = string.Empty;
    }
}