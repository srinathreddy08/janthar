using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories
{
    public class AuditRepository : IAuditRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AuditRepository> _logger;

        public AuditRepository(ApplicationDbContext context, ILogger<AuditRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<AuditRecord>> GetAllAsync()
        {
            _logger.LogInformation("Retrieving all audit records");
            return await _context.AuditRecords
                .Include(a => a.DinReapply)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<AuditRecord?> GetByIdAsync(int id)
        {
            _logger.LogInformation("Retrieving audit record by id: {Id}", id);
            return await _context.AuditRecords
                .Include(a => a.DinReapply)
                .AsNoTracking()
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task AddAsync(AuditRecord auditRecord)
        {
            _logger.LogInformation("Adding new audit record");
            await _context.AuditRecords.AddAsync(auditRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(AuditRecord auditRecord)
        {
            _logger.LogInformation("Updating audit record with id: {Id}", auditRecord.Id);
            _context.AuditRecords.Update(auditRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            _logger.LogInformation("Deleting audit record with id: {Id}", id);
            var entity = await _context.AuditRecords.FindAsync(id);
            if (entity != null)
            {
                _context.AuditRecords.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}