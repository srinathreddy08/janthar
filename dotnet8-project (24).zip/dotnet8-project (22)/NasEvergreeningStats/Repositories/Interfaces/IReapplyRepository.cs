using NasEvergreeningStats.Models.Entities;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IReapplyRepository
    {
        Task AddAsync(ReapplyRecord reapplyRecord);
    }
}