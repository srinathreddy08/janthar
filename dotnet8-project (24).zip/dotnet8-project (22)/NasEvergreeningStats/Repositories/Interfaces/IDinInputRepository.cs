using NasEvergreeningStats.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IDinInputRepository
    {
        Task<IEnumerable<DinInputRecord>> GetAllAsync();
        Task<DinInputRecord?> GetByIdAsync(int id);
        Task AddAsync(DinInputRecord dinInputRecord);
        Task UpdateAsync(DinInputRecord dinInputRecord);
        Task DeleteAsync(int id);
    }
}