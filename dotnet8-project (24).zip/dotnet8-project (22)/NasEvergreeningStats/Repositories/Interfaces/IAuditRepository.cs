using NasEvergreeningStats.Models.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IAuditRepository
    {
        Task<IEnumerable<AuditRecord>> GetAllAsync();
        Task<AuditRecord?> GetByIdAsync(int id);
        Task AddAsync(AuditRecord auditRecord);
        Task UpdateAsync(AuditRecord auditRecord);
        Task DeleteAsync(int id);
    }
}