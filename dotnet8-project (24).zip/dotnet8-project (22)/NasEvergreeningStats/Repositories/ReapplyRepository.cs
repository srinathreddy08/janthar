using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories
{
    public class ReapplyRepository : IReapplyRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ReapplyRepository> _logger;

        public ReapplyRepository(ApplicationDbContext context, ILogger<ReapplyRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task AddAsync(ReapplyRecord reapplyRecord)
        {
            _logger.LogInformation("Adding new reapply record for DIN: {Din}", reapplyRecord.Din);
            await _context.ReapplyRecords.AddAsync(reapplyRecord);
            await _context.SaveChangesAsync();
        }
    }
}