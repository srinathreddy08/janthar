using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Repositories
{
    public class DinInputRepository : IDinInputRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<DinInputRepository> _logger;

        public DinInputRepository(ApplicationDbContext context, ILogger<DinInputRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<DinInputRecord>> GetAllAsync()
        {
            _logger.LogInformation("Retrieving all DIN input records");
            return await _context.DinInputRecords.AsNoTracking().ToListAsync();
        }

        public async Task<DinInputRecord?> GetByIdAsync(int id)
        {
            _logger.LogInformation("Retrieving DIN input record by id: {Id}", id);
            return await _context.DinInputRecords.AsNoTracking().FirstOrDefaultAsync(d => d.Id == id);
        }

        public async Task AddAsync(DinInputRecord dinInputRecord)
        {
            _logger.LogInformation("Adding new DIN input record");
            await _context.DinInputRecords.AddAsync(dinInputRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(DinInputRecord dinInputRecord)
        {
            _logger.LogInformation("Updating DIN input record with id: {Id}", dinInputRecord.Id);
            _context.DinInputRecords.Update(dinInputRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            _logger.LogInformation("Deleting DIN input record with id: {Id}", id);
            var entity = await _context.DinInputRecords.FindAsync(id);
            if (entity != null)
            {
                _context.DinInputRecords.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}