using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Services.Interfaces;
using System;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuditController : ControllerBase
    {
        private readonly IAuditProcessingService _auditProcessingService;
        private readonly ILogger<AuditController> _logger;

        public AuditController(IAuditProcessingService auditProcessingService, ILogger<AuditController> logger)
        {
            _auditProcessingService = auditProcessingService;
            _logger = logger;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessAuditAsync([FromQuery] string callMode, [FromQuery] int loggingLevel)
        {
            _logger.LogInformation("Received request to process audit with callMode: {CallMode}, loggingLevel: {LoggingLevel}", callMode, loggingLevel);

            if (string.IsNullOrWhiteSpace(callMode))
            {
                return BadRequest("Call mode parameter is required.");
            }

            if (loggingLevel < 0)
            {
                return BadRequest("Logging level must be non-negative.");
            }

            try
            {
                await _auditProcessingService.ProcessAuditAndDinFilesAsync(callMode, loggingLevel);
                return Ok(new { Message = "Audit and DIN files processed successfully." });
            }
            catch (ArgumentException ex)
            {
                _logger.LogWarning(ex, "Validation error during audit processing");
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error during audit processing");
                return StatusCode(500, "An unexpected error occurred while processing audit files.");
            }
        }
    }
}