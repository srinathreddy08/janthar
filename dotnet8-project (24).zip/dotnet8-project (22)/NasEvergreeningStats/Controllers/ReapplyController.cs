using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Repositories.Interfaces;
using System;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReapplyController : ControllerBase
    {
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ILogger<ReapplyController> _logger;

        public ReapplyController(IReapplyRepository reapplyRepository, ILogger<ReapplyController> logger)
        {
            _reapplyRepository = reapplyRepository;
            _logger = logger;
        }

        // Endpoint to add a reapply record manually if needed
        [HttpPost]
        public async Task<IActionResult> AddReapplyRecord([FromBody] Models.Entities.ReapplyRecord reapplyRecord)
        {
            if (reapplyRecord == null)
            {
                return BadRequest("Reapply record cannot be null.");
            }

            try
            {
                await _reapplyRepository.AddAsync(reapplyRecord);
                return Ok(new { Message = "Reapply record added successfully." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding reapply record");
                return StatusCode(500, "An error occurred while adding reapply record.");
            }
        }
    }
}