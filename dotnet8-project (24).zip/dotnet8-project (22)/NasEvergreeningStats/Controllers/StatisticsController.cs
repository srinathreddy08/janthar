using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Services.Interfaces;
using System;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatisticsController : ControllerBase
    {
        private readonly IAuditProcessingService _auditProcessingService;
        private readonly ILogger<StatisticsController> _logger;

        public StatisticsController(IAuditProcessingService auditProcessingService, ILogger<StatisticsController> logger)
        {
            _auditProcessingService = auditProcessingService;
            _logger = logger;
        }

        [HttpGet("display")]
        public async Task<IActionResult> GetDisplayStatisticsAsync()
        {
            _logger.LogInformation("Received request to get display statistics");

            try
            {
                var stats = await _auditProcessingService.GetDisplayStatisticsAsync();
                return Ok(stats);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving display statistics");
                return StatusCode(500, "An error occurred while retrieving statistics.");
            }
        }
    }
}