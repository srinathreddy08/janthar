using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data.Configurations
{
    public class AuditRecordConfiguration : IEntityTypeConfiguration<AuditRecord>
    {
        public void Configure(EntityTypeBuilder<AuditRecord> builder)
        {
            builder.ToTable("AuditRecords");

            builder.HasKey(a => a.Id);

            builder.Property(a => a.ProcStartDate).HasMaxLength(8).IsRequired();
            builder.Property(a => a.ProcStartTime).HasMaxLength(4).IsRequired();
            builder.Property(a => a.NasevgDin).IsRequired();
            builder.Property(a => a.SrcDin).IsRequired();
            builder.Property(a => a.SrcSubjIdNb).IsRequired();
            builder.Property(a => a.SrcSubjSeqNb).IsRequired();
            builder.Property(a => a.SrcRef).IsRequired();
            builder.Property(a => a.SrcName).HasMaxLength(440).IsRequired();
            builder.Property(a => a.SrcAin).IsRequired();
            builder.Property(a => a.AddrQty).HasMaxLength(1).IsRequired();
            builder.Property(a => a.SrcAddrFrmtCd).HasMaxLength(2).IsRequired();
            builder.Property(a => a.SrcAddr).HasMaxLength(440).IsRequired();
            builder.Property(a => a.SrcNm).HasMaxLength(150).IsRequired();
            builder.Property(a => a.AddrLine1).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine2).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine3).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine4).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine5).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine6).HasMaxLength(112).IsRequired();
            builder.Property(a => a.AddrLine7).HasMaxLength(8).IsRequired();
            builder.Property(a => a.AinFromNas).IsRequired();
            builder.Property(a => a.QtyFromNas).HasMaxLength(1).IsRequired();
            builder.Property(a => a.AinChangeFlag).HasMaxLength(1).IsRequired();
            builder.Property(a => a.DinFoundFlag).HasMaxLength(1).IsRequired();
            builder.Property(a => a.ErrorCode).HasMaxLength(4).IsRequired();
            builder.Property(a => a.ProcessStg).HasMaxLength(1).IsRequired();
            builder.Property(a => a.FieldIndicator).HasMaxLength(1).IsRequired();
            builder.Property(a => a.DataProvider).HasMaxLength(5).IsRequired();
            builder.Property(a => a.SequenceNb).IsRequired();
            builder.Property(a => a.PinCount).IsRequired();
            builder.Property(a => a.NonStdLinCount).IsRequired();
            builder.Property(a => a.DinCount).IsRequired();

            builder.HasMany(a => a.DinReapply)
                .WithOne(d => d.AuditRecord)
                .HasForeignKey(d => d.AuditRecordId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.HasIndex(a => a.SrcDin);
            builder.HasIndex(a => a.ProcStartDate);

            builder.Property(a => a.CreatedDate).HasDefaultValueSql("CURRENT_TIMESTAMP");
            builder.Property(a => a.ModifiedDate).HasDefaultValueSql("CURRENT_TIMESTAMP");
        }
    }
}