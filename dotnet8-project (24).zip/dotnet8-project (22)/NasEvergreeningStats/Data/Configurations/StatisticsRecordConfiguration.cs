using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data.Configurations
{
    public class StatisticsRecordConfiguration : IEntityTypeConfiguration<StatisticsRecord>
    {
        public void Configure(EntityTypeBuilder<StatisticsRecord> builder)
        {
            builder.ToTable("StatisticsRecords");

            builder.HasKey(s => s.Id);

            builder.Property(s => s.ReapplyDinCount).IsRequired();
            builder.Property(s => s.PinCount).IsRequired();
            builder.Property(s => s.LinDeletedCount).IsRequired();
            builder.Property(s => s.TotalExistErrorRecords).IsRequired();
            builder.Property(s => s.CpuTime).IsRequired();
            builder.Property(s => s.ElapsedTime).IsRequired();
            builder.Property(s => s.TotalCpuTime).IsRequired();
            builder.Property(s => s.TotalElapsedTime).IsRequired();

            builder.Property(s => s.CreatedDate).HasDefaultValueSql("CURRENT_TIMESTAMP");
            builder.Property(s => s.ModifiedDate).HasDefaultValueSql("CURRENT_TIMESTAMP");
        }
    }
}