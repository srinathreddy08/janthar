using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data.Configurations
{
    public class DinInputRecordConfiguration : IEntityTypeConfiguration<DinInputRecord>
    {
        public void Configure(EntityTypeBuilder<DinInputRecord> builder)
        {
            builder.ToTable("DinInputRecords");

            builder.HasKey(d => d.Id);

            builder.Property(d => d.Din).IsRequired();
            builder.Property(d => d.SubjNb).IsRequired();
            builder.Property(d => d.SubjSeqNb).IsRequired();

            builder.HasIndex(d => d.Din);

            builder.Property(d => d.CreatedDate).HasDefaultValueSql("CURRENT_TIMESTAMP");
            builder.Property(d => d.ModifiedDate).HasDefaultValueSql("CURRENT_TIMESTAMP");
        }
    }
}