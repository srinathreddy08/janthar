using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data.Configurations
{
    public class ReapplyRecordConfiguration : IEntityTypeConfiguration<ReapplyRecord>
    {
        public void Configure(EntityTypeBuilder<ReapplyRecord> builder)
        {
            builder.ToTable("ReapplyRecords");

            builder.HasKey(r => r.Id);

            builder.Property(r => r.Din).IsRequired();
            builder.Property(r => r.SubjNb).IsRequired();
            builder.Property(r => r.SubjSeqNb).IsRequired();
            builder.Property(r => r.SrcProcess).HasMaxLength(50).IsRequired();
            builder.Property(r => r.RunDate).IsRequired();
            builder.Property(r => r.NoOfSubj).IsRequired();

            builder.Property(r => r.CreatedDate).HasDefaultValueSql("CURRENT_TIMESTAMP");
            builder.Property(r => r.ModifiedDate).HasDefaultValueSql("CURRENT_TIMESTAMP");

            builder.HasIndex(r => r.Din);
        }
    }
}