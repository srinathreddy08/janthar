using Microsoft.EntityFrameworkCore;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AuditRecord> AuditRecords { get; set; } = null!;
        public DbSet<DinInputRecord> DinInputRecords { get; set; } = null!;
        public DbSet<StatisticsRecord> StatisticsRecords { get; set; } = null!;
        public DbSet<ReapplyRecord> ReapplyRecords { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);

            base.OnModelCreating(modelBuilder);
        }
    }
}