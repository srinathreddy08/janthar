using NasEvergreeningStats.Services.Interfaces;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Services
{
    public class CpuTimeService : ICpuTimeService
    {
        public Task<(long CpuTime, long ElapsedTime)> GetCpuTimeAsync()
        {
            // Simulate CPU and elapsed time calculation
            // In real scenario, integrate with performance counters or external modules
            var cpuTime = Process.GetCurrentProcess().TotalProcessorTime.Ticks;
            var elapsedTime = Stopwatch.GetTimestamp();

            return Task.FromResult((cpuTime, elapsedTime));
        }
    }
}