using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Services.Interfaces;
using System;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Services
{
    public class LoggingService : ILoggingService
    {
        private readonly ILogger<LoggingService> _logger;

        public LoggingService(ILogger<LoggingService> logger)
        {
            _logger = logger;
        }

        public Task LogAsync(string logType, string logText)
        {
            if (string.IsNullOrWhiteSpace(logType))
                throw new ArgumentException("Log type must be provided.", nameof(logType));

            if (string.IsNullOrWhiteSpace(logText))
                throw new ArgumentException("Log text must be provided.", nameof(logText));

            // Map logType to log level
            switch (logType.ToUpperInvariant())
            {
                case "I":
                    _logger.LogInformation(logText);
                    break;
                case "E":
                    _logger.LogError(logText);
                    break;
                case "W":
                    _logger.LogWarning(logText);
                    break;
                default:
                    _logger.LogInformation(logText);
                    break;
            }

            return Task.CompletedTask;
        }
    }
}