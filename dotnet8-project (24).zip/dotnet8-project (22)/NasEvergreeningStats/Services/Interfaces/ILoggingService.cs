using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface ILoggingService
    {
        Task LogAsync(string logType, string logText);
    }
}