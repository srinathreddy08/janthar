using NasEvergreeningStats.Models.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IAuditProcessingService
    {
        Task ProcessAuditAndDinFilesAsync(string callMode, int loggingLevel);
        Task<IEnumerable<DisplayStatisticsDto>> GetDisplayStatisticsAsync();
    }
}