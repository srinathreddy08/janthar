using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface ICpuTimeService
    {
        Task<(long CpuTime, long ElapsedTime)> GetCpuTimeAsync();
    }
}