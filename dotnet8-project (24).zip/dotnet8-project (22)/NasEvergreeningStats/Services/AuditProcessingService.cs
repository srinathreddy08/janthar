using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Models.DTOs;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using NasEvergreeningStats.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NasEvergreeningStats.Services
{
    public class AuditProcessingService : IAuditProcessingService
    {
        private readonly IAuditRepository _auditRepository;
        private readonly IDinInputRepository _dinInputRepository;
        private readonly IStatisticsRepository _statisticsRepository;
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ICpuTimeService _cpuTimeService;
        private readonly ILoggingService _loggingService;
        private readonly ILogger<AuditProcessingService> _logger;

        public AuditProcessingService(
            IAuditRepository auditRepository,
            IDinInputRepository dinInputRepository,
            IStatisticsRepository statisticsRepository,
            IReapplyRepository reapplyRepository,
            ICpuTimeService cpuTimeService,
            ILoggingService loggingService,
            ILogger<AuditProcessingService> logger)
        {
            _auditRepository = auditRepository;
            _dinInputRepository = dinInputRepository;
            _statisticsRepository = statisticsRepository;
            _reapplyRepository = reapplyRepository;
            _cpuTimeService = cpuTimeService;
            _loggingService = loggingService;
            _logger = logger;
        }

        public async Task ProcessAuditAndDinFilesAsync(string callMode, int loggingLevel)
        {
            _logger.LogInformation("Starting audit and DIN files processing with callMode: {CallMode}, loggingLevel: {LoggingLevel}", callMode, loggingLevel);

            if (string.IsNullOrWhiteSpace(callMode) || (callMode != "U" && callMode != "R"))
            {
                _logger.LogError("Invalid call mode: {CallMode}. Expected 'U' or 'R'.", callMode);
                throw new ArgumentException("Call mode must be 'U' (Update) or 'R' (Read).", nameof(callMode));
            }

            if (loggingLevel < 0)
            {
                _logger.LogError("Invalid logging level: {LoggingLevel}. Must be non-negative.", loggingLevel);
                throw new ArgumentException("Logging level must be non-negative.", nameof(loggingLevel));
            }

            try
            {
                // Log entering program
                if (loggingLevel > 1)
                {
                    await _loggingService.LogAsync("I", "ENTERING PROGRAM EDBNAECE");
                }

                // Initialize accumulators
                int waDinCount = 0;
                int waPinCount = 0;
                int waLinCount = 0;
                int waErroredRec = 0;

                // Get all audit records
                var auditRecords = await _auditRepository.GetAllAsync();

                // Process audit records
                foreach (var audit in auditRecords)
                {
                    if (IsAuditError(audit))
                    {
                        waErroredRec++;
                    }
                    else if (IsAuditProcessed(audit))
                    {
                        waPinCount += audit.PinCount;
                        waLinCount += audit.NonStdLinCount;
                    }
                }

                // Get all DIN input records
                var dinInputRecords = await _dinInputRepository.GetAllAsync();

                // Process DIN input records
                foreach (var dinInput in dinInputRecords)
                {
                    waDinCount++;

                    // Prepare reapply record if update mode
                    if (callMode == "U")
                    {
                        var reapplyRecord = new ReapplyRecord
                        {
                            Din = dinInput.Din,
                            SubjNb = dinInput.SubjNb,
                            SubjSeqNb = dinInput.SubjSeqNb,
                            SrcProcess = ExtractSrcProcess(dinInput.Din),
                            RunDate = DateTime.UtcNow,
                            NoOfSubj = 1,
                            CreatedDate = DateTime.UtcNow,
                            ModifiedDate = DateTime.UtcNow,
                            CreatedBy = "System",
                            ModifiedBy = "System"
                        };

                        await _reapplyRepository.AddAsync(reapplyRecord);
                    }
                }

                // Get CPU and elapsed time
                var cpuTimeInfo = await _cpuTimeService.GetCpuTimeAsync();

                // Prepare statistics record
                var statisticsRecord = new StatisticsRecord
                {
                    ReapplyDinCount = waDinCount,
                    PinCount = waPinCount,
                    LinDeletedCount = waLinCount,
                    TotalExistErrorRecords = waErroredRec,
                    CpuTime = cpuTimeInfo.CpuTime,
                    ElapsedTime = cpuTimeInfo.ElapsedTime,
                    TotalCpuTime = cpuTimeInfo.CpuTime, // Assuming cumulative
                    TotalElapsedTime = cpuTimeInfo.ElapsedTime, // Assuming cumulative
                    CreatedDate = DateTime.UtcNow,
                    ModifiedDate = DateTime.UtcNow,
                    CreatedBy = "System",
                    ModifiedBy = "System"
                };

                // Save or update statistics
                var existingStats = await _statisticsRepository.GetLatestAsync();
                if (existingStats == null)
                {
                    await _statisticsRepository.AddAsync(statisticsRecord);
                }
                else
                {
                    existingStats.ReapplyDinCount = statisticsRecord.ReapplyDinCount;
                    existingStats.PinCount = statisticsRecord.PinCount;
                    existingStats.LinDeletedCount = statisticsRecord.LinDeletedCount;
                    existingStats.TotalExistErrorRecords = statisticsRecord.TotalExistErrorRecords;
                    existingStats.CpuTime = statisticsRecord.CpuTime;
                    existingStats.ElapsedTime = statisticsRecord.ElapsedTime;
                    existingStats.TotalCpuTime += statisticsRecord.CpuTime;
                    existingStats.TotalElapsedTime += statisticsRecord.ElapsedTime;
                    existingStats.ModifiedDate = DateTime.UtcNow;
                    existingStats.ModifiedBy = "System";

                    await _statisticsRepository.UpdateAsync(existingStats);
                }

                // Log exiting program
                if (loggingLevel > 1)
                {
                    await _loggingService.LogAsync("I", "EXITING PROGRAM EDBNAECE");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing audit and DIN files");
                throw;
            }
        }

        public async Task<IEnumerable<DisplayStatisticsDto>> GetDisplayStatisticsAsync()
        {
            _logger.LogInformation("Retrieving display statistics");

            var stats = await _statisticsRepository.GetLatestAsync();
            if (stats == null)
            {
                return Enumerable.Empty<DisplayStatisticsDto>();
            }

            var displayStats = new List<DisplayStatisticsDto>
            {
                new DisplayStatisticsDto { Header = "NUMBER OF LOW QUALITY INPUT RECORDS  :", Detail = 0 }, // Placeholder, COBOL logic not explicit
                new DisplayStatisticsDto { Header = "NUMBER OF TEXT QUALITY INPUT RECORDS :", Detail = 0 }, // Placeholder
                new DisplayStatisticsDto { Header = "NUMBER OF ERRORED RECORDS            :", Detail = stats.TotalExistErrorRecords },
                new DisplayStatisticsDto { Header = "TOTAL NUMBER OF INPUT RECORDS        :", Detail = stats.ReapplyDinCount },
                new DisplayStatisticsDto { Header = "NO OF RECORDS WITH AIN AND QLTY UNCHG:", Detail = 0 }, // Placeholder
                new DisplayStatisticsDto { Header = "NO OF TEXT TO LQ RECORD WITH SAME AIN:", Detail = 0 }, // Placeholder
                new DisplayStatisticsDto { Header = "NO OF LQ TO HQ RECORDS WITH UNCHG AIN:", Detail = 0 }, // Placeholder
                new DisplayStatisticsDto { Header = "NO OF RECORDS WITH CHNG AIN SAME QLTY:", Detail = 0 }, // Placeholder
                new DisplayStatisticsDto { Header = "NO OF TEXT TO LQ RECORD WITH CHNG AIN:", Detail = 0 }, // Placeholder
                new DisplayStatisticsDto { Header = "NO OF LQ TO HQ RECORDS WITH CHNGD AIN:", Detail = 0 }, // Placeholder
                new DisplayStatisticsDto { Header = "NUMBER OF PINS IMPACTED              :", Detail = stats.PinCount },
                new DisplayStatisticsDto { Header = "NUMBER OF DINS SENT TO REAPPLY       :", Detail = stats.ReapplyDinCount },
                new DisplayStatisticsDto { Header = "NUMBER OF LINS DELETED               :", Detail = stats.LinDeletedCount },
                new DisplayStatisticsDto { Header = "TOTAL CPU TIME                       :", Detail = stats.TotalCpuTime },
                new DisplayStatisticsDto { Header = "TOTAL ELAPSED TIME                   :", Detail = stats.TotalElapsedTime },
                new DisplayStatisticsDto { Header = "NO OF TEXT TO HQ RECORD WITH CHNG AIN:", Detail = 0 } // Placeholder
            };

            return displayStats;
        }

        private bool IsAuditError(AuditRecord audit)
        {
            return audit.ErrorCode == "0001" || audit.ErrorCode == "0002" || audit.ErrorCode == "0003" || audit.ErrorCode == "0004" || audit.ErrorCode == "0005" || audit.ErrorCode == "0006";
        }

        private bool IsAuditProcessed(AuditRecord audit)
        {
            return audit.ProcessStg == "P";
        }

        private string ExtractSrcProcess(long din)
        {
            // Extract substring from DIN numeric as per COBOL logic (positions 7 to 10)
            // DIN is long, convert to string with leading zeros
            var dinStr = din.ToString("D19");
            if (dinStr.Length >= 10)
            {
                return dinStr.Substring(6, 4); // zero-based index
            }
            return string.Empty;
        }
    }
}