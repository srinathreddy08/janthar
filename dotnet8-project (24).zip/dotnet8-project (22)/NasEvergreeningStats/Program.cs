using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Repositories;
using NasEvergreeningStats.Repositories.Interfaces;
using NasEvergreeningStats.Services;
using NasEvergreeningStats.Services.Interfaces;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;


var builder = WebApplication.CreateBuilder(args);

// Configure services
builder.Services.AddControllers();

// Configure DbContext with connection string from appsettings.json
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

// Register repositories
builder.Services.AddScoped<IAuditRepository, AuditRepository>();
builder.Services.AddScoped<IDinInputRepository, DinInputRepository>();
builder.Services.AddScoped<IStatisticsRepository, StatisticsRepository>();
builder.Services.AddScoped<IReapplyRepository, ReapplyRepository>();

// Register services
builder.Services.AddScoped<IAuditProcessingService, AuditProcessingService>();
builder.Services.AddScoped<ILoggingService, LoggingService>();
builder.Services.AddScoped<ICpuTimeService, CpuTimeService>();

// Configure logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();

// Configure authentication (JWT Bearer) if needed
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.Authority = builder.Configuration["Jwt:Authority"];
        options.Audience = builder.Configuration["Jwt:Audience"];
    });

// Configure Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();