using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class ReapplyControllerTests
    {
        private readonly Mock<IReapplyRepository> _mockReapplyRepository;
        private readonly Mock<ILogger<ReapplyController>> _mockLogger;
        private readonly ReapplyController _controller;

        public ReapplyControllerTests()
        {
            _mockReapplyRepository = new Mock<IReapplyRepository>();
            _mockLogger = new Mock<ILogger<ReapplyController>>();
            _controller = new ReapplyController(_mockReapplyRepository.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task AddReapplyRecord_WithValidRecord_ReturnsOk()
        {
            // Arrange
            var record = new ReapplyRecord
            {
                Din = 1234567890123456789,
                SubjNb = 1,
                SubjSeqNb = 1
            };

            _mockReapplyRepository.Setup(r => r.AddAsync(record)).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.AddReapplyRecord(record);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Contains("Reapply record added successfully", okResult.Value.ToString());
            _mockReapplyRepository.Verify(r => r.AddAsync(record), Times.Once);
        }

        [Fact]
        public async Task AddReapplyRecord_WithNullRecord_ReturnsBadRequest()
        {
            // Act
            var result = await _controller.AddReapplyRecord(null);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Reapply record cannot be null.", badRequestResult.Value);
            _mockReapplyRepository.Verify(r => r.AddAsync(It.IsAny<ReapplyRecord>()), Times.Never);
        }

        [Fact]
        public async Task AddReapplyRecord_WhenRepositoryThrowsException_ReturnsInternalServerError()
        {
            // Arrange
            var record = new ReapplyRecord
            {
                Din = 1234567890123456789,
                SubjNb = 1,
                SubjSeqNb = 1
            };

            _mockReapplyRepository.Setup(r => r.AddAsync(record)).ThrowsAsync(new Exception("DB error"));

            // Act
            var result = await _controller.AddReapplyRecord(record);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal("An error occurred while adding reapply record.", objectResult.Value);
            _mockReapplyRepository.Verify(r => r.AddAsync(record), Times.Once);
        }
    }
}
