using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Models.DTOs;
using NasEvergreeningStats.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class StatisticsControllerTests
    {
        private readonly Mock<IAuditProcessingService> _mockAuditProcessingService;
        private readonly Mock<ILogger<StatisticsController>> _mockLogger;
        private readonly StatisticsController _controller;

        public StatisticsControllerTests()
        {
            _mockAuditProcessingService = new Mock<IAuditProcessingService>();
            _mockLogger = new Mock<ILogger<StatisticsController>>();
            _controller = new StatisticsController(_mockAuditProcessingService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task GetDisplayStatisticsAsync_ReturnsOkWithStatistics()
        {
            // Arrange
            var expectedStats = new List<DisplayStatisticsDto>
            {
                new DisplayStatisticsDto { Header = "Test Header", Detail = 123 }
            };

            _mockAuditProcessingService.Setup(s => s.GetDisplayStatisticsAsync())
                .ReturnsAsync(expectedStats);

            // Act
            var result = await _controller.GetDisplayStatisticsAsync();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var returnedStats = Assert.IsAssignableFrom<IEnumerable<DisplayStatisticsDto>>(okResult.Value);
            Assert.NotEmpty(returnedStats);
            _mockAuditProcessingService.Verify(s => s.GetDisplayStatisticsAsync(), Times.Once);
        }

        [Fact]
        public async Task GetDisplayStatisticsAsync_WhenServiceThrowsException_ReturnsInternalServerError()
        {
            // Arrange
            _mockAuditProcessingService.Setup(s => s.GetDisplayStatisticsAsync())
                .ThrowsAsync(new Exception("Service failure"));

            // Act
            var result = await _controller.GetDisplayStatisticsAsync();

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal("An error occurred while retrieving statistics.", objectResult.Value);
            _mockAuditProcessingService.Verify(s => s.GetDisplayStatisticsAsync(), Times.Once);
        }
    }
}
