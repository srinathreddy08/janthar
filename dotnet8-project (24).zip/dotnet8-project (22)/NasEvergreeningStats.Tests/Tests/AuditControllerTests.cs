using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class AuditControllerTests
    {
        private readonly Mock<IAuditProcessingService> _mockAuditProcessingService;
        private readonly Mock<ILogger<AuditController>> _mockLogger;
        private readonly AuditController _controller;

        public AuditControllerTests()
        {
            _mockAuditProcessingService = new Mock<IAuditProcessingService>();
            _mockLogger = new Mock<ILogger<AuditController>>();
            _controller = new AuditController(_mockAuditProcessingService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessAuditAsync_WithValidParameters_ReturnsOk()
        {
            // Arrange
            string callMode = "U";
            int loggingLevel = 1;
            _mockAuditProcessingService.Setup(s => s.ProcessAuditAndDinFilesAsync(callMode, loggingLevel))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _controller.ProcessAuditAsync(callMode, loggingLevel);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);
            Assert.Contains("Audit and DIN files processed successfully", okResult.Value.ToString());
            _mockAuditProcessingService.Verify(s => s.ProcessAuditAndDinFilesAsync(callMode, loggingLevel), Times.Once);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("")]
        [InlineData("   ")]
        public async Task ProcessAuditAsync_WithNullOrWhitespaceCallMode_ReturnsBadRequest(string callMode)
        {
            // Arrange
            int loggingLevel = 0;

            // Act
            var result = await _controller.ProcessAuditAsync(callMode, loggingLevel);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Call mode parameter is required.", badRequestResult.Value);
            _mockAuditProcessingService.Verify(s => s.ProcessAuditAndDinFilesAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task ProcessAuditAsync_WithNegativeLoggingLevel_ReturnsBadRequest()
        {
            // Arrange
            string callMode = "U";
            int loggingLevel = -1;

            // Act
            var result = await _controller.ProcessAuditAsync(callMode, loggingLevel);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Logging level must be non-negative.", badRequestResult.Value);
            _mockAuditProcessingService.Verify(s => s.ProcessAuditAndDinFilesAsync(It.IsAny<string>(), It.IsAny<int>()), Times.Never);
        }

        [Fact]
        public async Task ProcessAuditAsync_WhenAuditProcessingServiceThrowsArgumentException_ReturnsBadRequest()
        {
            // Arrange
            string callMode = "U";
            int loggingLevel = 1;
            var exceptionMessage = "Invalid call mode";

            _mockAuditProcessingService.Setup(s => s.ProcessAuditAndDinFilesAsync(callMode, loggingLevel))
                .ThrowsAsync(new ArgumentException(exceptionMessage));

            // Act
            var result = await _controller.ProcessAuditAsync(callMode, loggingLevel);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(exceptionMessage, badRequestResult.Value);
            _mockAuditProcessingService.Verify(s => s.ProcessAuditAndDinFilesAsync(callMode, loggingLevel), Times.Once);
        }

        [Fact]
        public async Task ProcessAuditAsync_WhenAuditProcessingServiceThrowsException_ReturnsInternalServerError()
        {
            // Arrange
            string callMode = "U";
            int loggingLevel = 1;

            _mockAuditProcessingService.Setup(s => s.ProcessAuditAndDinFilesAsync(callMode, loggingLevel))
                .ThrowsAsync(new Exception("Unexpected error"));

            // Act
            var result = await _controller.ProcessAuditAsync(callMode, loggingLevel);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal("An unexpected error occurred while processing audit files.", objectResult.Value);
            _mockAuditProcessingService.Verify(s => s.ProcessAuditAndDinFilesAsync(callMode, loggingLevel), Times.Once);
        }
    }
}
