using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStatsProcessor.Data;
using NasEvergreeningStatsProcessor.Models.Entities;
using NasEvergreeningStatsProcessor.Repositories.Interfaces;

namespace NasEvergreeningStatsProcessor.Repositories
{
    public class FileRepository : IFileRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<FileRepository> _logger;

        public FileRepository(ApplicationDbContext context, ILogger<FileRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<List<AuditRecord>> GetAllAuditRecordsAsync()
        {
            try
            {
                return await _context.AuditRecords
                    .Include(a => a.DinReapply)
                    .AsNoTracking()
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving audit records from database.");
                throw;
            }
        }

        public async Task<List<DinInputRecord>> GetAllDinInputRecordsAsync()
        {
            try
            {
                return await _context.DinInputRecords.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving DIN input records from database.");
                throw;
            }
        }

        public async Task<StatsRecord?> GetStatsRecordAsync()
        {
            try
            {
                return await _context.StatsRecords.FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving stats record from database.");
                throw;
            }
        }

        public async Task UpdateStatsRecordAsync(StatsRecord statsRecord)
        {
            try
            {
                _context.StatsRecords.Update(statsRecord);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating stats record in database.");
                throw;
            }
        }

        public async Task AddReapplyRecordAsync(ReapplyRecord reapplyRecord)
        {
            try
            {
                await _context.ReapplyRecords.AddAsync(reapplyRecord);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding reapply record to database.");
                throw;
            }
        }

        public async Task SaveChangesAsync()
        {
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving changes to database.");
                throw;
            }
        }
    }
}