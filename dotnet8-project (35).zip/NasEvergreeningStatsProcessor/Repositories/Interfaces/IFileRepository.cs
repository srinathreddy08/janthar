using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreeningStatsProcessor.Models.Entities;

namespace NasEvergreeningStatsProcessor.Repositories.Interfaces
{
    public interface IFileRepository
    {
        Task<List<AuditRecord>> GetAllAuditRecordsAsync();
        Task<List<DinInputRecord>> GetAllDinInputRecordsAsync();
        Task<StatsRecord?> GetStatsRecordAsync();
        Task UpdateStatsRecordAsync(StatsRecord statsRecord);
        Task AddReapplyRecordAsync(ReapplyRecord reapplyRecord);
        Task SaveChangesAsync();
    }
}