using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NasEvergreeningStatsProcessor.Models.DTOs;
using NasEvergreeningStatsProcessor.Services.Interfaces;

namespace NasEvergreeningStatsProcessor.Batch
{
    public class BatchJobRunner : BackgroundService
    {
        private readonly IStatsProcessingService _statsProcessingService;
        private readonly ILogger<BatchJobRunner> _logger;

        public BatchJobRunner(IStatsProcessingService statsProcessingService, ILogger<BatchJobRunner> logger)
        {
            _statsProcessingService = statsProcessingService;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("BatchJobRunner started.");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    // Retrieve call mode and logging level from configuration or DB
                    var request = new ProcessStatsRequestDto
                    {
                        CallMode = "U", // This should be fetched dynamically from DB/config
                        LoggingLevel = 1
                    };

                    var result = await _statsProcessingService.ProcessStatsAsync(request);

                    if (result.Success)
                    {
                        _logger.LogInformation("Batch job processed successfully.");
                    }
                    else
                    {
                        _logger.LogWarning("Batch job processed with warnings: {Message}", result.Message);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error occurred during batch job processing.");
                }

                // Wait for configured interval before next run
                await Task.Delay(TimeSpan.FromHours(24), stoppingToken); // Example: daily run
            }

            _logger.LogInformation("BatchJobRunner stopping.");
        }
    }
}