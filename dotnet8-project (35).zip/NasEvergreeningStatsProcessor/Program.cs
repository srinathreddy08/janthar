using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using NasEvergreeningStatsProcessor.Data;
using NasEvergreeningStatsProcessor.Repositories;
using NasEvergreeningStatsProcessor.Repositories.Interfaces;
using NasEvergreeningStatsProcessor.Services;
using NasEvergreeningStatsProcessor.Services.Interfaces;
using NasEvergreeningStatsProcessor.Middleware;
using NasEvergreeningStatsProcessor.Batch;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// Configure DbContext with connection string from appsettings.json
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseMySql(builder.Configuration.GetConnectionString("DefaultConnection"),
        new MySqlServerVersion(new Version(8, 0, 33))));

// Register repositories and services
builder.Services.AddScoped<IFileRepository, FileRepository>();
builder.Services.AddScoped<IStatsProcessingService, StatsProcessingService>();

// Add logging
builder.Services.AddLogging();

// Add batch job runner as hosted service
builder.Services.AddHostedService<BatchJobRunner>();

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseMiddleware<ErrorHandlingMiddleware>();

app.MapControllers();

app.Run();