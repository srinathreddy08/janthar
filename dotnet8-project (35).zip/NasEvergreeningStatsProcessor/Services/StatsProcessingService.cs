using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStatsProcessor.Models.DTOs;
using NasEvergreeningStatsProcessor.Models.Entities;
using NasEvergreeningStatsProcessor.Repositories.Interfaces;
using NasEvergreeningStatsProcessor.Services.Interfaces;

namespace NasEvergreeningStatsProcessor.Services
{
    public class StatsProcessingService : IStatsProcessingService
    {
        private readonly IFileRepository _fileRepository;
        private readonly ILogger<StatsProcessingService> _logger;

        public StatsProcessingService(IFileRepository fileRepository, ILogger<StatsProcessingService> logger)
        {
            _fileRepository = fileRepository;
            _logger = logger;
        }

        public async Task<ProcessStatsResponseDto> ProcessStatsAsync(ProcessStatsRequestDto request)
        {
            _logger.LogInformation("Starting ProcessStatsAsync with CallMode: {CallMode}, LoggingLevel: {LoggingLevel}", request.CallMode, request.LoggingLevel);

            if (request == null)
            {
                _logger.LogError("ProcessStatsRequestDto is null.");
                throw new ArgumentNullException(nameof(request));
            }

            if (string.IsNullOrWhiteSpace(request.CallMode) || (request.CallMode != "U" && request.CallMode != "R"))
            {
                _logger.LogError("Invalid CallMode: {CallMode}. Must be 'U' or 'R'.", request.CallMode);
                return new ProcessStatsResponseDto
                {
                    Success = false,
                    Message = "Invalid CallMode. Must be 'U' (Update) or 'R' (Read)."
                };
            }

            try
            {
                // Retrieve audit and DIN input records
                var auditRecords = await _fileRepository.GetAllAuditRecordsAsync();
                var dinInputRecords = await _fileRepository.GetAllDinInputRecordsAsync();

                // Retrieve existing stats record or create new
                var statsRecord = await _fileRepository.GetStatsRecordAsync() ?? new StatsRecord();

                // Initialize accumulators
                int waDinCount = 0;
                int waPinCount = 0;
                int waLinCount = 0;
                int waErroredRec = 0;

                // Process audit records
                foreach (var audit in auditRecords)
                {
                    if (IsAuditError(audit))
                    {
                        waErroredRec++;
                    }
                    else if (IsAuditProcessed(audit))
                    {
                        waPinCount += audit.PinCount;
                        waLinCount += audit.NonStdLinCount;
                    }
                }

                // Process DIN input records
                foreach (var din in dinInputRecords)
                {
                    waDinCount++;

                    if (request.CallMode == "U")
                    {
                        // Create and add reapply record
                        var reapplyRecord = new ReapplyRecord
                        {
                            Din = din.Din,
                            SrcProcess = ExtractSrcProcess(din.Din),
                            RunDate = DateTime.UtcNow.ToString("yyyyMMdd"),
                            NoOfSubj = 1,
                            SubjNb1 = din.SubjNb,
                            SubjSeq1 = din.SubjSeqNb
                        };

                        // Special logic for SrcProcess 80,60,70,50 to add second subject
                        if (new[] { 80, 60, 70, 50 }.Contains(ParseSrcProcessCode(reapplyRecord.SrcProcess)))
                        {
                            reapplyRecord.NoOfSubj = 2;
                            reapplyRecord.SubjNb2 = 2;
                            reapplyRecord.SubjSeq2 = din.SubjSeqNb;
                        }

                        await _fileRepository.AddReapplyRecordAsync(reapplyRecord);
                    }
                }

                // Update stats record with accumulated counts
                statsRecord.ReapplyDinCount = waDinCount;
                statsRecord.PinCount = waPinCount;
                statsRecord.LinDeleted = waLinCount;
                statsRecord.TotalExistErrorRec = waErroredRec;

                // Update total records count
                statsRecord.TotalRecords = auditRecords.Count;

                // Update CPU and elapsed time metrics (simulate or retrieve from performance service)
                // For demonstration, set dummy values
                statsRecord.EdbnaeceCpu = 427735;
                statsRecord.EdbnaeceElp = 0;
                statsRecord.TotalTimeCpu = 1493039071;
                statsRecord.TotalTimeElp = 2792;

                await _fileRepository.UpdateStatsRecordAsync(statsRecord);

                _logger.LogInformation("ProcessStatsAsync completed successfully.");

                return new ProcessStatsResponseDto
                {
                    Success = true,
                    Message = "Statistics processed successfully."
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during ProcessStatsAsync.");
                throw;
            }
        }

        private bool IsAuditError(AuditRecord audit)
        {
            return audit.ProcessStg == "E" || audit.ErrorCode != "0000";
        }

        private bool IsAuditProcessed(AuditRecord audit)
        {
            return audit.ProcessStg == "P" || audit.ProcessStg == "U";
        }

        private string ExtractSrcProcess(decimal din)
        {
            // Extract 4 characters from DIN numeric as string for SrcProcess
            // Assuming DIN is numeric, convert to string with leading zeros
            var dinStr = din.ToString("D19");
            return dinStr.Substring(6, 4); // 7th to 10th character (1-based index)
        }

        private int ParseSrcProcessCode(string srcProcess)
        {
            if (int.TryParse(srcProcess, out int code))
                return code;
            return 0;
        }
    }
}