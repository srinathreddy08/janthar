using System.Threading.Tasks;
using NasEvergreeningStatsProcessor.Models.DTOs;

namespace NasEvergreeningStatsProcessor.Services.Interfaces
{
    public interface IStatsProcessingService
    {
        Task<ProcessStatsResponseDto> ProcessStatsAsync(ProcessStatsRequestDto request);
    }
}