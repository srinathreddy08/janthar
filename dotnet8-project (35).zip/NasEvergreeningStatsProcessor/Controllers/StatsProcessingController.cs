using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreeningStatsProcessor.Models.DTOs;
using NasEvergreeningStatsProcessor.Services.Interfaces;

namespace NasEvergreeningStatsProcessor.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatsProcessingController : ControllerBase
    {
        private readonly IStatsProcessingService _statsProcessingService;
        private readonly ILogger<StatsProcessingController> _logger;

        public StatsProcessingController(IStatsProcessingService statsProcessingService, ILogger<StatsProcessingController> logger)
        {
            _statsProcessingService = statsProcessingService;
            _logger = logger;
        }

        [HttpPost("process")]
        public async Task<IActionResult> ProcessStats([FromBody] ProcessStatsRequestDto request)
        {
            _logger.LogInformation("Received request to process stats with CallMode: {CallMode}", request.CallMode);

            if (!ModelState.IsValid)
            {
                _logger.LogWarning("Invalid model state for ProcessStatsRequestDto.");
                return BadRequest(ModelState);
            }

            try
            {
                var response = await _statsProcessingService.ProcessStatsAsync(request);

                if (response.Success)
                    return Ok(response);

                return BadRequest(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception occurred while processing stats.");
                return StatusCode(500, "Internal server error occurred.");
            }
        }
    }
}