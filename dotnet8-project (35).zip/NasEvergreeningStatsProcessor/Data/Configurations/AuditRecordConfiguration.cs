using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStatsProcessor.Models.Entities;

namespace NasEvergreeningStatsProcessor.Data.Configurations
{
    public class AuditRecordConfiguration : IEntityTypeConfiguration<AuditRecord>
    {
        public void Configure(EntityTypeBuilder<AuditRecord> builder)
        {
            builder.ToTable("AuditRecords");

            builder.HasKey(a => a.Id);

            builder.Property(a => a.ProcStartDate).HasMaxLength(8).IsRequired();
            builder.Property(a => a.ProcStartTime).HasMaxLength(4).IsRequired();
            builder.Property(a => a.NasevgDin).HasPrecision(18, 0);
            builder.Property(a => a.SrcDin).HasPrecision(18, 0);
            builder.Property(a => a.SrcSubjIdNb).IsRequired();
            builder.Property(a => a.SrcSubjSeqNb).IsRequired();
            builder.Property(a => a.SrcRef).HasPrecision(18, 0);
            builder.Property(a => a.SrcName).HasMaxLength(440).IsRequired();
            builder.Property(a => a.SrcAin).IsRequired();
            builder.Property(a => a.AddrQty).HasMaxLength(1).IsRequired();
            builder.Property(a => a.SrcAddrFrmtCd).HasMaxLength(2).IsRequired();
            builder.Property(a => a.SrcAddr).HasMaxLength(440).IsRequired();

            builder.Property(a => a.SrcNm).HasMaxLength(150).IsRequired();
            builder.Property(a => a.AddrLine1).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine2).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine3).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine4).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine5).HasMaxLength(60).IsRequired();
            builder.Property(a => a.AddrLine6).HasMaxLength(112).IsRequired();
            builder.Property(a => a.AddrLine7).HasMaxLength(8).IsRequired();

            builder.Property(a => a.AinFromNas).IsRequired();
            builder.Property(a => a.QtyFromNas).HasMaxLength(1).IsRequired();
            builder.Property(a => a.AinChangeFlag).HasMaxLength(1).IsRequired();
            builder.Property(a => a.DinFoundFlag).HasMaxLength(1).IsRequired();
            builder.Property(a => a.ErrorCode).HasMaxLength(4).IsRequired();
            builder.Property(a => a.ProcessStg).HasMaxLength(1).IsRequired();
            builder.Property(a => a.FieldIndicator).HasMaxLength(1).IsRequired();
            builder.Property(a => a.DataProvider).HasMaxLength(5).IsRequired();
            builder.Property(a => a.SequenceNb).IsRequired();
            builder.Property(a => a.PinCount).IsRequired();
            builder.Property(a => a.NonStdLinCount).IsRequired();
            builder.Property(a => a.DinCount).IsRequired();

            builder.HasMany(a => a.DinReapply)
                .WithOne()
                .HasForeignKey("AuditRecordId")
                .OnDelete(DeleteBehavior.Cascade);

            builder.Ignore(a => a.IsHigh);
            builder.Ignore(a => a.IsLow);
            builder.Ignore(a => a.IsText);
            builder.Ignore(a => a.IsHighFromNas);
            builder.Ignore(a => a.IsLowFromNas);
            builder.Ignore(a => a.IsTextFromNas);
            builder.Ignore(a => a.AinChanged);
            builder.Ignore(a => a.NoAinChanged);
            builder.Ignore(a => a.DinFound);
            builder.Ignore(a => a.DinNotFound);
            builder.Ignore(a => a.IsError0001);
            builder.Ignore(a => a.IsError0002);
            builder.Ignore(a => a.IsError0003);
            builder.Ignore(a => a.IsError0004);
            builder.Ignore(a => a.IsError0005);
            builder.Ignore(a => a.IsError0006);
            builder.Ignore(a => a.IsProcessStgEmpty);
            builder.Ignore(a => a.IsError);
            builder.Ignore(a => a.IsProcessed);
            builder.Ignore(a => a.IsAinUpdated);
            builder.Ignore(a => a.IsToAddress);
            builder.Ignore(a => a.IsFromAddress);
            builder.Ignore(a => a.IsPostStdAin);
            builder.Ignore(a => a.IsEmpAin);
            builder.Ignore(a => a.IsUpdateAll);
        }
    }
}