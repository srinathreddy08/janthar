using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStatsProcessor.Models.Entities;

namespace NasEvergreeningStatsProcessor.Data.Configurations
{
    public class AuditDinReapplyConfiguration : IEntityTypeConfiguration<AuditDinReapply>
    {
        public void Configure(EntityTypeBuilder<AuditDinReapply> builder)
        {
            builder.ToTable("AuditDinReapplies");

            builder.HasKey(d => d.Id);

            builder.Property(d => d.Din).HasPrecision(18, 0).IsRequired();
            builder.Property(d => d.SubjIdNb).IsRequired();
            builder.Property(d => d.SubjIdSeqNb).IsRequired();
        }
    }
}