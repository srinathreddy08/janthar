using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStatsProcessor.Models.Entities;

namespace NasEvergreeningStatsProcessor.Data.Configurations
{
    public class ReapplyRecordConfiguration : IEntityTypeConfiguration<ReapplyRecord>
    {
        public void Configure(EntityTypeBuilder<ReapplyRecord> builder)
        {
            builder.ToTable("ReapplyRecords");

            builder.HasKey(r => r.Id);

            builder.Property(r => r.Din).HasPrecision(18, 0).IsRequired();
            builder.Property(r => r.SrcProcess).HasMaxLength(4).IsRequired();
            builder.Property(r => r.RunDate).HasMaxLength(8).IsRequired();
            builder.Property(r => r.NoOfSubj).IsRequired();
            builder.Property(r => r.SubjNb1).IsRequired();
            builder.Property(r => r.SubjSeq1).IsRequired();
            builder.Property(r => r.SubjNb2);
            builder.Property(r => r.SubjSeq2);
        }
    }
}