using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStatsProcessor.Models.Entities;

namespace NasEvergreeningStatsProcessor.Data.Configurations
{
    public class StatsRecordConfiguration : IEntityTypeConfiguration<StatsRecord>
    {
        public void Configure(EntityTypeBuilder<StatsRecord> builder)
        {
            builder.ToTable("StatsRecords");

            builder.HasKey(s => s.Id);

            builder.Property(s => s.LqRec).IsRequired();
            builder.Property(s => s.TxtRec).IsRequired();
            builder.Property(s => s.TotalExistErrorRec).IsRequired();
            builder.Property(s => s.TotalRecords).IsRequired();
            builder.Property(s => s.UnchangedAddr).IsRequired();
            builder.Property(s => s.TxtLqAinUnchg).IsRequired();
            builder.Property(s => s.LqHqAinUnchg).IsRequired();
            builder.Property(s => s.UnchgLqAinChgd).IsRequired();
            builder.Property(s => s.TxtLqAinChg).IsRequired();
            builder.Property(s => s.LqHqAinChg).IsRequired();
            builder.Property(s => s.PinCount).IsRequired();
            builder.Property(s => s.ReapplyDinCount).IsRequired();
            builder.Property(s => s.LinDeleted).IsRequired();
            builder.Property(s => s.EdbnaecaCpu).HasPrecision(17, 0).IsRequired();
            builder.Property(s => s.EdbnaecaElp).IsRequired();
            builder.Property(s => s.EdbnaecbCpu).HasPrecision(17, 0).IsRequired();
            builder.Property(s => s.EdbnaecbElp).IsRequired();
            builder.Property(s => s.EdbnaeccCpu).HasPrecision(17, 0).IsRequired();
            builder.Property(s => s.EdbnaeccElp).IsRequired();
            builder.Property(s => s.EdbnaecdCpu).HasPrecision(17, 0).IsRequired();
            builder.Property(s => s.EdbnaecdElp).IsRequired();
            builder.Property(s => s.EdbnaeceCpu).HasPrecision(17, 0).IsRequired();
            builder.Property(s => s.EdbnaeceElp).IsRequired();
            builder.Property(s => s.TotalTimeCpu).HasPrecision(17, 0).IsRequired();
            builder.Property(s => s.TotalTimeElp).IsRequired();
            builder.Property(s => s.TxtHqAinChg).IsRequired();

            builder.HasIndex(s => s.TotalRecords).HasDatabaseName("IX_StatsRecords_TotalRecords");
        }
    }
}