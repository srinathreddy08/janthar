using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NasEvergreeningStatsProcessor.Models.Entities;

namespace NasEvergreeningStatsProcessor.Data.Configurations
{
    public class DinInputRecordConfiguration : IEntityTypeConfiguration<DinInputRecord>
    {
        public void Configure(EntityTypeBuilder<DinInputRecord> builder)
        {
            builder.ToTable("DinInputRecords");

            builder.HasKey(d => d.Id);

            builder.Property(d => d.Din).HasPrecision(18, 0).IsRequired();
            builder.Property(d => d.SubjNb).IsRequired();
            builder.Property(d => d.SubjSeqNb).IsRequired();
        }
    }
}