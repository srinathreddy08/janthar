using Microsoft.EntityFrameworkCore;
using NasEvergreeningStatsProcessor.Models.Entities;
using NasEvergreeningStatsProcessor.Data.Configurations;

namespace NasEvergreeningStatsProcessor.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AuditRecord> AuditRecords { get; set; } = null!;
        public DbSet<AuditDinReapply> AuditDinReapplies { get; set; } = null!;
        public DbSet<DinInputRecord> DinInputRecords { get; set; } = null!;
        public DbSet<StatsRecord> StatsRecords { get; set; } = null!;
        public DbSet<ReapplyRecord> ReapplyRecords { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AuditRecordConfiguration());
            modelBuilder.ApplyConfiguration(new AuditDinReapplyConfiguration());
            modelBuilder.ApplyConfiguration(new DinInputRecordConfiguration());
            modelBuilder.ApplyConfiguration(new StatsRecordConfiguration());
            modelBuilder.ApplyConfiguration(new ReapplyRecordConfiguration());

            base.OnModelCreating(modelBuilder);
        }
    }
}