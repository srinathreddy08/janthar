using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStatsProcessor.Models.Entities
{
    [Table("StatsRecords")]
    public class StatsRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Range(0, 99999999)]
        public int LqRec { get; set; } // :PFX:-LQ-REC

        [Range(0, 99999999)]
        public int TxtRec { get; set; } // :PFX:-TXT-REC

        [Range(0, 99999999)]
        public int TotalExistErrorRec { get; set; } // :PFX:-TOTAL-EXIST-ERROR-REC

        [Range(0, 99999999)]
        public int TotalRecords { get; set; } // :PFX:-TOTAL-RECORDS

        [Range(0, 99999999)]
        public int UnchangedAddr { get; set; } // :PFX:-UNCHNGD-ADDR

        [Range(0, 99999999)]
        public int TxtLqAinUnchg { get; set; } // :PFX:-TXT-LQ-AIN-UNCHG

        [Range(0, 99999999)]
        public int LqHqAinUnchg { get; set; } // :PFX:-LQ-HQ-AIN-UNCHG

        [Range(0, 99999999)]
        public int UnchgLqAinChgd { get; set; } // :PFX:-UNCHG-LQ-AIN-CHGD

        [Range(0, 99999999)]
        public int TxtLqAinChg { get; set; } // :PFX:-TXT-LQ-AIN-CHG

        [Range(0, 99999999)]
        public int LqHqAinChg { get; set; } // :PFX:-LQ-HQ-AIN-CHG

        [Range(0, 99999999)]
        public int PinCount { get; set; } // :PFX:-PIN-CT

        [Range(0, 99999999)]
        public int ReapplyDinCount { get; set; } // :PFX:-REAPPLY-DIN-CT

        [Range(0, 99999999)]
        public int LinDeleted { get; set; } // :PFX:-LIN-DELETED

        [Column(TypeName = "decimal(17,0)")]
        public decimal EdbnaecaCpu { get; set; } // :PFX:-EDBNAECA-CPU

        [Range(0, 99999999)]
        public int EdbnaecaElp { get; set; } // :PFX:-EDBNAECA-ELP

        [Column(TypeName = "decimal(17,0)")]
        public decimal EdbnaecbCpu { get; set; } // :PFX:-EDBNAECB-CPU

        [Range(0, 99999999)]
        public int EdbnaecbElp { get; set; } // :PFX:-EDBNAECB-ELP

        [Column(TypeName = "decimal(17,0)")]
        public decimal EdbnaeccCpu { get; set; } // :PFX:-EDBNAECC-CPU

        [Range(0, 99999999)]
        public int EdbnaeccElp { get; set; } // :PFX:-EDBNAECC-ELP

        [Column(TypeName = "decimal(17,0)")]
        public decimal EdbnaecdCpu { get; set; } // :PFX:-EDBNAECD-CPU

        [Range(0, 99999999)]
        public int EdbnaecdElp { get; set; } // :PFX:-EDBNAECD-ELP

        [Column(TypeName = "decimal(17,0)")]
        public decimal EdbnaeceCpu { get; set; } // :PFX:-EDBNAECE-CPU

        [Range(0, 99999999)]
        public int EdbnaeceElp { get; set; } // :PFX:-EDBNAECE-ELP

        [Column(TypeName = "decimal(17,0)")]
        public decimal TotalTimeCpu { get; set; } // :PFX:-TOTAL-TIME-CPU

        [Range(0, 99999999)]
        public int TotalTimeElp { get; set; } // :PFX:-TOTAL-TIME-ELP

        [Range(0, 99999999)]
        public int TxtHqAinChg { get; set; } // :PFX:-TXT-HQ-AIN-CHG
    }
}