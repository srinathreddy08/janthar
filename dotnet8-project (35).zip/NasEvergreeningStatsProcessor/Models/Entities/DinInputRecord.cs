using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStatsProcessor.Models.Entities
{
    [Table("DinInputRecords")]
    public class DinInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Column(TypeName = "decimal(18,0)")]
        public decimal Din { get; set; } // D-INP-DIN PIC S9(18) COMP

        public short SubjNb { get; set; } // D-INP-SUBJ-NB PIC S9(04) COMP

        public short SubjSeqNb { get; set; } // D-INP-SUBJ-SEQ-NB PIC S9(04) COMP
    }
}