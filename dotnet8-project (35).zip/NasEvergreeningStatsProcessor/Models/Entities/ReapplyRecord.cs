using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStatsProcessor.Models.Entities
{
    [Table("ReapplyRecords")]
    public class ReapplyRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Column(TypeName = "decimal(18,0)")]
        public decimal Din { get; set; } // REAPPLY DIN field

        [Required, StringLength(4)]
        public string SrcProcess { get; set; } = string.Empty; // REPL-SRC-PROCESS

        [Required, StringLength(8)]
        public string RunDate { get; set; } = string.Empty; // REPL-RUN-DATE

        [Required]
        public short NoOfSubj { get; set; } // REPL-NO-OF-SUBJ

        [Required]
        public short SubjNb1 { get; set; } // REPL-SUBJ-NB(1)

        [Required]
        public short SubjSeq1 { get; set; } // REPL-SUBJ-SEQ(1)

        public short? SubjNb2 { get; set; } // REPL-SUBJ-NB(2) optional

        public short? SubjSeq2 { get; set; } // REPL-SUBJ-SEQ(2) optional
    }
}