using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStatsProcessor.Models.Entities
{
    [Table("AuditRecords")]
    public class AuditRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required, StringLength(8)]
        public string ProcStartDate { get; set; } = string.Empty; // N-PROC-START-DT PIC X(08)

        [Required, StringLength(4)]
        public string ProcStartTime { get; set; } = string.Empty; // N-PROC-START-TM PIC X(04)

        [Column(TypeName = "decimal(18,0)")]
        public decimal NasevgDin { get; set; } // N-NASEVG-DIN PIC S9(18) COMP

        [Column(TypeName = "decimal(18,0)")]
        public decimal SrcDin { get; set; } // N-SRC-DIN PIC S9(18) COMP

        public short SrcSubjIdNb { get; set; } // N-SRC-SUBJ-ID-NB PIC S9(04) COMP

        public short SrcSubjSeqNb { get; set; } // N-SRC-SUBJ-SEQ-NB PIC S9(04) COMP

        [Column(TypeName = "decimal(18,0)")]
        public decimal SrcRef { get; set; } // N-SRC-REF PIC S9(18) COMP

        [Required, StringLength(440)]
        public string SrcName { get; set; } = string.Empty; // N-SRC-NAME PIC X(440)

        public int SrcAin { get; set; } // N-SRC-AIN PIC S9(09) COMP

        [Required, StringLength(1)]
        public string AddrQty { get; set; } = string.Empty; // N-ADDR-QTY PIC X(01)

        [NotMapped]
        public bool IsHigh => AddrQty == "H";
        [NotMapped]
        public bool IsLow => AddrQty == "L";
        [NotMapped]
        public bool IsText => AddrQty == "T";

        [Required, StringLength(2)]
        public string SrcAddrFrmtCd { get; set; } = string.Empty; // N-SRC-ADDR-FRMT-CD PIC X(02)

        [Required, StringLength(440)]
        public string SrcAddr { get; set; } = string.Empty; // N-SRC-ADDR PIC X(440)

        // Formatted Address Fields
        [Required, StringLength(150)]
        public string SrcNm { get; set; } = string.Empty; // N-SRC-NM PIC X(150)

        [Required, StringLength(60)]
        public string AddrLine1 { get; set; } = string.Empty; // N-ADDR-LINE1 PIC X(60)

        [Required, StringLength(60)]
        public string AddrLine2 { get; set; } = string.Empty; // N-ADDR-LINE2 PIC X(60)

        [Required, StringLength(60)]
        public string AddrLine3 { get; set; } = string.Empty; // N-ADDR-LINE3 PIC X(60)

        [Required, StringLength(60)]
        public string AddrLine4 { get; set; } = string.Empty; // N-ADDR-LINE4 PIC X(60)

        [Required, StringLength(60)]
        public string AddrLine5 { get; set; } = string.Empty; // N-ADDR-LINE5 PIC X(60)

        [Required, StringLength(112)]
        public string AddrLine6 { get; set; } = string.Empty; // N-ADDR-LINE6 PIC X(112)

        [Required, StringLength(8)]
        public string AddrLine7 { get; set; } = string.Empty; // N-ADDR-LINE7 PIC X(08)

        public int AinFromNas { get; set; } // N-AIN-FROM-NAS PIC S9(09) COMP

        [Required, StringLength(1)]
        public string QtyFromNas { get; set; } = string.Empty; // N-QTY-FROM-NAS PIC X(01)

        [NotMapped]
        public bool IsHighFromNas => QtyFromNas == "H";
        [NotMapped]
        public bool IsLowFromNas => QtyFromNas == "L";
        [NotMapped]
        public bool IsTextFromNas => QtyFromNas == "T";

        [Required, StringLength(1)]
        public string AinChangeFlag { get; set; } = string.Empty; // N-AIN-CHANGE-FLAG PIC X(01)

        [NotMapped]
        public bool AinChanged => AinChangeFlag == "Y";
        [NotMapped]
        public bool NoAinChanged => AinChangeFlag == "N";

        [Required, StringLength(1)]
        public string DinFoundFlag { get; set; } = string.Empty; // N-DIN-FOUND-FLAG PIC X(01)

        [NotMapped]
        public bool DinFound => DinFoundFlag == "Y";
        [NotMapped]
        public bool DinNotFound => DinFoundFlag == "N";

        [Required, StringLength(4)]
        public string ErrorCode { get; set; } = string.Empty; // N-ERROR-CODE PIC X(04)

        [NotMapped]
        public bool IsError0001 => ErrorCode == "0001";
        [NotMapped]
        public bool IsError0002 => ErrorCode == "0002";
        [NotMapped]
        public bool IsError0003 => ErrorCode == "0003";
        [NotMapped]
        public bool IsError0004 => ErrorCode == "0004";
        [NotMapped]
        public bool IsError0005 => ErrorCode == "0005";
        [NotMapped]
        public bool IsError0006 => ErrorCode == "0006";

        [Required, StringLength(1)]
        public string ProcessStg { get; set; } = string.Empty; // N-PROCESS-STG PIC X(01)

        [NotMapped]
        public bool IsProcessStgEmpty => ProcessStg == " ";
        [NotMapped]
        public bool IsError => ProcessStg == "E";
        [NotMapped]
        public bool IsProcessed => ProcessStg == "P";
        [NotMapped]
        public bool IsAinUpdated => ProcessStg == "U";

        [Required, StringLength(1)]
        public string FieldIndicator { get; set; } = string.Empty; // N-FIELD-INDICATOR PIC X(01)

        [NotMapped]
        public bool IsToAddress => FieldIndicator == "T";
        [NotMapped]
        public bool IsFromAddress => FieldIndicator == "F";
        [NotMapped]
        public bool IsPostStdAin => FieldIndicator == "S";
        [NotMapped]
        public bool IsEmpAin => FieldIndicator == "E";
        [NotMapped]
        public bool IsUpdateAll => FieldIndicator == "A";

        [Required, StringLength(5)]
        public string DataProvider { get; set; } = string.Empty; // N-DATA-PROVIDER PIC X(05)

        public int SequenceNb { get; set; } // N-SEQUENCE-NB PIC 9(06)

        public short PinCount { get; set; } // N-PIN-COUNT PIC S9(04) COMP

        public short NonStdLinCount { get; set; } // N-NON-STD-LIN-COUNT PIC S9(04) COMP

        public short DinCount { get; set; } // N-DIN-COUNT PIC S9(04) COMP

        // Arrays
        public List<int> PinArray { get; set; } = new(); // N-PIN-ARRAY OCCURS 0 TO 500 TIMES

        public List<int> LinArray { get; set; } = new(); // N-LIN-ARRAY OCCURS 0 TO 200 TIMES

        public List<AuditDinReapply> DinReapply { get; set; } = new(); // N-DIN-REAPPLY OCCURS 0 TO 2200 TIMES
    }

    public class AuditDinReapply
    {
        [Key]
        public int Id { get; set; }

        [Column(TypeName = "decimal(18,0)")]
        public decimal Din { get; set; } // N-DIN PIC S9(18) COMP

        public short SubjIdNb { get; set; } // N-SUBJ-ID-NB PIC S9(04) COMP

        public short SubjIdSeqNb { get; set; } // N-SUBJ-ID-SEQ-NB PIC S9(04) COMP
    }
}