namespace NasEvergreeningStatsProcessor.Models
{
    public enum CallMode
    {
        Update = 'U',
        Read = 'R'
    }

    public enum EndOfFileFlag
    {
        Yes = 'Y',
        No = 'N'
    }
}