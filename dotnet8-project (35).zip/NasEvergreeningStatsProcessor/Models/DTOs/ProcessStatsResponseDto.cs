namespace NasEvergreeningStatsProcessor.Models.DTOs
{
    public class ProcessStatsResponseDto
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}