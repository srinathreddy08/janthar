using System.ComponentModel.DataAnnotations;

namespace NasEvergreeningStatsProcessor.Models.DTOs
{
    public class ProcessStatsRequestDto
    {
        [Required]
        [RegularExpression("[UR]", ErrorMessage = "CallMode must be 'U' (Update) or 'R' (Read).")]
        public string CallMode { get; set; } = string.Empty;

        [Range(0, 5)]
        public int LoggingLevel { get; set; } = 0;
    }
}