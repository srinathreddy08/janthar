using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStatsProcessor.Controllers;
using NasEvergreeningStatsProcessor.Models.DTOs;
using NasEvergreeningStatsProcessor.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStatsProcessor.Tests.Controllers
{
    public class StatsProcessingControllerTests
    {
        private readonly Mock<IStatsProcessingService> _mockService;
        private readonly Mock<ILogger<StatsProcessingController>> _mockLogger;
        private readonly StatsProcessingController _controller;

        public StatsProcessingControllerTests()
        {
            _mockService = new Mock<IStatsProcessingService>();
            _mockLogger = new Mock<ILogger<StatsProcessingController>>();
            _controller = new StatsProcessingController(_mockService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessStats_ReturnsOk_WhenServiceReturnsSuccess()
        {
            // Arrange
            var request = new ProcessStatsRequestDto { CallMode = "U" };
            var response = new ProcessStatsResponseDto { Success = true, Message = "Success" };
            _mockService.Setup(s => s.ProcessStatsAsync(request)).ReturnsAsync(response);

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(response, okResult.Value);
            _mockLogger.Verify(l => l.LogInformation(It.IsAny<string>(), request.CallMode), Times.Once);
        }

        [Fact]
        public async Task ProcessStats_ReturnsBadRequest_WhenServiceReturnsFailure()
        {
            // Arrange
            var request = new ProcessStatsRequestDto { CallMode = "R" };
            var response = new ProcessStatsResponseDto { Success = false, Message = "Failure" };
            _mockService.Setup(s => s.ProcessStatsAsync(request)).ReturnsAsync(response);

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(response, badRequestResult.Value);
            _mockLogger.Verify(l => l.LogInformation(It.IsAny<string>(), request.CallMode), Times.Once);
        }

        [Fact]
        public async Task ProcessStats_ReturnsBadRequest_WhenModelStateIsInvalid()
        {
            // Arrange
            _controller.ModelState.AddModelError("CallMode", "Required");
            var request = new ProcessStatsRequestDto();

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            _mockLogger.Verify(l => l.LogWarning(It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task ProcessStats_ReturnsInternalServerError_WhenServiceThrowsException()
        {
            // Arrange
            var request = new ProcessStatsRequestDto { CallMode = "U" };
            _mockService.Setup(s => s.ProcessStatsAsync(request)).ThrowsAsync(new Exception("Test exception"));

            // Act
            var result = await _controller.ProcessStats(request);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, objectResult.StatusCode);
            Assert.Equal("Internal server error occurred.", objectResult.Value);
            _mockLogger.Verify(l => l.LogError(It.IsAny<Exception>(), It.IsAny<string>()), Times.Once);
        }
    }
}
